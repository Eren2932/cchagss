# BRELLCAR 2.0 — ADB-консоль для головных устройств Changan (Compose Desktop)

Portable-приложение под Windows: русификация, установка приложений, заливка ресурсов голосового
ассистента (`tinove`), ADB по USB и Wi‑Fi, раздача Wi‑Fi с ПК. Чистая архитектура (domain / data / app) + MVI.
UI заблокирован до подтверждения лицензии сервером (по VIN).

> ⚠️ Границы: приложение **не вскрывает инженерное меню и не обходит активацию ADB**. Оно работает уже
> с подключённым (авторизованным) ГУ.

Это развитие проекта ChanganModRU v2.1.2 (бренд BRELLCAR 2.0, версия сборки 2.3.0).

## Что нового в 2.2.x

**Безопасность (anti-brick)**
- **Несколько устройств = блокировка.** Раньше брался «первый в списке» `adb devices`: рецепт мог уйти на телефон или не на тот ГУ. Теперь при >1 устройстве запуск запрещён, а подтверждение привязано к серийнику.
- **Закрыты дыры в `SafetyPolicy`:** `cmd package uninstall` обходил запрет `pm uninstall` (`cmd` убран из белого списка); `pm clear/hide/suspend` запрещены; ядро Android (`android`, `com.android.*`, `com.google.android.*`) отключить нельзя; сырые `settings put` для клавиатур/доступности/`adb_wifi_enabled` запрещены; `svc power`/`shutdown` запрещены.
- **Журнал изменений + откат.** Перед заменой установленного APK оригинал копируется в `Backups/<serial>/`; прежние значения настроек и список отключённых приложений пишутся в `journal.json` до выполнения шага. Кнопка «Откатить изменения» возвращает настройки и включает приложения. Откат самих APK — best-effort: Android на серийных сборках не даёт даунгрейд, поэтому оригиналы лежат в `Backups/` на случай ручного восстановления.
- **Проверка совместимости APK до запуска.** Приложение читает `AndroidManifest.xml` прямо из APK (свой AXML-парсер, без aapt): `minSdk` vs API ГУ, ABI vs процессор ГУ, `sharedUserId`. Системный APK (`android.uid.system`) помечается в диалоге подтверждения и не заменяется без успешного бэкапа оригинала.
- **Идемпотентность.** Уже установленная такая же/новая версия пропускается (`"force": true` отключает пропуск); push папки копирует содержимое (`dir/.`), повторный запуск не плодит `/sdcard/x/x`; результат push сверяется с числом локальных файлов; после `install` проверяется `pm path`.
- Раздача Wi‑Fi: случайный пароль на каждый запуск (раньше `12345678`), раздача выключается при закрытии программы, если включили мы.

**Функции:** ADB по Wi‑Fi (`adb tcpip` + `adb connect`), подтверждение перед каждым запуском с перечнем рисков, шаг `ime` (включение клавиатуры), рецепты по группам, журнал в `Logs/` и копирование в буфер.

## Структура

```
├── settings.gradle.kts / build.gradle.kts
├── src/main/kotlin/com/brellcar/
│   ├── domain/   # Models, Ports, SafetyPolicy (ядро, без UI)
│   ├── data/     # AdbCli, ProcessRunner, WindowsHotspot, LicenseClient, AppPaths,
│   │             # JsonRecipeRepository, JsonJournal, ApkInspector
│   └── app/      # AppModule(DI), Main(UI), mvi/* (Contract, ViewModel, RunRecipeUseCase), ui/*
├── src/test/     # SafetyPolicyTest, AppPathsTest, ApkInspectorTest (+ реальные манифесты в resources)
├── scripts-samples/   # рецепты *.json: russify, voice_tinove, apps_media, apps_tools, gsplit
└── .github/workflows/build.yml
```

Поставка (portable, рядом с exe):

```
BRELLCAR/
├── BRELLCAR.exe (+ app/, runtime/)
├── adb.exe  AdbWinApi.dll  AdbWinUsbApi.dll   <-- CI кладёт сам (platform-tools)
├── config.properties                          <-- скопируйте из config.properties.example
├── Apk/  tinove/  Scripts/                    <-- APK, ресурсы голоса, рецепты
├── Backups/   <-- создаётся сам: оригиналы APK и journal.json по серийнику ГУ
└── Logs/      <-- brellcar-ГГГГММДД.log
```

## Формат рецепта (`Scripts/*.json`)

```json
{
  "id": "gsplit", "title": "...", "description": "...",
  "requiredFeature": "gsplit", "group": "Система", "confirm": "доп. предупреждение",
  "supportedModels": [],
  "steps": [
    { "type": "install", "apk": "GSplit.apk", "force": false },
    { "type": "grant", "pkg": "com.salat.gsplit", "permission": "android.permission.WRITE_SECURE_SETTINGS" },
    { "type": "setting", "namespace": "global", "key": "enable_freeform_support", "value": "1" },
    { "type": "ime", "ime": "pkg/com.pkg.ImeService" },
    { "type": "push", "local": "timove", "remote": "/sdcard/timove" },
    { "type": "opensettings", "action": "android.settings.ACCESSIBILITY_SETTINGS" },
    { "type": "setappenabled", "pkg": "com.vendor.bloat", "enabled": false },
    { "type": "reboot" }
  ]
}
```

Битый JSON не пропадает молча: имя файла и причина попадают в журнал. Кнопка «Обновить рецепты» перечитывает `Scripts/` без перезапуска.

## Лицензионный сервер (FastAPI): контракт

`POST /api/v1/verify` → `{ "vin": "...", "serial": "..." }`
```json
{ "allowed": true, "vin": "...", "features": ["russify_cluster","voice","apps","gsplit"], "expires_at": null, "reason": null }
```
Клиент **fail-closed**: нет связи или HTTP-ошибка → всё заблокировано. Рецепты используют features
`russify_cluster`, `voice`, `apps`, `gsplit`; новые (`apps`, `gsplit`) сервер должен начать отдавать
(или поменяйте `requiredFeature` в нужных json).

## Защита от окирпичивания (SafetyPolicy)

Каждый shell/push/setting проходит `SafetyPolicy` **дважды** (в UseCase и в AdbCli):
- whitelist команд: `getprop settings pm am dumpsys input svc wm ime ls`;
- запрет `rm -rf`, `dd`, `mkfs`, `fastboot`, `reboot bootloader/recovery`, remount `/system`, `pm uninstall|clear|hide|suspend`, `cmd package`, `svc power`;
- отключать (`disable-user`) можно вендорские приложения, но не ядро Android; всё через журнал отката;
- push только в `/sdcard`, `/storage/emulated/0`, `/data/local/tmp`;
- запрет критических `setprop` и опасных `settings`-ключей;
- fail-fast: первая ошибка останавливает рецепт.

## Сборка

Нужны JDK 17 и Gradle 8.10+ (wrapper-jar в проекте нет).

```bash
gradle run                          # дев-запуск
gradle test                         # SafetyPolicy / AppPaths / ApkInspector
gradle createReleaseDistributable   # portable app-image
```

CI (`.github/workflows/build.yml`, кладётся в репо один раз): берёт ZIP проекта с наибольшей версией
(`BRELLCAR-vX.Y.Z-src.zip`), гоняет тесты, собирает app-image на `windows-latest`, докладывает свежий
`adb.exe`, `Apk/ tinove/ Scripts/`, пакует `BRELLCAR-vX.Y.Z-portable-win64.zip` + `.sha256`, публикует Release `vX.Y.Z`.

> `Apk/` и `tinove/` в исходниках пустые (`.gitkeep`): положите APK и ресурсы голоса в ZIP проекта перед заливкой.

## 2.3.0 — новый интерфейс
- Оранжевая тема на тёмном графите, окно сразу на весь экран, всё на одном экране без прокрутки.
- Шапка: название, версия, статус активации, «Настройки Android», «О программе» (быстрые кнопки открытия папок Apk/Scripts/Backups/Logs), виджет раздачи Wi‑Fi с тумблером.
- Две карточки статуса: ADB (с кнопками «Wi‑Fi ADB» и «Перезапуск ADB») и VIN/активация.
- Полоса прогресса всегда на виду.
- Операции — крупные плитки (вся плитка нажимается), справа журнал.
- Откат и перезагрузка ГУ — плитки с подтверждением.
