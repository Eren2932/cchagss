import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.0.21"
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.21"
    id("org.jetbrains.compose") version "1.7.1"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
}

group = "com.brellcar"
// Версия по умолчанию. CI переопределяет её переменной окружения APP_VERSION
// (из имени ZIP), чтобы версия в exe/манифесте/имени ZIP всегда совпадала.
// Env-переменная, а не -P: так версия не ломается парсингом аргументов в PowerShell/cmd.
val defaultAppVersion = "2.3.0"
version = System.getenv("APP_VERSION")?.takeIf { it.isNotBlank() } ?: defaultAppVersion

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.materialIconsExtended)

    // Корутины
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")

    // Ktor client — связь с FastAPI (лицензионный сервер)
    implementation("io.ktor:ktor-client-core:3.0.1")
    implementation("io.ktor:ktor-client-cio:3.0.1")
    implementation("io.ktor:ktor-client-content-negotiation:3.0.1")
    implementation("io.ktor:ktor-serialization-kotlinx-json:3.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    // Логирование
    implementation("io.github.oshai:kotlin-logging-jvm:7.0.0")
    implementation("org.slf4j:slf4j-simple:2.0.16")

    testImplementation(kotlin("test"))
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
}

tasks.test { useJUnitPlatform() }

kotlin { jvmToolchain(17) }

compose.desktop {
    application {
        mainClass = "com.brellcar.app.MainKt"

        // Версия попадает в приложение (заголовок окна/чип). Совпадает с версией ZIP.
        jvmArgs.add("-Dapp.version=${project.version}")

        nativeDistributions {
            // Для portable-раздачи нам по сути нужен просто рантайм + exe.
            // msi оставляем опционально, основная поставка — ZIP со структурой (см. CI).
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "BRELLCAR"
            packageVersion = version.toString()
            vendor = "BRELLCAR"
            // ТОЛЬКО ASCII: jpackage на Windows ломается на кириллице/юникоде в --description/--vendor
            description = "BRELLCAR 2.0 - ADB console for Changan head units"

            windows {
                // Стабильный UpgradeUuid — чтобы апдейты не плодили копии. Новый бренд = новый UUID; дальше НЕ МЕНЯТЬ.
                upgradeUuid = "B7E4C2A1-5D3F-4A8E-9C16-0F2D8B6E4A57"
                menuGroup = "BRELLCAR"
                console = false
                dirChooser = true
                perUserInstall = true
            }

            // Кладём ПОЛНЫЙ JRE. Урезанный (modules(...)) собирается без ошибок, но может упасть
            // уже при запуске у клиента (нет jdk.unsupported / java.instrument и т.п.), а проверить
            // это без запуска exe нельзя. Надёжность важнее ~40 МБ. Когда будет проверка на
            // реальной Windows, можно вернуть modules(...) через suggestRuntimeModules.
            includeAllModules = true
        }

        buildTypes.release.proguard {
            isEnabled.set(false) // Compose + ProGuard капризны; оставляем выкл для надёжности
        }
    }
}
