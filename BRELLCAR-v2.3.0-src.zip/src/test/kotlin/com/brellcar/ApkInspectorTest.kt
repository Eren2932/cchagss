package com.brellcar

import com.brellcar.data.ApkInspector
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Парсер манифестов проверяется на НАСТОЯЩИХ AndroidManifest.xml из ваших APK
 * (src/test/resources/manifests), а не на выдуманных данных.
 */
class ApkInspectorTest {

    private fun fixture(name: String): ByteArray =
        checkNotNull(javaClass.getResourceAsStream("/manifests/$name")) { "нет фикстуры $name" }.use { it.readBytes() }

    private fun apk(manifest: ByteArray, vararg extraEntries: String): File {
        val f = File.createTempFile("brellcar-test", ".apk")
        f.deleteOnExit()
        ZipOutputStream(f.outputStream()).use { z ->
            z.putNextEntry(ZipEntry("AndroidManifest.xml"))
            z.write(manifest)
            z.closeEntry()
            for (e in extraEntries) {
                z.putNextEntry(ZipEntry(e))
                z.write(1)
                z.closeEntry()
            }
        }
        return f
    }

    @Test fun `reads small manifest`() {
        val info = assertNotNull(ApkInspector.inspect(apk(fixture("start_settings.bin"))))
        assertEquals("alex161russ.launch_com.android.settings", info.packageName)
        assertEquals(1L, info.versionCode)
        assertEquals("1.0", info.versionName)
        assertEquals(21, info.minSdk)
        assertEquals(29, info.targetSdk)
        assertNull(info.sharedUserId)
        assertFalse(info.isSystemUid)
    }

    @Test fun `detects system uid of navigation mod`() {
        val info = assertNotNull(ApkInspector.inspect(apk(fixture("ChanganModRu.bin"))))
        assertEquals("com.neusoft.ya.navigation", info.packageName)
        assertEquals("android.uid.system", info.sharedUserId)
        assertTrue(info.isSystemUid)
        assertEquals(30, info.minSdk)
        assertEquals(2L, info.versionCode)
    }

    @Test fun `reads GSplit version and sdk`() {
        val info = assertNotNull(ApkInspector.inspect(apk(fixture("GSplit.bin"))))
        assertEquals("com.salat.gsplit", info.packageName)
        assertEquals(12400L, info.versionCode)
        assertEquals("1.2.4-Alpha", info.versionName)
        assertEquals(24, info.minSdk)
        assertEquals(34, info.targetSdk)
    }

    @Test fun `collects native abis from lib folders`() {
        val f = apk(fixture("GSplit.bin"), "lib/", "lib/arm64-v8a/liba.so", "lib/armeabi-v7a/liba.so", "classes.dex")
        val info = assertNotNull(ApkInspector.inspect(f))
        assertEquals(setOf("arm64-v8a", "armeabi-v7a"), info.abis)
    }

    @Test fun `garbage and truncated manifests give null instead of crash`() {
        assertNull(ApkInspector.inspect(apk(ByteArray(64) { 7 })))
        assertNull(ApkInspector.inspect(apk(fixture("GSplit.bin").copyOf(40))))
        val notZip = File.createTempFile("brellcar-test", ".apk").apply { deleteOnExit(); writeText("not a zip") }
        assertNull(ApkInspector.inspect(notZip))
        assertNull(ApkInspector.inspect(File("definitely-missing.apk")))
    }
}
