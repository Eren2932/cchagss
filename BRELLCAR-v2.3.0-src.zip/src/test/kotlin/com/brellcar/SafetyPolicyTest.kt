package com.brellcar

import com.brellcar.domain.RecipeStep
import com.brellcar.domain.SafetyPolicy
import com.brellcar.domain.SafetyPolicy.Decision
import kotlin.test.Test
import kotlin.test.assertTrue

class SafetyPolicyTest {

    private fun denied(d: Decision) = d is Decision.Denied
    private fun allowed(d: Decision) = d is Decision.Allowed

    // ── shell ──────────────────────────────────────────────────────────────

    @Test fun `allows whitelisted settings`() {
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("settings", "put", "system", "x", "1"))))
    }

    @Test fun `blocks rm -rf`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("rm", "-rf", "/system"))))
    }

    @Test fun `blocks pm uninstall`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "uninstall", "com.chinese.app"))))
    }

    @Test fun `blocks reboot bootloader`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("svc", "reboot", "bootloader"))))
    }

    @Test fun `blocks unknown shell head`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("busybox", "whatever"))))
    }

    @Test fun `blocks shell metacharacters (injection)`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("settings", "put", "system", "x", "1; reboot"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("getprop", "a|b"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("getprop", "\$(reboot)"))))
    }

    @Test fun `dangerous words are matched as whole words only`() {
        // Похожие слова НЕ должны давать ложных срабатываний:
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("settings", "put", "system", "date_format", "1"))))
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("am", "start", "-n", "com.x.flashlight/.Main"))))
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("dumpsys", "package", "com.x.add"))))
        // ...а настоящие опасные слова блокируются:
        assertTrue(denied(SafetyPolicy.checkShell(listOf("am", "start", "-a", "recovery"))))
    }

    // ── setprop / settings ─────────────────────────────────────────────────

    @Test fun `blocks critical setprop`() {
        assertTrue(denied(SafetyPolicy.checkSetprop("ro.boot.something")))
        assertTrue(allowed(SafetyPolicy.checkSetprop("persist.sys.my_flag")))
    }

    @Test fun `blocks dangerous settings keys`() {
        assertTrue(denied(SafetyPolicy.checkSetting("adb_enabled")))
        assertTrue(denied(SafetyPolicy.checkSetting("device_provisioned")))
        assertTrue(allowed(SafetyPolicy.checkSetting("screen_off_timeout")))
    }

    // ── push ───────────────────────────────────────────────────────────────

    @Test fun `blocks push into system`() {
        assertTrue(denied(SafetyPolicy.checkPush("/system/app/x.apk")))
        assertTrue(allowed(SafetyPolicy.checkPush("/sdcard/x.apk")))
    }

    @Test fun `blocks path traversal in push`() {
        assertTrue(denied(SafetyPolicy.checkPush("/sdcard/../system/x")))
        assertTrue(denied(SafetyPolicy.checkPush("/sdcard/a/../../data/x")))
    }

    // ── шаги рецепта ───────────────────────────────────────────────────────

    @Test fun `grant is validated`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(
            RecipeStep.Grant("ru.x.app", "android.permission.WRITE_SECURE_SETTINGS"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(
            RecipeStep.Grant("ru.x.app; reboot", "android.permission.X"))))
    }

    @Test fun `setting step is validated`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("system", "screen_off_timeout", "600000"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("system", "k", "1;reboot"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("system", "adb_enabled", "0"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("bogus", "k", "1"))))
    }

    @Test fun `install accepts only apk`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Install("voice/good.apk"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Install("evil.exe"))))
    }

    @Test fun `open settings and reboot are allowed, junk action is not`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.OpenSettings("android.settings.SETTINGS"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.OpenSettings("x && reboot"))))
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Reboot)))
    }

    // ── v2.2: закрытые дыры ────────────────────────────────────────────────

    @Test fun `cmd package no longer bypasses uninstall block`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("cmd", "package", "uninstall", "com.x.y"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("cmd", "wifi", "status"))))
    }

    @Test fun `pm destructive subcommands are blocked`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "clear", "com.neusoft.ya.navigation"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "hide", "com.x.y"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "uninstall-system-updates", "com.x.y"))))
    }

    @Test fun `android core cannot be disabled but vendor apps can`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "disable-user", "--user", "0", "com.android.systemui"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("pm", "disable-user", "--user", "0", "com.google.android.gms"))))
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("pm", "disable-user", "--user", "0", "com.vendor.bloat"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.SetAppEnabled("com.android.launcher3", false))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.SetAppEnabled("android", false))))
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.SetAppEnabled("com.vendor.bloat", false))))
        // включать можно любое
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.SetAppEnabled("com.android.launcher3", true))))
    }

    @Test fun `input and accessibility settings cannot be written raw`() {
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("secure", "default_input_method", "x/y"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("secure", "enabled_accessibility_services", "x/y"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("global", "adb_wifi_enabled", "0"))))
    }

    @Test fun `ime step only enables and validates id`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(
            RecipeStep.Ime("ru.yandex.androidkeyboard/com.android.inputmethod.latin.LatinIME"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Ime("no-slash"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Ime("a.b/c.D\$Inner"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Ime("a.b/c; reboot"))))
        assertTrue(allowed(SafetyPolicy.checkShell(listOf("ime", "enable", "a.b/c.D"))))
        assertTrue(denied(SafetyPolicy.checkShell(listOf("ime", "set", "a.b/c.D"))))
    }

    @Test fun `power off is blocked`() {
        assertTrue(denied(SafetyPolicy.checkShell(listOf("svc", "power", "shutdown"))))
    }

    // ── реальные шаги из шпаргалки GSplit и манифестов ─────────────────────

    @Test fun `gsplit cheat sheet steps are allowed`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("global", "enable_freeform_support", "1"))))
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Setting("global", "force_resizable_activities", "1"))))
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(
            RecipeStep.Grant("com.salat.gsplit", "android.permission.WRITE_SECURE_SETTINGS"))))
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.OpenSettings("android.settings.ACCESSIBILITY_SETTINGS"))))
    }

    @Test fun `tinove push target is allowed and system targets are not`() {
        assertTrue(allowed(SafetyPolicy.checkRecipeStep(RecipeStep.Push("timove", "/sdcard/timove"))))
        assertTrue(denied(SafetyPolicy.checkRecipeStep(RecipeStep.Push("timove", "/system/timove"))))
    }
}
