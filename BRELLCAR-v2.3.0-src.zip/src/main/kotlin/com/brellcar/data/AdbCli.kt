package com.brellcar.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import com.brellcar.domain.*
import java.io.File

/**
 * Реализация AdbPort поверх локального adb.exe.
 * ВАЖНО: все shell/push проходят проверку SafetyPolicy ЗДЕСЬ же, второй раз —
 * defence in depth. Даже если UI ошибётся, опасная команда не уйдёт на машину.
 */
class AdbCli(
    private val runner: ProcessRunner,
) : AdbPort {

    private val propLine = Regex("^\\[(.+?)\\]: \\[(.*)\\]\$")
    private val vinKey = Regex("(^|[._])vin([._]|\$)", RegexOption.IGNORE_CASE)
    private val pushFailure = Regex(
        "^(adb: (error|failed)|error:)|Permission denied|No such file or directory|Read-only file system",
        RegexOption.IGNORE_CASE,
    )
    private val pushSummary = Regex("(\\d+) files? pushed(?:, (\\d+) skipped)?")
    private val packageName = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+\$")
    private val remoteApkPath = Regex("^/[A-Za-z0-9._/~=@+\\-]{1,400}\$")
    private val hostPort = Regex("^(\\d{1,3}\\.){3}\\d{1,3}(:\\d{1,5})?\$")

    private fun adb(vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath) + args

    private fun adbSerial(serial: String, vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath, "-s", serial) + args

    override fun observeDevice(): Flow<HeadUnit> = flow {
        var last: HeadUnit? = null
        while (true) {
            val hu = try {
                poll(last)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Нет adb.exe / adb завис — не роняем приложение, показываем «Не подключено».
                HeadUnit(serial = "", state = AdbState.DISCONNECTED)
            }
            last = hu
            emit(hu)
            delay(2000)
        }
    }

    /**
     * Один опрос. Детали ГУ (VIN, модель, прошивка) читаем ОДИН раз на подключение,
     * а не каждые 2 секунды: иначе десяток adb-процессов в цикле нагружают ГУ и USB.
     */
    private suspend fun poll(last: HeadUnit?): HeadUnit {
        val res = runner.run(adb("devices", "-l"), timeoutSec = 10)
        val devices = res.stdout.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("*") && !it.startsWith("List of devices") }
            .map { line ->
                val cols = line.split(Regex("\\s+"))
                cols.first() to cols.getOrNull(1)
            }
            .toList()

        if (devices.isEmpty()) return HeadUnit(serial = "", state = AdbState.DISCONNECTED)

        // Больше одного устройства (телефон + ГУ, USB + устаревший Wi-Fi) → работа запрещена.
        // Раньше брался «первый попавшийся» — рецепт мог уйти не на ту машину.
        if (devices.size > 1) {
            return HeadUnit(serial = devices.joinToString(", ") { it.first }, state = AdbState.MULTIPLE)
        }

        val (serial, rawState) = devices.first()
        val state = when (rawState) {
            "device" -> AdbState.CONNECTED
            "unauthorized" -> AdbState.UNAUTHORIZED
            "offline" -> AdbState.OFFLINE
            else -> AdbState.CONNECTING
        }
        if (state != AdbState.CONNECTED) return HeadUnit(serial = serial, state = state)
        if (last != null && last.serial == serial && last.state == AdbState.CONNECTED) return last

        val abiList = getprop(serial, "ro.product.cpu.abilist") ?: getprop(serial, "ro.product.cpu.abi")
        return HeadUnit(
            serial = serial,
            state = state,
            vin = readVin(serial),
            model = readModel(serial),
            androidVersion = getprop(serial, "ro.build.version.release"),
            firmware = readFirmware(serial),
            sdk = getprop(serial, "ro.build.version.sdk")?.toIntOrNull(),
            abis = abiList?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList(),
        )
    }

    private suspend fun getprop(serial: String, key: String): String? =
        runner.run(adbSerial(serial, "shell", "getprop", key), timeoutSec = 10)
            .stdout.trim().ifBlank { null }

    override suspend fun readVin(serial: String): String? {
        // 1) Сканируем ВСЕ свойства: ищем ключ вида *.vin / vin_* со значением длиной 11..20.
        //    Точное имя свойства у разных ГУ отличается, поэтому не гадаем одно имя.
        val dump = runner.run(adbSerial(serial, "shell", "getprop"), timeoutSec = 15).stdout
        val fromDump = dump.lineSequence()
            .mapNotNull { line ->
                propLine.find(line.trim())?.let { it.groupValues[1] to it.groupValues[2].trim() }
            }
            .firstOrNull { (k, v) -> vinKey.containsMatchIn(k) && v.length in 11..20 }
            ?.second
        if (fromDump != null) return fromDump

        // 2) Запасной вариант — несколько известных имён.
        val candidates = listOf("persist.sys.vehicle.vin", "ro.vehicle.vin", "persist.vin")
        for (k in candidates) getprop(serial, k)?.let { if (it.length in 11..20) return it }
        return null
    }

    override suspend fun readModel(serial: String): String? =
        getprop(serial, "ro.product.model") ?: getprop(serial, "ro.product.device")

    override suspend fun readFirmware(serial: String): String? =
        getprop(serial, "ro.build.display.id") ?: getprop(serial, "ro.build.version.incremental")

    override suspend fun install(
        serial: String,
        apkPath: String,
        reinstall: Boolean,
        allowDowngrade: Boolean,
    ): AdbResult {
        val args = buildList {
            add("install")
            if (reinstall) add("-r")
            if (allowDowngrade) add("-d")
            add("-g") // сразу выдаём runtime-разрешения: на ГУ некому тапать диалоги
            add(apkPath)
        }
        val r = runner.run(adbSerial(serial, *args.toTypedArray()), timeoutSec = 600)
        val text = r.stdout + "\n" + r.stderr
        // Успех = exit 0 И слово Success: часть сборок adb возвращает 0 при Failure [...].
        val ok = r.exitCode == 0 && text.contains("Success", ignoreCase = true)
        if (ok) return AdbResult(true, r.stdout, r.stderr, 0, "install $apkPath")
        val code = Regex("INSTALL_[A-Z_]+").find(text)?.value
        val human = explainInstallFailure(code)
        val err = when {
            human != null -> "$human [$code]"
            code != null -> "$code"
            else -> r.stderr.ifBlank { r.stdout }
        }
        return AdbResult(false, r.stdout, err, if (r.exitCode == 0) 1 else r.exitCode, "install $apkPath")
    }

    private fun explainInstallFailure(code: String?): String? = when (code) {
        "INSTALL_FAILED_VERSION_DOWNGRADE" -> "На ГУ уже стоит более новая версия"
        "INSTALL_FAILED_UPDATE_INCOMPATIBLE" ->
            "Подпись APK не совпадает с установленной версией. Заменить приложение нельзя (удаление в BRELLCAR запрещено намеренно)"
        "INSTALL_FAILED_SHARED_USER_INCOMPATIBLE" ->
            "APK требует платформенную подпись (sharedUserId), у этого APK она не совпадает с ключом ГУ. На этой прошивке не установится"
        "INSTALL_FAILED_INSUFFICIENT_STORAGE" -> "Недостаточно места на ГУ"
        "INSTALL_FAILED_NO_MATCHING_ABIS" -> "APK собран под другую архитектуру процессора"
        "INSTALL_FAILED_OLDER_SDK" -> "Версия Android на ГУ слишком старая для этого APK"
        "INSTALL_FAILED_USER_RESTRICTED" -> "Установка запрещена настройками ГУ"
        "INSTALL_PARSE_FAILED_NO_CERTIFICATES", "INSTALL_PARSE_FAILED_NOT_APK" -> "APK повреждён или не подписан"
        else -> null
    }

    override suspend fun push(serial: String, localPath: String, remotePath: String): Flow<OpProgress> {
        val decision = SafetyPolicy.checkPush(remotePath)
        if (decision is SafetyPolicy.Decision.Denied) {
            return flow { emit(OpProgress("Push", 0, done = true, error = decision.reason)) }
        }
        val local = File(localPath)
        val isDir = local.isDirectory
        // Папку льём как «dir/.»: копируется СОДЕРЖИМОЕ в remotePath.
        // Без этого повторный push в существующую папку создаёт remote/dir/dir (дубль сотен МБ).
        val source = if (isDir) local.absolutePath.replace('\\', '/').trimEnd('/') + "/." else localPath
        val expected = if (isDir) local.walkTopDown().count { it.isFile } else 1
        return flow {
            val title = "Push $remotePath"
            emit(OpProgress(title, 0))
            var failure: String? = null
            var pushed = -1
            var skipped = 0
            runner.stream(adbSerial(serial, "push", source, remotePath)).collect { ln ->
                if (pushFailure.containsMatchIn(ln)) failure = ln
                pushSummary.find(ln)?.let { m ->
                    pushed = m.groupValues[1].toInt()
                    skipped = m.groupValues[2].toIntOrNull() ?: 0
                }
                val pct = Regex("(\\d+)%").find(ln)?.groupValues?.get(1)?.toIntOrNull()
                emit(OpProgress(title, pct ?: 50, line = ln))
            }
            // adb push не отдаёт exit code через стрим — ловим ошибку по тексту и сверяем число файлов.
            val f = failure
            val p = pushed
            val s = skipped
            when {
                f != null -> emit(OpProgress(title, 0, done = true, error = f))
                p >= 0 && p + s < expected ->
                    emit(OpProgress(title, 0, done = true,
                        error = "Передано файлов: $p (+$s пропущено) из $expected. Возможен обрыв кабеля"))
                else -> emit(OpProgress(title, 100, line = "Файлов передано: ${if (p >= 0) p else expected}", done = true))
            }
        }
    }

    override suspend fun grant(serial: String, pkg: String, permission: String): AdbResult =
        runner.run(adbSerial(serial, "shell", "pm", "grant", pkg, permission)).toResult("grant $pkg $permission")

    override suspend fun setAppEnabled(serial: String, pkg: String, enabled: Boolean): AdbResult {
        val verb = if (enabled) "enable" else "disable-user"
        if (!enabled) {
            // Второй рубеж: ядро Android отключить нельзя, даже если шаг прошёл мимо рецептов.
            val d = SafetyPolicy.checkRecipeStep(RecipeStep.SetAppEnabled(pkg, false))
            if (d is SafetyPolicy.Decision.Denied) return AdbResult(false, "", d.reason, -2, "pm $verb $pkg")
        }
        val args = if (enabled) listOf("shell", "pm", "enable", pkg)
                   else listOf("shell", "pm", "disable-user", "--user", "0", pkg)
        return runner.run(adbSerial(serial, *args.toTypedArray())).toResult("pm $verb $pkg")
    }

    override suspend fun openSettings(serial: String, action: String): AdbResult {
        val d = SafetyPolicy.checkRecipeStep(RecipeStep.OpenSettings(action))
        if (d is SafetyPolicy.Decision.Denied) return AdbResult(false, "", d.reason, -2, "am start $action")
        return runner.run(adbSerial(serial, "shell", "am", "start", "-a", action)).toResult("am start $action")
    }

    override suspend fun reboot(serial: String): AdbResult =
        runner.run(adbSerial(serial, "reboot"), timeoutSec = 20).toResult("reboot")

    override suspend fun installedVersion(serial: String, pkg: String): Long? {
        if (!packageName.matches(pkg)) return null
        val path = shell(serial, listOf("pm", "path", pkg))
        if (!path.stdout.contains("package:")) return null
        val dump = shell(serial, listOf("dumpsys", "package", pkg)).stdout
        // Пакет есть, а версию не разобрали → 0: «установлено, версия неизвестна».
        return Regex("versionCode=(\\d+)").find(dump)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
    }

    override suspend fun backupApk(serial: String, pkg: String, destDirPath: String): String? {
        if (!packageName.matches(pkg)) return null
        val paths = shell(serial, listOf("pm", "path", pkg)).stdout.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:") }
            .toList()
        val remote = paths.firstOrNull { it.endsWith("base.apk") } ?: paths.firstOrNull() ?: return null
        if (!remoteApkPath.matches(remote)) return null
        val dir = File(destDirPath).apply { mkdirs() }
        val local = File(dir, "$pkg-${System.currentTimeMillis()}.apk")
        val r = runner.run(adbSerial(serial, "pull", remote, local.absolutePath), timeoutSec = 600)
        return if (r.exitCode == 0 && local.exists() && local.length() > 0) local.absolutePath else null
    }

    override suspend fun getSetting(serial: String, namespace: String, key: String): String? {
        val r = shell(serial, listOf("settings", "get", namespace, key))
        if (!r.success) return null
        val v = r.stdout.trim()
        return if (v.isEmpty() || v == "null") null else v
    }

    override suspend fun connectTcp(hostPort: String): AdbResult {
        val trimmed = hostPort.trim()
        val target = if (trimmed.contains(':')) trimmed else "$trimmed:5555"
        if (!this.hostPort.matches(target)) {
            return AdbResult(false, "", "Адрес должен быть вида 192.168.137.2 или 192.168.137.2:5555", -1, "connect")
        }
        val r = runner.run(adb("connect", target), timeoutSec = 20)
        val text = r.stdout + "\n" + r.stderr
        val ok = r.exitCode == 0 &&
            Regex("(already )?connected to", RegexOption.IGNORE_CASE).containsMatchIn(text) &&
            !text.contains("cannot", ignoreCase = true) &&
            !text.contains("failed", ignoreCase = true)
        return AdbResult(ok, r.stdout, r.stderr, r.exitCode, "connect $target")
    }

    override suspend fun enableTcpip(serial: String, port: Int): AdbResult {
        if (port !in 1024..65535) return AdbResult(false, "", "Недопустимый порт", -1, "tcpip")
        return runner.run(adbSerial(serial, "tcpip", port.toString()), timeoutSec = 20).toResult("tcpip $port")
    }

    override suspend fun shell(serial: String, args: List<String>): AdbResult {
        val decision = SafetyPolicy.checkShell(args)
        if (decision is SafetyPolicy.Decision.Denied) {
            return AdbResult(false, "", decision.reason, -2, "shell ${args.joinToString(" ")}")
        }
        return runner.run(adbSerial(serial, "shell", *args.toTypedArray())).toResult("shell ${args.joinToString(" ")}")
    }

    override suspend fun killServer() { runner.run(adb("kill-server"), timeoutSec = 15) }
    override suspend fun startServer() { runner.run(adb("start-server"), timeoutSec = 30) }

    private fun ProcOutput.toResult(cmd: String) =
        AdbResult(exitCode == 0, stdout, stderr, exitCode, cmd)
}
