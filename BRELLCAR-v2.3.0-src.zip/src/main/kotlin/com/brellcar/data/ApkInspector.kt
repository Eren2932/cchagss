package com.brellcar.data

import com.brellcar.domain.ApkInfo
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipFile

/**
 * Читает метаданные APK прямо из бинарного AndroidManifest.xml (AXML) без aapt и без Android SDK.
 * Нужен для preflight: пакет/версия, minSdk, ABI, sharedUserId (android.uid.system = платформенная подпись).
 *
 * Любая ошибка разбора → null. Инспектор — ТОЛЬКО подсказка: он никогда не должен блокировать работу,
 * если файл нестандартный; жёсткие запреты живут в SafetyPolicy.
 */
object ApkInspector {

    private val PACKAGE_NAME = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+\$")

    private const val CHUNK_STRING_POOL = 0x0001
    private const val CHUNK_START_ELEMENT = 0x0102

    private const val TYPE_STRING = 0x03
    private const val TYPE_INT_DEC = 0x10
    private const val TYPE_INT_HEX = 0x11

    internal data class RawManifest(
        val pkg: String?,
        val versionCode: Long?,
        val versionName: String?,
        val sharedUserId: String?,
        val minSdk: Int?,
        val targetSdk: Int?,
    )

    fun inspect(apk: File): ApkInfo? {
        return try {
            ZipFile(apk).use { zip ->
                val entry = zip.getEntry("AndroidManifest.xml") ?: return@use null
                val bytes = zip.getInputStream(entry).use { it.readBytes() }
                val m = parseManifest(bytes) ?: return@use null
                val pkg = m.pkg?.takeIf { PACKAGE_NAME.matches(it) } ?: return@use null
                val abis = zip.entries().asSequence()
                    .map { it.name }
                    .filter { it.startsWith("lib/") }
                    .mapNotNull { it.split('/').getOrNull(1) }
                    .filter { it.isNotEmpty() }
                    .toSet()
                ApkInfo(
                    packageName = pkg,
                    versionCode = m.versionCode,
                    versionName = m.versionName,
                    sharedUserId = m.sharedUserId,
                    minSdk = m.minSdk,
                    targetSdk = m.targetSdk,
                    abis = abis,
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun u16(b: ByteBuffer, pos: Int): Int = b.getShort(pos).toInt() and 0xFFFF

    internal fun parseManifest(data: ByteArray): RawManifest? {
        if (data.size < 16) return null
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        var off = u16(b, 2) // размер заголовка файла
        val strings = ArrayList<String>()

        var pkg: String? = null
        var versionCode: Long? = null
        var versionName: String? = null
        var sharedUserId: String? = null
        var minSdk: Int? = null
        var targetSdk: Int? = null

        while (off + 8 <= data.size) {
            val type = u16(b, off)
            val chunkSize = b.getInt(off + 4)
            if (chunkSize <= 0) break

            if (type == CHUNK_STRING_POOL) {
                readStrings(b, off, strings)
            } else if (type == CHUNK_START_ELEMENT) {
                val tag = strings.getOrNull(b.getInt(off + 20))
                if (tag == "manifest" || tag == "uses-sdk") {
                    val attrStart = u16(b, off + 24)
                    val attrCount = u16(b, off + 28)
                    val base = off + 16 + attrStart
                    for (i in 0 until attrCount) {
                        val p = base + i * 20
                        val name = strings.getOrNull(b.getInt(p + 4)) ?: continue
                        val dataType = b.get(p + 15).toInt() and 0xFF
                        val raw = b.getInt(p + 16)
                        val asString: String? = if (dataType == TYPE_STRING) strings.getOrNull(raw) else null
                        val asInt: Long? =
                            if (dataType == TYPE_INT_DEC || dataType == TYPE_INT_HEX) raw.toLong() and 0xFFFFFFFFL else null
                        if (tag == "manifest") {
                            when (name) {
                                "package" -> pkg = asString
                                "versionCode" -> versionCode = asInt
                                "versionName" -> versionName = asString
                                "sharedUserId" -> sharedUserId = asString
                            }
                        } else {
                            when (name) {
                                "minSdkVersion" -> minSdk = asInt?.toInt()
                                "targetSdkVersion" -> targetSdk = asInt?.toInt()
                            }
                        }
                    }
                    // Нужные теги закончились: uses-sdk идёт сразу после manifest.
                    if (tag == "uses-sdk") break
                }
            }
            off += chunkSize
        }
        return RawManifest(pkg, versionCode, versionName, sharedUserId, minSdk, targetSdk)
    }

    private fun readStrings(b: ByteBuffer, off: Int, out: MutableList<String>) {
        val count = b.getInt(off + 8)
        val flags = b.getInt(off + 16)
        val stringsStart = b.getInt(off + 20)
        val utf8 = (flags and (1 shl 8)) != 0
        val base = off + stringsStart
        val array = b.array()
        for (i in 0 until count) {
            var p = base + b.getInt(off + 28 + i * 4)
            if (utf8) {
                var chars = b.get(p).toInt() and 0xFF
                p += 1
                if ((chars and 0x80) != 0) {
                    chars = ((chars and 0x7F) shl 8) or (b.get(p).toInt() and 0xFF)
                    p += 1
                }
                var bytes = b.get(p).toInt() and 0xFF
                p += 1
                if ((bytes and 0x80) != 0) {
                    bytes = ((bytes and 0x7F) shl 8) or (b.get(p).toInt() and 0xFF)
                    p += 1
                }
                out.add(String(array, p, bytes, Charsets.UTF_8))
            } else {
                var chars = u16(b, p)
                p += 2
                if ((chars and 0x8000) != 0) {
                    chars = ((chars and 0x7FFF) shl 16) or u16(b, p)
                    p += 2
                }
                out.add(String(array, p, chars * 2, Charsets.UTF_16LE))
            }
        }
    }
}
