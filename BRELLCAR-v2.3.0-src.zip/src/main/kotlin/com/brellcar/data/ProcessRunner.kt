package com.brellcar.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

data class ProcOutput(val exitCode: Int, val stdout: String, val stderr: String)

/**
 * Тонкая обёртка над ProcessBuilder. Один вход для всех внешних бинарников
 * (adb.exe, netsh, powershell). Таймаут обязателен — иначе зависший adb повесит UI.
 */
class ProcessRunner {

    suspend fun run(
        command: List<String>,
        workingDir: File? = null,
        timeoutSec: Long = 120,
    ): ProcOutput = withContext(Dispatchers.IO) {
        val pb = ProcessBuilder(command).apply {
            workingDir?.let { directory(it) }
        }
        val proc = pb.start()
        val out = proc.inputStream.bufferedReader()
        val err = proc.errorStream.bufferedReader()
        // Читаем в отдельных потоках, чтобы не словить deadlock на забитом буфере.
        val outText = StringBuilder()
        val errText = StringBuilder()
        val tOut = Thread { out.forEachLine { outText.appendLine(it) } }.apply { start() }
        val tErr = Thread { err.forEachLine { errText.appendLine(it) } }.apply { start() }

        val finished = proc.waitFor(timeoutSec, TimeUnit.SECONDS)
        if (!finished) {
            proc.destroyForcibly()
            tOut.join(1000); tErr.join(1000)
            return@withContext ProcOutput(-1, outText.toString(), "TIMEOUT после ${timeoutSec}s\n$errText")
        }
        tOut.join(); tErr.join()
        ProcOutput(proc.exitValue(), outText.toString().trim(), errText.toString().trim())
    }

    /** Стриминг построчного вывода (для push/install с прогрессом). */
    fun stream(command: List<String>, workingDir: File? = null): Flow<String> = callbackFlow {
        val proc = ProcessBuilder(command)
            .apply { workingDir?.let { directory(it) }; redirectErrorStream(true) }
            .start()
        val reader = proc.inputStream.bufferedReader()
        val t = Thread {
            try {
                reader.forEachLine { trySend(it) }
                proc.waitFor()
            } finally { close() }
        }.apply { start() }
        awaitClose { proc.destroy(); t.interrupt() }
    }.flowOn(Dispatchers.IO)
}
