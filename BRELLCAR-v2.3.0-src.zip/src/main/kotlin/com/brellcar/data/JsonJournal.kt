package com.brellcar.data

import com.brellcar.domain.JournalEntry
import com.brellcar.domain.JournalPort
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/**
 * Журнал изменений на ГУ: Backups/<serial>/journal.json.
 * Пишется ПЕРЕД каждым изменяющим шагом, поэтому откат возможен даже если приложение
 * упало или USB отвалился посреди рецепта.
 */
class JsonJournal : JournalPort {

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    @Serializable
    private data class Dto(
        val kind: String,
        val pkg: String? = null,
        val ns: String? = null,
        val key: String? = null,
        val prev: String? = null,
        val backup: String? = null,
    )

    private fun file(serial: String) = AppPaths.deviceBackupDir(serial).resolve("journal.json")

    @Synchronized
    override fun append(serial: String, entry: JournalEntry) {
        val all = entries(serial) + entry
        val f = file(serial)
        f.parentFile.mkdirs()
        val dtos = all.map { Dto(it.kind.name, it.pkg, it.ns, it.key, it.prev, it.backup) }
        // Пишем во временный файл и переименовываем: обрыв записи не убьёт старый журнал.
        val tmp = f.resolveSibling("journal.json.tmp")
        tmp.writeText(json.encodeToString(ListSerializer(Dto.serializer()), dtos))
        if (f.exists()) f.delete()
        tmp.renameTo(f)
    }

    @Synchronized
    override fun entries(serial: String): List<JournalEntry> {
        val f = file(serial)
        if (!f.exists()) return emptyList()
        return try {
            json.decodeFromString(ListSerializer(Dto.serializer()), f.readText()).mapNotNull { d ->
                val kind = runCatching { JournalEntry.Kind.valueOf(d.kind) }.getOrNull() ?: return@mapNotNull null
                JournalEntry(kind, d.pkg, d.ns, d.key, d.prev, d.backup)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    override fun clear(serial: String) {
        file(serial).delete()
    }
}
