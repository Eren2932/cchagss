package com.brellcar.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import com.brellcar.domain.Recipe
import com.brellcar.domain.RecipeLoad
import com.brellcar.domain.RecipeRepository
import com.brellcar.domain.RecipeStep

/**
 * Рецепты лежат в /Scripts/<имя>.json — так новые машины/патчи добавляются БЕЗ пересборки.
 * Каждый json — декларативное описание шагов. SafetyPolicy проверит каждый шаг.
 * Битый файл не пропадает молча: имя файла и причина уходят в RecipeLoad.errors (видно в журнале).
 */
class JsonRecipeRepository : RecipeRepository {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Serializable
    private data class RecipeDto(
        val id: String,
        val title: String,
        val description: String = "",
        val requiredFeature: String,
        val supportedModels: List<String> = emptyList(),
        val group: String = "Прочее",
        val confirm: String? = null,
        val steps: List<StepDto>,
    )

    @Serializable
    private data class StepDto(
        val type: String,
        val apk: String? = null,
        val reinstall: Boolean = true,
        val force: Boolean = false,
        val local: String? = null,
        val remote: String? = null,
        val pkg: String? = null,
        val permission: String? = null,
        val namespace: String? = null,
        val key: String? = null,
        val value: String? = null,
        val action: String? = null,
        val enabled: Boolean = true,
        val ime: String? = null,
    )

    override suspend fun loadAll(): RecipeLoad = withContext(Dispatchers.IO) {
        AppPaths.ensureDirs()
        val files = AppPaths.scriptsDir.listFiles { f -> f.extension.equals("json", true) } ?: emptyArray()
        val recipes = ArrayList<Recipe>()
        val errors = ArrayList<String>()
        for (f in files.sortedBy { it.name }) {
            try {
                recipes += json.decodeFromString<RecipeDto>(f.readText()).toDomain()
            } catch (e: Exception) {
                errors += "${f.name}: ${e.message?.lineSequence()?.firstOrNull() ?: e.javaClass.simpleName}"
            }
        }
        val ids = recipes.groupBy { it.id }.filter { it.value.size > 1 }.keys
        if (ids.isNotEmpty()) errors += "Повторяющиеся id рецептов: ${ids.joinToString()}"
        RecipeLoad(recipes.sortedWith(compareBy({ it.group }, { it.title })), errors)
    }

    private fun RecipeDto.toDomain() = Recipe(
        id = id, title = title, description = description,
        requiredFeature = requiredFeature,
        supportedModels = supportedModels.toSet(),
        steps = steps.mapIndexed { i, s -> s.toDomain(i + 1) },
        group = group,
        confirm = confirm,
    )

    private fun <T : Any> need(value: T?, field: String, step: Int, type: String): T =
        requireNotNull(value) { "шаг $step ($type): не задано поле \"$field\"" }

    private fun StepDto.toDomain(n: Int): RecipeStep = when (type.lowercase()) {
        "install" -> RecipeStep.Install(need(apk, "apk", n, type), reinstall, force)
        "push" -> RecipeStep.Push(need(local, "local", n, type), need(remote, "remote", n, type))
        "grant" -> RecipeStep.Grant(need(pkg, "pkg", n, type), need(permission, "permission", n, type))
        "setting" -> RecipeStep.Setting(namespace ?: "system", need(key, "key", n, type), need(value, "value", n, type))
        "opensettings" -> RecipeStep.OpenSettings(need(action, "action", n, type))
        "setappenabled" -> RecipeStep.SetAppEnabled(need(pkg, "pkg", n, type), enabled)
        "ime" -> RecipeStep.Ime(need(ime, "ime", n, type))
        "reboot" -> RecipeStep.Reboot
        else -> error("шаг $n: неизвестный тип \"$type\"")
    }
}
