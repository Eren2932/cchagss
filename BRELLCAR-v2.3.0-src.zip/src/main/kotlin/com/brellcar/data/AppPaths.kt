package com.brellcar.data

import java.io.File

/**
 * Portable-пути. Всё берём ОТНОСИТЕЛЬНО папки с exe, а не из рабочей директории,
 * иначе при запуске ярлыком пути поедут.
 *
 * Структура поставки:
 *   BRELLCAR/
 *     ├── BRELLCAR.exe (+ app/ runtime)
 *     ├── adb.exe, AdbWinApi.dll, AdbWinUsbApi.dll
 *     ├── Apk/
 *     ├── tinove/   (голосовой ассистент)
 *     ├── Scripts/  (*.json рецепты)
 *     ├── Backups/  (оригиналы APK и журнал отката по серийнику ГУ)
 *     └── Logs/     (brellcar-ГГГГММДД.log)
 */
object AppPaths {

    /** Папка, где лежит exe (или корень проекта при dev-запуске). */
    val root: File by lazy {
        val codeSource = runCatching {
            File(AppPaths::class.java.protectionDomain.codeSource.location.toURI())
        }.getOrNull()
        // В собранном дистрибутиве jar лежит в app/ — поднимаемся к exe.
        val fromJar = codeSource?.let { src ->
            var dir = if (src.isFile) src.parentFile else src
            if (dir.name.equals("app", ignoreCase = true)) dir = dir.parentFile
            dir
        }
        fromJar ?: File(System.getProperty("user.dir"))
    }

    val adbExe: File get() = root.resolve("adb.exe")
    val apkDir: File get() = root.resolve("Apk")
    val tinoveDir: File get() = root.resolve("tinove")
    val scriptsDir: File get() = root.resolve("Scripts")
    val backupsDir: File get() = root.resolve("Backups")
    val logsDir: File get() = root.resolve("Logs")

    /** Папка бэкапов конкретного ГУ. Серийник чистим: он может содержать ':' (adb по Wi-Fi). */
    fun deviceBackupDir(serial: String): File =
        backupsDir.resolve(serial.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "unknown" })

    fun ensureDirs() {
        listOf(apkDir, tinoveDir, scriptsDir, backupsDir, logsDir).forEach { if (!it.exists()) it.mkdirs() }
    }

    /**
     * Безопасно резолвим относительный путь внутри base (anti path-traversal).
     * Сравниваем с разделителем в конце: иначе "Apk2" считался бы "внутри Apk".
     */
    fun resolveInside(base: File, relative: String): File {
        val baseCanon = base.canonicalFile
        val f = baseCanon.resolve(relative).canonicalFile
        require(f == baseCanon || f.path.startsWith(baseCanon.path + File.separator)) {
            "Путь $relative выходит за пределы ${base.name}"
        }
        return f
    }
}
