package com.brellcar.data

import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import com.brellcar.domain.LicensePort
import com.brellcar.domain.LicenseVerdict

/**
 * Клиент твоего лицензионного сервера. Логика: UI по умолчанию заблокирован,
 * перед разблокировкой кнопок шлём {vin, serial} -> сервер отвечает, что разрешено.
 *
 * Безопасность: сервер — источник правды. Клиент НЕ хранит «вечную» разблокировку,
 * проверка идёт по VIN на каждую сессию. Фичи (features) приходят с сервера, так ты
 * сможешь продавать отдельно русификацию / Voice / удаление китайских прил.
 */
class LicenseClient(
    private val baseUrl: String,
    private val apiKey: String? = null,
) : LicensePort {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val client = HttpClient(CIO) {
        install(ContentNegotiation) { json(json) }
        install(HttpTimeout) {
            requestTimeoutMillis = 15_000
            connectTimeoutMillis = 10_000
        }
        expectSuccess = false
    }

    @Serializable
    private data class VerifyRequest(val vin: String, val serial: String)

    @Serializable
    private data class VerifyResponse(
        val allowed: Boolean,
        val vin: String,
        val features: List<String> = emptyList(),
        val expires_at: String? = null,
        val reason: String? = null,
    )

    override suspend fun verify(vin: String, serial: String): LicenseVerdict {
        return try {
            val resp: HttpResponse = client.post("$baseUrl/api/v1/verify") {
                contentType(ContentType.Application.Json)
                apiKey?.let { header("X-Api-Key", it) }
                setBody(VerifyRequest(vin, serial))
            }
            if (!resp.status.isSuccess()) {
                return LicenseVerdict(false, vin, reason = "Сервер: HTTP ${resp.status.value}")
            }
            val body = json.decodeFromString<VerifyResponse>(resp.bodyAsText())
            LicenseVerdict(
                allowed = body.allowed,
                vin = body.vin,
                features = body.features.toSet(),
                expiresAt = body.expires_at,
                reason = body.reason,
            )
        } catch (e: Exception) {
            // Fail-closed: нет связи с сервером = кнопки остаются заблокированы.
            LicenseVerdict(false, vin, reason = "Нет связи с сервером: ${e.message}")
        }
    }
}
