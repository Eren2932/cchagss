package com.brellcar.app.mvi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import com.brellcar.data.AppPaths
import com.brellcar.domain.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * MVI-вьюмодель: Intent -> (side effects) -> новый UiState.
 * Любое исключение в корутине ловим и пишем в лог. Иначе необработанная ошибка
 * (нет adb.exe, сломанный JSON, отвалился USB) роняет всё приложение.
 */
class MainViewModel(
    private val scope: CoroutineScope,
    private val adb: AdbPort,
    private val hotspot: HotspotPort,
    private val license: LicensePort,
    private val recipes: RecipeRepository,
    private val runRecipe: RunRecipeUseCase,
    private val journal: JournalPort,
    private val onOpenHotspotSettings: () -> Unit,
) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    /** Точку доступа включили МЫ → при закрытии программы выключим (не оставляем раздачу интернета открытой). */
    @Volatile private var hotspotStartedByUs = false

    private val logFile by lazy {
        AppPaths.logsDir.apply { mkdirs() }
            .resolve("brellcar-" + LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE) + ".log")
    }

    init {
        if (!AppPaths.adbExe.exists()) {
            log("adb.exe не найден: ${AppPaths.adbExe.absolutePath}. Положите его рядом с программой.")
        }
        launchSafe {
            adb.observeDevice().collect { hu ->
                var serialChanged = false
                _state.update { cur ->
                    // Другое устройство → старая лицензия недействительна, ожидающий запуск отменяется.
                    serialChanged = hu.serial != cur.device.serial || hu.state != cur.device.state
                    val changed = hu.serial != cur.device.serial
                    cur.copy(
                        device = hu,
                        license = if (changed) null else cur.license,
                        pending = if (changed) null else cur.pending,
                    )
                }
                if (serialChanged) refreshRollback()
            }
        }
        reloadRecipes()
        launchSafe { _state.update { it.copy(hotspotActive = hotspot.isActive()) } }
    }

    fun dispatch(intent: Intent) {
        when (intent) {
            Intent.VerifyLicense -> verify()
            Intent.ToggleHotspot -> toggleHotspot()
            Intent.OpenHotspotSettings -> onOpenHotspotSettings()
            is Intent.SetHotspot ->
                _state.update { it.copy(hotspotSsid = intent.ssid.take(32), hotspotPassword = intent.password.take(63)) }
            is Intent.RequestRun -> request(intent.recipe)
            Intent.ConfirmRun -> confirm()
            Intent.CancelRun -> _state.update { it.copy(pending = null) }
            Intent.Rollback -> rollback()
            Intent.RebootDevice -> withSerial { s -> launchBusy { adb.reboot(s).logTo() } }
            Intent.OpenAndroidSettings -> withSerial { s ->
                launchBusy { adb.openSettings(s, "android.settings.SETTINGS").logTo() }
            }
            Intent.RestartAdb -> launchSafe {
                adb.killServer()
                adb.startServer()
                log("ADB-сервер перезапущен")
            }
            Intent.ReloadRecipes -> reloadRecipes()
            Intent.ClearLog -> _state.update { it.copy(log = emptyList()) }
            is Intent.SetManualVin ->
                _state.update { it.copy(manualVin = intent.vin.take(17), license = null) }
            is Intent.SetWifiTarget -> _state.update { it.copy(wifiTarget = intent.value.take(21)) }
            Intent.ConnectWifi -> connectWifi()
            Intent.EnableTcpip -> withSerial { s ->
                launchBusy {
                    val r = adb.enableTcpip(s)
                    log("adb tcpip 5555: " + r.output.ifBlank { "ok" } +
                        ". Теперь введите IP ГУ и нажмите «Подключить по Wi‑Fi»")
                }
            }
        }
    }

    /** Вызывается при закрытии окна. */
    fun shutdown() {
        if (!hotspotStartedByUs) return
        runBlocking { withTimeoutOrNull(8_000) { hotspot.stop() } }
    }

    // ───────────────────────── операции ─────────────────────────

    private fun reloadRecipes() {
        launchSafe {
            val load = recipes.loadAll()
            _state.update { it.copy(recipes = load.recipes) }
            load.errors.forEach { log("Рецепт не загружен: $it") }
            log("Рецептов загружено: ${load.recipes.size}")
        }
    }

    private fun verify() {
        val st = _state.value
        val vin = st.vin
        if (!st.connected || vin.isNullOrBlank()) {
            log("Нельзя проверить лицензию: нет подключения или VIN")
            return
        }
        launchSafe {
            _state.update { it.copy(licenseChecking = true) }
            try {
                val verdict = license.verify(vin, st.device.serial)
                _state.update { it.copy(license = verdict) }
                log(if (verdict.allowed) "Лицензия подтверждена сервером" else "Лицензия не подтверждена: ${verdict.reason ?: "отказ сервера"}")
            } finally {
                _state.update { it.copy(licenseChecking = false) }
            }
        }
    }

    private fun toggleHotspot() {
        val s = _state.value
        if (s.busy) { log("Подождите, идёт другая операция"); return }
        launchBusy {
            val r = if (s.hotspotActive) hotspot.stop() else hotspot.start(s.hotspotSsid, s.hotspotPassword)
            val active = hotspot.isActive()
            if (active && !s.hotspotActive) hotspotStartedByUs = true
            if (!active) hotspotStartedByUs = false
            _state.update { it.copy(hotspotActive = active) }
            log("Хот-спот: " + r.output.ifBlank { if (active) "включён" else "выключен" })
        }
    }

    private fun connectWifi() {
        val s = _state.value
        if (s.busy) { log("Подождите, идёт другая операция"); return }
        launchBusy {
            val r = adb.connectTcp(s.wifiTarget)
            log(if (r.success) "ADB по Wi‑Fi: ${r.stdout.trim()}" else "ADB по Wi‑Fi: ${r.output.ifBlank { "не удалось подключиться" }}")
        }
    }

    /** Шаг 1: считаем риски и показываем диалог. На машине пока ничего не происходит. */
    private fun request(recipe: Recipe) {
        val st = _state.value
        if (st.busy) { log("Подождите, идёт другая операция"); return }
        val reason = st.disabledReason(recipe)
        if (reason != null) { log("Недоступно: ${recipe.title}. $reason"); return }
        val serial = st.device.serial
        launchSafe {
            val risks = withContext(Dispatchers.IO) { runRecipe.risks(recipe) }
            _state.update { it.copy(pending = PendingRun(recipe, risks, serial)) }
        }
    }

    /** Шаг 2: пользователь подтвердил. Проверяем, что устройство то же самое. */
    private fun confirm() {
        val st = _state.value
        val p = st.pending ?: return
        _state.update { it.copy(pending = null) }
        if (p.serial != st.device.serial || !st.isRecipeEnabled(p.recipe)) {
            log("Устройство или лицензия изменились, запуск отменён")
            return
        }
        if (st.busy) { log("Подождите, идёт другая операция"); return }
        launchBusy {
            log("Запуск: ${p.recipe.title}")
            _state.update { it.copy(progress = null) }
            runRecipe.run(st.device, p.recipe).collect { pr ->
                _state.update { it.copy(progress = pr) }
                if (pr.line.isNotBlank()) log(pr.line)
                pr.error?.let { log("ОШИБКА: $it") }
                if (pr.done && pr.error == null) log("Готово: ${p.recipe.title}")
            }
            refreshRollback()
        }
    }

    private fun rollback() {
        withSerial { s ->
            launchBusy {
                log("Откат изменений по журналу…")
                runRecipe.rollback(s).collect { pr ->
                    _state.update { it.copy(progress = pr) }
                    if (pr.line.isNotBlank()) log(pr.line)
                    pr.error?.let { log("ОШИБКА: $it") }
                }
                refreshRollback()
            }
        }
    }

    private fun refreshRollback() {
        val st = _state.value
        val serial = st.device.serial
        if (!st.connected) {
            _state.update { it.copy(canRollback = false) }
            return
        }
        launchSafe {
            val can = withContext(Dispatchers.IO) { journal.entries(serial).isNotEmpty() }
            _state.update { it.copy(canRollback = can) }
        }
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun withSerial(block: (String) -> Unit) {
        val st = _state.value
        when {
            !st.connected -> log("Устройство не подключено")
            st.busy -> log("Подождите, идёт другая операция")
            else -> block(st.device.serial)
        }
    }

    /** Запуск корутины, которая не может уронить приложение. */
    private fun launchSafe(block: suspend () -> Unit): Job = scope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            log("Ошибка: ${e.message ?: e::class.simpleName}")
        }
    }

    /** То же + флаг busy на время операции (блокирует кнопки). */
    private fun launchBusy(block: suspend () -> Unit): Job = launchSafe {
        _state.update { it.copy(busy = true) }
        try {
            block()
        } finally {
            _state.update { it.copy(busy = false) }
        }
    }

    private fun AdbResult.logTo() =
        log(if (success) "OK: $command" else "Ошибка ($exitCode): ${output.take(300)}")

    private fun log(line: String) {
        _state.update { it.copy(log = (it.log + "• $line").takeLast(500)) }
        // Тот же журнал — в файл Logs/brellcar-ГГГГММДД.log: пригодится при разборе «у меня не работает».
        try {
            logFile.appendText(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME).take(8) + " " + line + "\n")
        } catch (e: Exception) {
            // журнал в файл не критичен
        }
    }
}
