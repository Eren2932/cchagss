package com.brellcar.app.mvi

import com.brellcar.domain.*
import java.security.SecureRandom

private val VIN_REGEX = Regex("^[A-HJ-NPR-Z0-9]{17}\$")

/** Пароль точки доступа: случайный на каждый запуск (раньше был общеизвестный 12345678 на парковке). */
private fun randomPassword(length: Int = 10): String {
    val alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789" // без 0/O/1/l/I
    val rnd = SecureRandom()
    return buildString { repeat(length) { append(alphabet[rnd.nextInt(alphabet.length)]) } }
}

/** Запрос на запуск, ожидающий подтверждения пользователя. serial фиксируем, чтобы не запустить на другом ГУ. */
data class PendingRun(val recipe: Recipe, val risks: List<String>, val serial: String)

/** Единое состояние экрана (MVI). UI — чистая функция от этого state. */
data class UiState(
    val device: HeadUnit = HeadUnit("", AdbState.DISCONNECTED),
    val manualVin: String = "",
    val license: LicenseVerdict? = null,
    val licenseChecking: Boolean = false,
    val hotspotActive: Boolean = false,
    val hotspotSsid: String = "BRELLCAR",
    val hotspotPassword: String = randomPassword(),
    val wifiTarget: String = "",
    val recipes: List<Recipe> = emptyList(),
    val progress: OpProgress? = null,
    val log: List<String> = emptyList(),
    val busy: Boolean = false,
    val canRollback: Boolean = false,
    val pending: PendingRun? = null,
) {
    val connected: Boolean get() = device.state == AdbState.CONNECTED

    /** VIN: автоопределённый с ГУ, иначе введённый вручную (ровно 17 символов). */
    val vin: String? get() = device.vin ?: manualVin.trim().uppercase().takeIf { VIN_REGEX.matches(it) }

    val unlocked: Boolean get() = connected && license?.allowed == true

    /** Почему операция сейчас недоступна (null = доступна). Показывается прямо на плитке. */
    fun disabledReason(recipe: Recipe): String? {
        if (!connected) {
            return when (device.state) {
                AdbState.UNAUTHORIZED -> "Подтвердите отладку на экране ГУ"
                AdbState.MULTIPLE -> "Подключено несколько устройств"
                else -> "Подключите ГУ"
            }
        }
        val lic = license
        if (lic == null || !lic.allowed) return "Сначала проверьте лицензию"
        if (recipe.requiredFeature !in lic.features) return "Не входит в вашу лицензию"
        val model = device.model
        if (recipe.supportedModels.isNotEmpty() && model != null &&
            recipe.supportedModels.none { model.contains(it, ignoreCase = true) }
        ) return "Не для модели $model"
        return null
    }

    fun isRecipeEnabled(recipe: Recipe): Boolean = disabledReason(recipe) == null
}

/** Намерения пользователя. */
sealed interface Intent {
    data object VerifyLicense : Intent
    data object ToggleHotspot : Intent
    data object OpenHotspotSettings : Intent
    data class SetHotspot(val ssid: String, val password: String) : Intent

    /** Нажатие на плитку: показать подтверждение. Сам запуск — только после ConfirmRun. */
    data class RequestRun(val recipe: Recipe) : Intent
    data object ConfirmRun : Intent
    data object CancelRun : Intent

    data object Rollback : Intent
    data object RebootDevice : Intent
    data object OpenAndroidSettings : Intent
    data object RestartAdb : Intent
    data object ReloadRecipes : Intent
    data object ClearLog : Intent

    data class SetManualVin(val vin: String) : Intent
    data class SetWifiTarget(val value: String) : Intent
    data object ConnectWifi : Intent
    data object EnableTcpip : Intent
}
