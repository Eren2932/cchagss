package com.brellcar.app.mvi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.brellcar.data.ApkInspector
import com.brellcar.data.AppPaths
import com.brellcar.domain.*
import java.io.File

/**
 * Выполняет рецепт строго по шагам.
 *
 * Гарантии (anti-brick):
 *  1. Preflight ДО первого действия на машине: SafetyPolicy на каждый шаг, файлы на месте,
 *     APK совместим с ГУ (minSdk, ABI).
 *  2. Перед заменой установленного приложения оригинальный APK копируется в Backups/.
 *  3. Журнал изменений пишется на диск: откат возможен даже после обрыва USB.
 *  4. Первая же ошибка останавливает рецепт (fail-fast): половина рецепта не маскируется.
 *  5. Повторный запуск безопасен: одинаковые версии пропускаются, push не плодит дубли.
 */
class RunRecipeUseCase(
    private val adb: AdbPort,
    private val journal: JournalPort,
) {

    /** Предупреждения, которые видны пользователю в диалоге подтверждения ДО запуска. */
    fun risks(recipe: Recipe): List<String> {
        val out = ArrayList<String>()
        recipe.confirm?.let { out += it }
        for (step in recipe.steps) {
            when (step) {
                is RecipeStep.Install -> {
                    val info = apkInfo(step)
                    if (info != null && info.isSystemUid) {
                        out += "${info.packageName}: системный APK (sharedUserId=${info.sharedUserId}). " +
                            "Встанет только при совпадении платформенной подписи; оригинал будет сохранён в Backups."
                    }
                }
                is RecipeStep.SetAppEnabled ->
                    if (!step.enabled) out += "Будет отключено приложение ${step.pkg} (откат: кнопка «Откатить»)."
                RecipeStep.Reboot -> out += "ГУ перезагрузится."
                else -> {}
            }
        }
        return out
    }

    fun run(device: HeadUnit, recipe: Recipe): Flow<OpProgress> = flow {
        val serial = device.serial
        val total = recipe.steps.size

        val problem = preflight(device, recipe)
        if (problem != null) {
            emit(OpProgress(recipe.title, 0, done = true, error = problem))
            return@flow
        }

        recipe.steps.forEachIndexed { i, step ->
            val n = i + 1
            val base = (i * 100) / total
            val res: AdbResult? = when (step) {
                is RecipeStep.Install -> {
                    val apk = AppPaths.resolveInside(AppPaths.apkDir, step.apkRelPath)
                    val info = ApkInspector.inspect(apk)
                    val title = "Установка ${apk.name}"
                    emit(OpProgress(title, base))
                    var pending: JournalEntry? = null
                    var skip = false
                    if (info != null) {
                        val installed = adb.installedVersion(serial, info.packageName)
                        val newCode = info.versionCode
                        if (installed != null && !step.force && newCode != null && installed >= newCode) {
                            emit(OpProgress(title, base, line = "${apk.name}: уже установлено (versionCode $installed), пропускаю"))
                            skip = true
                        } else if (installed != null) {
                            val backup = adb.backupApk(serial, info.packageName, AppPaths.deviceBackupDir(serial).absolutePath)
                            if (backup == null && info.isSystemUid) {
                                emit(OpProgress(recipe.title, base, done = true,
                                    error = "Шаг $n: не удалось сохранить оригинал ${info.packageName}. Системный APK без бэкапа не заменяю"))
                                return@flow
                            }
                            emit(OpProgress(title, base, line =
                                if (backup != null) "Оригинал сохранён: $backup"
                                else "Оригинал ${info.packageName} сохранить не удалось, продолжаю (не системный)"))
                            pending = JournalEntry(JournalEntry.Kind.INSTALLED, pkg = info.packageName,
                                prev = installed.toString(), backup = backup)
                        } else {
                            pending = JournalEntry(JournalEntry.Kind.INSTALLED, pkg = info.packageName)
                        }
                    }
                    if (skip) {
                        null
                    } else {
                        val r = adb.install(serial, apk.absolutePath, step.reinstall)
                        if (r.success && info != null && adb.installedVersion(serial, info.packageName) == null) {
                            AdbResult(false, r.stdout,
                                "adb сообщил об успехе, но пакет ${info.packageName} на ГУ не найден", 1, r.command)
                        } else {
                            if (r.success && pending != null) journal.append(serial, pending)
                            r
                        }
                    }
                }
                is RecipeStep.Push -> {
                    val local = AppPaths.resolveInside(AppPaths.tinoveDir, step.localRelPath)
                    var pushError: String? = null
                    adb.push(serial, local.absolutePath, step.remotePath).collect { p ->
                        emit(p.copy(percent = base + (p.percent * (100 / total)) / 100))
                        if (p.error != null) pushError = p.error
                    }
                    val e = pushError
                    if (e != null) AdbResult(false, "", e, 1, "push ${step.remotePath}")
                    else AdbResult(true, "", "", 0, "push ${step.remotePath}")
                }
                is RecipeStep.Grant -> {
                    emit(OpProgress("Разрешение ${step.permission.substringAfterLast('.')}", base))
                    adb.grant(serial, step.pkg, step.permission)
                }
                is RecipeStep.Setting -> {
                    emit(OpProgress("Настройка ${step.key}", base))
                    val prev = adb.getSetting(serial, step.namespace, step.key)
                    val r = adb.shell(serial, listOf("settings", "put", step.namespace, step.key, step.value))
                    // Первое «прежнее» значение — истинный оригинал: повторный запуск его не перетирает.
                    val known = journal.entries(serial).any {
                        it.kind == JournalEntry.Kind.SETTING && it.ns == step.namespace && it.key == step.key
                    }
                    if (r.success && !known) {
                        journal.append(serial, JournalEntry(JournalEntry.Kind.SETTING,
                            ns = step.namespace, key = step.key, prev = prev))
                    }
                    r
                }
                is RecipeStep.OpenSettings -> {
                    emit(OpProgress("Открываю настройки", base))
                    adb.openSettings(serial, step.action)
                }
                is RecipeStep.SetAppEnabled -> {
                    emit(OpProgress("${if (step.enabled) "Включаю" else "Отключаю"} ${step.pkg}", base))
                    val r = adb.setAppEnabled(serial, step.pkg, step.enabled)
                    val known = journal.entries(serial).any {
                        it.kind == JournalEntry.Kind.DISABLED && it.pkg == step.pkg
                    }
                    if (r.success && !step.enabled && !known) {
                        journal.append(serial, JournalEntry(JournalEntry.Kind.DISABLED, pkg = step.pkg))
                    }
                    r
                }
                is RecipeStep.Ime -> {
                    emit(OpProgress("Включаю клавиатуру", base))
                    val r = adb.shell(serial, listOf("ime", "enable", step.id))
                    if (r.success && r.output.contains("unknown", ignoreCase = true)) r.copy(success = false) else r
                }
                RecipeStep.Reboot -> {
                    emit(OpProgress("Перезагрузка ГУ", base))
                    adb.reboot(serial)
                }
            }
            if (res != null && !res.success) {
                emit(OpProgress(recipe.title, base, done = true,
                    error = "Шаг $n из $total не выполнен: ${res.output.ifBlank { res.command }.take(300)}"))
                return@flow
            }
        }
        emit(OpProgress(recipe.title, 100, line = "Готово", done = true))
    }.flowOn(Dispatchers.IO)

    /** Откат по журналу в обратном порядке. Best-effort: ошибки одного пункта не останавливают остальные. */
    fun rollback(serial: String): Flow<OpProgress> = flow {
        val title = "Откат изменений"
        val entries = journal.entries(serial)
        if (entries.isEmpty()) {
            emit(OpProgress(title, 100, line = "Журнал пуст: откатывать нечего", done = true))
            return@flow
        }
        val reversed = entries.asReversed()
        var failures = 0
        reversed.forEachIndexed { i, e ->
            val pct = (i * 100) / reversed.size
            emit(OpProgress(title, pct))
            val res: AdbResult? = when (e.kind) {
                JournalEntry.Kind.SETTING -> {
                    val ns = e.ns
                    val key = e.key
                    val prev = e.prev
                    if (ns == null || key == null) null
                    else if (prev == null) adb.shell(serial, listOf("settings", "delete", ns, key))
                    else adb.shell(serial, listOf("settings", "put", ns, key, prev))
                }
                JournalEntry.Kind.DISABLED -> e.pkg?.let { adb.setAppEnabled(serial, it, true) }
                JournalEntry.Kind.INSTALLED -> {
                    val backup = e.backup
                    if (backup != null && File(backup).exists()) {
                        adb.install(serial, backup, reinstall = true, allowDowngrade = true)
                    } else {
                        emit(OpProgress(title, pct, line =
                            "${e.pkg}: это была новая установка, приложение оставлено (удаление запрещено политикой безопасности)"))
                        null
                    }
                }
            }
            if (res != null) {
                if (res.success) {
                    emit(OpProgress(title, pct, line = "Восстановлено: ${describe(e)}"))
                } else {
                    failures++
                    emit(OpProgress(title, pct, line = "Не удалось: ${describe(e)}. ${res.output.take(200)}"))
                }
            }
        }
        if (failures == 0) {
            journal.clear(serial)
            emit(OpProgress(title, 100, line = "Откат завершён", done = true))
        } else {
            emit(OpProgress(title, 100, done = true,
                error = "Откат выполнен не полностью (ошибок: $failures). Журнал сохранён, оригиналы APK лежат в Backups"))
        }
    }.flowOn(Dispatchers.IO)

    private fun describe(e: JournalEntry): String = when (e.kind) {
        JournalEntry.Kind.SETTING -> "настройка ${e.ns}/${e.key}"
        JournalEntry.Kind.DISABLED -> "приложение ${e.pkg} включено"
        JournalEntry.Kind.INSTALLED -> "приложение ${e.pkg}"
    }

    private fun apkInfo(step: RecipeStep.Install): ApkInfo? = try {
        ApkInspector.inspect(AppPaths.resolveInside(AppPaths.apkDir, step.apkRelPath))
    } catch (e: Exception) {
        null
    }

    private fun preflight(device: HeadUnit, recipe: Recipe): String? {
        recipe.steps.forEachIndexed { i, step ->
            val n = i + 1
            val decision = SafetyPolicy.checkRecipeStep(step)
            if (decision is SafetyPolicy.Decision.Denied) {
                return "Рецепт отклонён политикой безопасности (шаг $n): ${decision.reason}"
            }
            try {
                when (step) {
                    is RecipeStep.Install -> {
                        val apk = AppPaths.resolveInside(AppPaths.apkDir, step.apkRelPath)
                        if (!apk.exists()) return "Рецепт не запущен: нет файла «${apk.name}» в папке Apk (шаг $n)"
                        val info = ApkInspector.inspect(apk)
                        if (info != null) {
                            val problem = compatibility(device, apk.name, info)
                            if (problem != null) return "Рецепт не запущен (шаг $n): $problem"
                        }
                    }
                    is RecipeStep.Push -> {
                        val local = AppPaths.resolveInside(AppPaths.tinoveDir, step.localRelPath)
                        if (!local.exists()) return "Рецепт не запущен: нет «${local.name}» в папке tinove (шаг $n)"
                        if (local.isDirectory && local.walkTopDown().none { it.isFile })
                            return "Рецепт не запущен: папка «${local.name}» пуста (шаг $n)"
                    }
                    else -> {}
                }
            } catch (e: IllegalArgumentException) {
                return "Рецепт не запущен (шаг $n): ${e.message}"
            }
        }
        return null
    }

    private fun compatibility(device: HeadUnit, name: String, info: ApkInfo): String? {
        val sdk = device.sdk
        val min = info.minSdk
        if (sdk != null && min != null && min > sdk) return "$name требует Android API $min, на ГУ API $sdk"
        if (info.abis.isNotEmpty() && device.abis.isNotEmpty() && info.abis.none { it in device.abis }) {
            return "$name собран под ${info.abis.joinToString()}, ГУ поддерживает ${device.abis.joinToString()}"
        }
        return null
    }
}
