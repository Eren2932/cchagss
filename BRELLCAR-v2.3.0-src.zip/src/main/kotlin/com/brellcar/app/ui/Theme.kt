package com.brellcar.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * BRELLCAR 2.0: тёмный графит + оранжевый акцент.
 * Фон и карточки нейтральные (не устают глаза в салоне вечером), оранжевый — только там,
 * куда можно нажать и где идёт работа. Зелёный/красный остаются для статусов (ок/ошибка).
 */
object Palette {
    val Bg = Color(0xFF111214)          // фон окна
    val Surface = Color(0xFF1A1C20)     // карточки
    val SurfaceAlt = Color(0xFF22252B)  // плитки, поля ввода
    val SurfaceHi = Color(0xFF2A2E35)   // hover
    val Primary = Color(0xFFFF8A1F)     // основной оранжевый
    val PrimaryBright = Color(0xFFFFA64D)
    val PrimaryDeep = Color(0xFFB45309)
    val OnPrimary = Color(0xFF1C0F02)   // тёмный текст на оранжевой кнопке
    val Accent = Color(0xFFFFC58A)      // мягкий оранжевый для подписей/заголовков секций
    val Success = Color(0xFF4ADE80)
    val Danger = Color(0xFFF87171)
    val Warning = Color(0xFFFACC15)
    val TextPrimary = Color(0xFFF4F1EC)
    val TextMuted = Color(0xFF9CA0A8)
    val Border = Color(0xFF2E3138)
    val Console = Color(0xFF0C0D0F)

    // Цвета иконок плиток по группам (как на старом экране: у каждой операции свой оттенок)
    val TileOrange = Color(0xFFFF8A1F)
    val TileTeal = Color(0xFF2DD4BF)
    val TileViolet = Color(0xFFA78BFA)
    val TileBlue = Color(0xFF60A5FA)
    val TilePink = Color(0xFFF472B6)
    val TileRed = Color(0xFFF87171)
}

@Composable
fun BrellcarTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Palette.Primary,
        onPrimary = Palette.OnPrimary,
        primaryContainer = Palette.PrimaryDeep,
        secondary = Palette.Accent,
        background = Palette.Bg,
        surface = Palette.Surface,
        surfaceVariant = Palette.SurfaceAlt,
        onBackground = Palette.TextPrimary,
        onSurface = Palette.TextPrimary,
        onSurfaceVariant = Palette.TextMuted,
        outline = Palette.Border,
        error = Palette.Danger,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
