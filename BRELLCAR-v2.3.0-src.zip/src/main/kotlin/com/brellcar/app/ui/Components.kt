package com.brellcar.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Карточка-контейнер. */
@Composable
fun Panel(
    modifier: Modifier = Modifier,
    title: String? = null,
    trailing: (@Composable RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        color = Palette.Surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Palette.Border),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            if (title != null || trailing != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (title != null) CardLabel(title)
                    Spacer(Modifier.weight(1f))
                    trailing?.invoke(this)
                }
                Spacer(Modifier.height(8.dp))
            }
            content()
        }
    }
}

@Composable
fun CardLabel(text: String) {
    Text(text.uppercase(), color = Palette.TextMuted, fontSize = 11.sp,
        fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
}

@Composable
fun Pill(text: String, color: Color = Palette.Accent) {
    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
    }
}

/** Точка-индикатор статуса. */
@Composable
fun Dot(color: Color, size: Int = 9) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(color))
}

/** Квадратная иконка в цветной подложке (как на плитках старого экрана). */
@Composable
fun IconBadge(icon: ImageVector, accent: Color, active: Boolean = true, size: Int = 46) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = if (active) 0.18f else 0.07f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = if (active) accent else accent.copy(alpha = 0.4f),
            modifier = Modifier.size((size * 0.5f).dp))
    }
}

/** Главная кнопка: оранжевая заливка, тёмный текст. Высота ≥ 44dp — удобно попадать. */
@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 44.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Palette.Primary, contentColor = Palette.OnPrimary,
            disabledContainerColor = Palette.SurfaceAlt, disabledContentColor = Palette.TextMuted,
        ),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
    }
}

/** Вторичная кнопка: контур. */
@Composable
fun GhostButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val tint = if (danger) Palette.Danger else Palette.PrimaryBright
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 40.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tint, disabledContentColor = Palette.TextMuted),
        border = BorderStroke(1.dp, if (enabled) tint.copy(alpha = 0.55f) else Palette.Border),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
    }
}

fun iconForGroup(group: String): ImageVector = when {
    group.contains("русиф", ignoreCase = true) -> Icons.Filled.Translate
    group.contains("приложен", ignoreCase = true) -> Icons.Filled.Apps
    group.contains("голос", ignoreCase = true) -> Icons.Filled.RecordVoiceOver
    group.contains("систем", ignoreCase = true) -> Icons.Filled.Settings
    else -> Icons.Filled.Build
}

fun colorForGroup(group: String): Color = when {
    group.contains("русиф", ignoreCase = true) -> Palette.TileOrange
    group.contains("приложен", ignoreCase = true) -> Palette.TileTeal
    group.contains("голос", ignoreCase = true) -> Palette.TileViolet
    group.contains("систем", ignoreCase = true) -> Palette.TileBlue
    else -> Palette.TilePink
}

/**
 * Плитка операции: вся плитка — кнопка (не надо целиться в маленькую «Запустить»).
 * Если недоступна — вместо описания замок и причина.
 */
@Composable
fun ActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    lockedReason: String?,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
) {
    val enabled = lockedReason == null && !busy
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    val borderColor = when {
        enabled && hovered -> if (danger) Palette.Danger else Palette.Primary
        enabled -> Palette.Border
        else -> Palette.Border.copy(alpha = 0.6f)
    }
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(78.dp),
        shape = RoundedCornerShape(14.dp),
        color = if (enabled && hovered) Palette.SurfaceHi else if (enabled) Palette.SurfaceAlt else Palette.Surface,
        border = BorderStroke(1.dp, borderColor),
        interactionSource = interaction,
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, accent, active = lockedReason == null)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = if (lockedReason == null) Palette.TextPrimary else Palette.TextMuted,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                if (lockedReason != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = Palette.TextMuted,
                            modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(lockedReason, color = Palette.TextMuted, fontSize = 12.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                    }
                } else {
                    Text(subtitle, color = Palette.TextMuted, fontSize = 12.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.width(10.dp))
            if (enabled) {
                Box(
                    Modifier.size(36.dp).clip(CircleShape)
                        .background(if (danger) Palette.Danger.copy(alpha = 0.2f) else Palette.Primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = null,
                        tint = if (danger) Palette.Danger else Palette.OnPrimary, modifier = Modifier.size(22.dp))
                }
            } else {
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Palette.TextMuted.copy(alpha = 0.5f))
            }
        }
    }
}
