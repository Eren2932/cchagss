package com.brellcar.app

import androidx.compose.foundation.VerticalScrollbar
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.rememberScrollbarAdapter
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPlacement
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import com.brellcar.app.mvi.Intent
import com.brellcar.app.mvi.PendingRun
import com.brellcar.app.mvi.UiState
import com.brellcar.app.ui.*
import com.brellcar.data.AppPaths
import com.brellcar.domain.AdbState
import java.awt.Desktop
import java.awt.Dimension
import java.io.File

/** Версия приложения: build.gradle.kts передаёт её через -Dapp.version (совпадает с версией ZIP). */
private val appVersion: String = System.getProperty("app.version") ?: "dev"

/** Диалоги — локальное состояние экрана, бизнес-логики в них нет (всё уходит Intent'ами в VM). */
private enum class UiDialog { WIFI_ADB, HOTSPOT, REBOOT, ROLLBACK, ABOUT }

fun main() {
    AppPaths.ensureDirs()
    application {
        val scope = rememberCoroutineScope()
        val vm = remember { AppModule.provideViewModel(scope) }
        // Сразу на весь экран: в машине на ноутбуке ничего не должно уезжать за край.
        val windowState = rememberWindowState(placement = WindowPlacement.Maximized, width = 1366.dp, height = 820.dp)
        Window(
            // При закрытии гасим раздачу Wi-Fi, если включали мы.
            onCloseRequest = { vm.shutdown(); exitApplication() },
            state = windowState,
            title = "BRELLCAR 2.0",
        ) {
            LaunchedEffect(Unit) { window.minimumSize = Dimension(1180, 720) }
            BrellcarTheme {
                val state by vm.state.collectAsState()
                MainScreen(state, vm::dispatch)
            }
        }
    }
}

// ═════════════════════════ экран ═════════════════════════
// Один экран без прокрутки: шапка → статусы → прогресс → [плитки | журнал].
// Всё редкое (Wi-Fi ADB, настройки раздачи, о программе) — в диалогах, чтобы не загромождать.

@Composable
private fun MainScreen(state: UiState, onIntent: (Intent) -> Unit) {
    var dialog by remember { mutableStateOf<UiDialog?>(null) }
    Column(
        Modifier.fillMaxSize().background(Palette.Bg).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Header(state, onIntent, open = { dialog = it })
        Row(
            Modifier.fillMaxWidth().height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AdbStatusCard(state, onIntent, Modifier.weight(1f).fillMaxHeight(), openWifi = { dialog = UiDialog.WIFI_ADB })
            VinCard(state, onIntent, Modifier.weight(1f).fillMaxHeight())
        }
        ProgressStrip(state)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Operations(state, onIntent, Modifier.weight(1f).fillMaxHeight(), open = { dialog = it })
            LogPanel(state, onIntent, Modifier.width(420.dp).fillMaxHeight())
        }
    }

    state.pending?.let { ConfirmRunDialog(it, onIntent) }
    when (dialog) {
        UiDialog.WIFI_ADB -> WifiAdbDialog(state, onIntent) { dialog = null }
        UiDialog.HOTSPOT -> HotspotDialog(state, onIntent) { dialog = null }
        UiDialog.REBOOT -> SimpleConfirm(
            title = "Перезагрузить ГУ?",
            text = "Головное устройство перезагрузится, связь ADB пропадёт примерно на минуту.",
            action = "Перезагрузить", danger = true,
            onConfirm = { onIntent(Intent.RebootDevice); dialog = null },
            onDismiss = { dialog = null },
        )
        UiDialog.ROLLBACK -> SimpleConfirm(
            title = "Откатить изменения?",
            text = "Вернутся прежние значения настроек и включатся отключённые приложения. " +
                "Установленные приложения остаются, оригиналы заменённых APK лежат в папке Backups.",
            action = "Откатить", danger = false,
            onConfirm = { onIntent(Intent.Rollback); dialog = null },
            onDismiss = { dialog = null },
        )
        UiDialog.ABOUT -> AboutDialog { dialog = null }
        null -> Unit
    }
}

// ─────────────────────────── шапка ───────────────────────────

@Composable
private fun Header(state: UiState, onIntent: (Intent) -> Unit, open: (UiDialog) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("BRELLCAR", color = Palette.TextPrimary, fontSize = 28.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                Text(" 2.0", color = Palette.Primary, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Text("Русификация и настройка ГУ Changan", color = Palette.TextMuted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(14.dp))
        Pill("v$appVersion")
        Spacer(Modifier.width(8.dp))
        val lic = state.license
        when {
            lic == null -> Pill("Не активировано", Palette.TextMuted)
            lic.allowed -> Pill("Активировано", Palette.Success)
            else -> Pill("Отказ лицензии", Palette.Danger)
        }
        Spacer(Modifier.weight(1f))
        GhostButton("Настройки Android", icon = Icons.Filled.Settings,
            enabled = state.connected && !state.busy) { onIntent(Intent.OpenAndroidSettings) }
        Spacer(Modifier.width(8.dp))
        OutlinedIconButton(
            onClick = { open(UiDialog.ABOUT) },
            border = BorderStroke(1.dp, Palette.PrimaryBright.copy(alpha = 0.55f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.size(40.dp),
        ) { Icon(Icons.Filled.Info, contentDescription = "О программе", tint = Palette.PrimaryBright) }
        Spacer(Modifier.width(14.dp))
        HotspotWidget(state, onIntent, openSettings = { open(UiDialog.HOTSPOT) })
    }
}

private fun hotspotInputValid(state: UiState): Boolean =
    state.hotspotSsid.length in 1..32 &&
        state.hotspotPassword.length in 8..63 &&
        state.hotspotPassword.all { it.code in 32..126 }

/** Виджет раздачи как на старом экране, но с тумблером: включить/выключить в одно касание. */
@Composable
private fun HotspotWidget(state: UiState, onIntent: (Intent) -> Unit, openSettings: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val active = state.hotspotActive
    Surface(
        color = Palette.Surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (active) Palette.Success.copy(alpha = 0.6f) else Palette.Border),
        modifier = Modifier.width(340.dp),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Icons.Filled.Wifi, if (active) Palette.Success else Palette.Primary, size = 42)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Wi‑Fi с ПК", color = Palette.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Dot(if (active) Palette.Success else Palette.TextMuted, 7)
                    Spacer(Modifier.width(4.dp))
                    Text(if (active) "Активна" else "Выкл.", fontSize = 11.sp,
                        color = if (active) Palette.Success else Palette.TextMuted, fontWeight = FontWeight.SemiBold)
                }
                Text("Сеть: ${state.hotspotSsid}", color = Palette.TextMuted, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Пароль: ", color = Palette.TextMuted, fontSize = 12.sp)
                    Text(state.hotspotPassword, color = Palette.Primary, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.ContentCopy, contentDescription = "Копировать пароль", tint = Palette.TextMuted,
                        modifier = Modifier.size(14.dp).clip(RoundedCornerShape(4.dp))
                            .clickableNoRipple { clipboard.setText(AnnotatedString(state.hotspotPassword)) })
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Switch(
                    checked = active,
                    onCheckedChange = { onIntent(Intent.ToggleHotspot) },
                    enabled = !state.busy && (active || hotspotInputValid(state)),
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Palette.Primary, checkedThumbColor = Palette.OnPrimary,
                        uncheckedTrackColor = Palette.SurfaceAlt, uncheckedThumbColor = Palette.TextMuted,
                        uncheckedBorderColor = Palette.Border,
                    ),
                )
                IconButton(onClick = openSettings, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Filled.Tune, contentDescription = "Настройки раздачи", tint = Palette.TextMuted,
                        modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = src, indication = null, onClick = onClick)
}

// ─────────────────────────── статусы ───────────────────────────

@Composable
private fun AdbStatusCard(state: UiState, onIntent: (Intent) -> Unit, modifier: Modifier, openWifi: () -> Unit) {
    val d = state.device
    data class S(val icon: ImageVector, val color: Color, val label: String, val hint: String)
    val s = when (d.state) {
        AdbState.CONNECTED -> S(Icons.Filled.CheckCircle, Palette.Success, "Подключено",
            listOfNotNull(
                d.model,
                d.androidVersion?.let { a -> "Android $a" + (d.sdk?.let { " (API $it)" } ?: "") },
                d.serial.ifBlank { null },
            ).joinToString("  ·  ").ifBlank { "Устройство на связи" })
        AdbState.UNAUTHORIZED -> S(Icons.Filled.Warning, Palette.Warning, "Нужно разрешение",
            "Нажмите «Разрешить» в окне отладки на экране ГУ")
        AdbState.CONNECTING -> S(Icons.Filled.Sync, Palette.Warning, "Подключение…", "Ждём ответа от ГУ")
        AdbState.OFFLINE -> S(Icons.Filled.LinkOff, Palette.Danger, "Offline", "Переподключите кабель или нажмите «Перезапуск ADB»")
        AdbState.MULTIPLE -> S(Icons.Filled.Warning, Palette.Danger, "Несколько устройств",
            "Отключите лишние: ${d.serial}. Пока их больше одного, запуск заблокирован")
        AdbState.DISCONNECTED -> S(Icons.Filled.Cancel, Palette.Danger, "Не подключено",
            "Подключите ГУ кабелем USB или по Wi‑Fi")
    }
    Panel(modifier, title = "ADB статус") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(s.icon, contentDescription = null, tint = s.color, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.label, color = s.color, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(s.hint, color = Palette.TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(10.dp))
            GhostButton("Wi‑Fi ADB", icon = Icons.Filled.Wifi, enabled = !state.busy, onClick = openWifi)
            Spacer(Modifier.width(8.dp))
            GhostButton("Перезапуск ADB", icon = Icons.Filled.Refresh) { onIntent(Intent.RestartAdb) }
        }
    }
}

@Composable
private fun VinCard(state: UiState, onIntent: (Intent) -> Unit, modifier: Modifier) {
    val lic = state.license
    Panel(modifier, title = "VIN и активация") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                val vin = state.vin
                when {
                    !state.connected -> Text("—  Нет устройства", color = Palette.TextMuted,
                        fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    vin != null -> Text(vin, color = Palette.TextPrimary, fontSize = 19.sp,
                        fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    else -> Text("VIN не определён", color = Palette.Warning, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                val (c, t) = when {
                    lic == null && !state.connected -> Palette.TextMuted to "VIN определится автоматически после подключения"
                    lic == null && state.vin == null -> Palette.Warning to "Введите VIN вручную (17 символов)"
                    lic == null -> Palette.TextMuted to "Нажмите «Проверить активацию»"
                    lic.allowed -> Palette.Success to ("Активировано" + (lic.expiresAt?.let { " до $it" } ?: ""))
                    else -> Palette.Danger to (lic.reason ?: "Сервер отказал")
                }
                Text(t, color = c, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (state.connected && state.device.vin == null) {
                Spacer(Modifier.width(10.dp))
                OutlinedTextField(
                    value = state.manualVin,
                    onValueChange = { onIntent(Intent.SetManualVin(it)) },
                    placeholder = { Text("VIN вручную", fontSize = 13.sp) },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                    colors = fieldColors(),
                    modifier = Modifier.width(220.dp),
                )
            }
            Spacer(Modifier.width(10.dp))
            PrimaryButton(
                if (state.licenseChecking) "Проверяю…" else "Проверить активацию",
                icon = Icons.Filled.VerifiedUser,
                enabled = state.connected && state.vin != null && !state.licenseChecking,
            ) { onIntent(Intent.VerifyLicense) }
        }
    }
}

// ─────────────────────────── прогресс ───────────────────────────

@Composable
private fun ProgressStrip(state: UiState) {
    val p = state.progress
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val title = p?.title ?: if (state.busy) "Выполняется…" else "Готово к работе"
            Text(title, color = Palette.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(12.dp))
            val sub = when {
                p == null -> "Выберите операцию ниже"
                p.error != null -> p.error
                p.done -> "Готово"
                else -> p.line
            }
            Text(sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = when { p?.error != null -> Palette.Danger; p?.done == true -> Palette.Success; else -> Palette.TextMuted },
                modifier = Modifier.weight(1f))
            Text("${p?.percent?.coerceIn(0, 100) ?: 0}%", color = Palette.Primary, fontSize = 15.sp,
                fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { (p?.percent ?: 0).coerceIn(0, 100) / 100f },
            color = when { p?.error != null -> Palette.Danger; p?.done == true -> Palette.Success; else -> Palette.Primary },
            trackColor = Palette.SurfaceAlt,
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
        )
    }
}

// ─────────────────────────── операции ───────────────────────────

@Composable
private fun Operations(state: UiState, onIntent: (Intent) -> Unit, modifier: Modifier, open: (UiDialog) -> Unit) {
    val gridState = rememberLazyGridState()
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)) {
            CardLabel("Операции")
            Spacer(Modifier.width(8.dp))
            Text("${state.recipes.size}", color = Palette.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(
                "Обновить список", color = Palette.PrimaryBright, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(6.dp))
                    .clickableNoRipple { if (!state.busy) onIntent(Intent.ReloadRecipes) }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Box(Modifier.weight(1f)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                state = gridState,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().padding(end = 10.dp),
            ) {
                if (state.recipes.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Panel {
                            Text(
                                "Операции не найдены. Положите *.json в папку Scripts рядом с программой " +
                                    "(примеры — в scripts-samples) и нажмите «Обновить список».",
                                color = Palette.TextMuted, fontSize = 13.sp,
                            )
                        }
                    }
                }
                items(state.recipes) { recipe ->
                    ActionTile(
                        title = recipe.title,
                        subtitle = recipe.description.ifBlank { "Шагов: ${recipe.steps.size}" },
                        icon = iconForGroup(recipe.group),
                        accent = colorForGroup(recipe.group),
                        lockedReason = state.disabledReason(recipe),
                        busy = state.busy,
                        onClick = { onIntent(Intent.RequestRun(recipe)) },
                    )
                }
                item(key = "__rollback") {
                    ActionTile(
                        title = "Откатить изменения",
                        subtitle = "Вернуть настройки и отключённые приложения",
                        icon = Icons.Filled.Restore,
                        accent = Palette.TileBlue,
                        lockedReason = if (!state.canRollback) "Нет изменений для отката" else null,
                        busy = state.busy,
                        onClick = { open(UiDialog.ROLLBACK) },
                    )
                }
                item(key = "__reboot") {
                    ActionTile(
                        title = "Перезагрузить ГУ",
                        subtitle = "С подтверждением",
                        icon = Icons.Filled.PowerSettingsNew,
                        accent = Palette.TileRed,
                        lockedReason = if (!state.connected) "Подключите ГУ" else null,
                        busy = state.busy,
                        danger = true,
                        onClick = { open(UiDialog.REBOOT) },
                    )
                }
            }
            VerticalScrollbar(
                adapter = rememberScrollbarAdapter(gridState),
                modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight(),
            )
        }
    }
}

// ─────────────────────────── журнал ───────────────────────────

private fun logColor(line: String): Color = when {
    line.contains("ОШИБКА") || line.contains("Ошибка") || line.contains("Не удалось") ||
        line.contains("не удалось") || line.contains("не загружен") -> Palette.Danger
    line.contains("Готово") || line.contains("Восстановлено") || line.contains("подтверждена") ||
        line.startsWith("• OK") -> Palette.Success
    line.startsWith("• Запуск") -> Palette.Accent
    else -> Palette.TextMuted
}

@Composable
private fun LogPanel(state: UiState, onIntent: (Intent) -> Unit, modifier: Modifier) {
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    LaunchedEffect(state.log.size) {
        if (state.log.isNotEmpty()) listState.scrollToItem(state.log.lastIndex)
    }
    Panel(
        modifier,
        title = "Журнал",
        trailing = {
            IconButton(onClick = { clipboard.setText(AnnotatedString(state.log.joinToString("\n"))) },
                modifier = Modifier.size(30.dp)) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Копировать", tint = Palette.Accent,
                    modifier = Modifier.size(17.dp))
            }
            IconButton(onClick = { onIntent(Intent.ClearLog) }, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Filled.DeleteSweep, contentDescription = "Очистить", tint = Palette.Accent,
                    modifier = Modifier.size(18.dp))
            }
        },
    ) {
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .clip(RoundedCornerShape(10.dp)).background(Palette.Console).padding(10.dp),
        ) {
            if (state.log.isEmpty()) {
                Text("Здесь будет ход выполнения операций.\nКопия журнала пишется в папку Logs.",
                    color = Palette.TextMuted, fontSize = 12.sp)
            } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 8.dp)) {
                    items(state.log) { line ->
                        Text(line, color = logColor(line), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
                VerticalScrollbar(
                    adapter = rememberScrollbarAdapter(listState),
                    modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight(),
                )
            }
        }
    }
}

// ─────────────────────────── диалоги ───────────────────────────

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.Primary,
    unfocusedBorderColor = Palette.Border,
    disabledBorderColor = Palette.Border,
    focusedLabelColor = Palette.Primary,
    unfocusedLabelColor = Palette.TextMuted,
    disabledLabelColor = Palette.TextMuted,
    cursorColor = Palette.Primary,
    focusedTextColor = Palette.TextPrimary,
    unfocusedTextColor = Palette.TextPrimary,
    disabledTextColor = Palette.TextMuted,
    focusedPlaceholderColor = Palette.TextMuted,
    unfocusedPlaceholderColor = Palette.TextMuted,
)

@Composable
private fun BrellDialog(
    title: String,
    onDismiss: () -> Unit,
    confirm: @Composable () -> Unit,
    dismiss: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.TextPrimary,
        textContentColor = Palette.TextMuted,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.widthIn(min = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
        },
        confirmButton = confirm,
        dismissButton = dismiss,
    )
}

@Composable
private fun ConfirmRunDialog(p: PendingRun, onIntent: (Intent) -> Unit) {
    BrellDialog(
        title = p.recipe.title,
        onDismiss = { onIntent(Intent.CancelRun) },
        confirm = { PrimaryButton("Запустить", icon = Icons.Filled.PlayArrow) { onIntent(Intent.ConfirmRun) } },
        dismiss = { GhostButton("Отмена") { onIntent(Intent.CancelRun) } },
    ) {
        Text("Шагов: ${p.recipe.steps.size}. Перед заменой приложений оригиналы сохраняются в Backups, " +
            "изменения пишутся в журнал и откатываются плиткой «Откатить изменения».")
        p.risks.forEach { risk ->
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = Palette.Warning, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(risk, color = Palette.Warning, fontSize = 13.sp)
            }
        }
        Text("Не глушите машину и не отключайте кабель до завершения.", color = Palette.Accent)
    }
}

@Composable
private fun SimpleConfirm(
    title: String, text: String, action: String, danger: Boolean,
    onConfirm: () -> Unit, onDismiss: () -> Unit,
) {
    BrellDialog(
        title = title, onDismiss = onDismiss,
        confirm = {
            if (danger) GhostButton(action, danger = true, icon = Icons.Filled.PowerSettingsNew, onClick = onConfirm)
            else PrimaryButton(action, icon = Icons.Filled.Restore, onClick = onConfirm)
        },
        dismiss = { GhostButton("Отмена", onClick = onDismiss) },
    ) { Text(text) }
}

@Composable
private fun WifiAdbDialog(state: UiState, onIntent: (Intent) -> Unit, onClose: () -> Unit) {
    BrellDialog(
        title = "ADB по Wi‑Fi",
        onDismiss = onClose,
        confirm = { GhostButton("Закрыть", onClick = onClose) },
    ) {
        Text("1. Подключите ГУ кабелем USB и нажмите «Включить по USB» (adb tcpip 5555).\n" +
            "2. Подключите ГУ к той же сети (раздача с ПК: адрес обычно 192.168.137.x).\n" +
            "3. Введите IP ГУ и нажмите «Подключить по Wi‑Fi». Кабель можно отключать.")
        OutlinedTextField(
            value = state.wifiTarget,
            onValueChange = { onIntent(Intent.SetWifiTarget(it)) },
            label = { Text("IP ГУ, например 192.168.137.2") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton("Включить по USB", modifier = Modifier.weight(1f), icon = Icons.Filled.Usb,
                enabled = state.connected && !state.busy && !state.device.serial.contains(':'),
            ) { onIntent(Intent.EnableTcpip) }
            PrimaryButton("Подключить по Wi‑Fi", modifier = Modifier.weight(1f), icon = Icons.Filled.Wifi,
                enabled = !state.busy && state.wifiTarget.isNotBlank(),
            ) { onIntent(Intent.ConnectWifi) }
        }
    }
}

@Composable
private fun HotspotDialog(state: UiState, onIntent: (Intent) -> Unit, onClose: () -> Unit) {
    var showPassword by remember { mutableStateOf(true) }
    val locked = state.hotspotActive || state.busy
    BrellDialog(
        title = "Раздача Wi‑Fi с ПК",
        onDismiss = onClose,
        confirm = { PrimaryButton("Готово", onClick = onClose) },
    ) {
        if (state.hotspotActive) Text("Чтобы изменить имя или пароль, сначала выключите раздачу.", color = Palette.Warning)
        OutlinedTextField(
            value = state.hotspotSsid,
            onValueChange = { onIntent(Intent.SetHotspot(it, state.hotspotPassword)) },
            label = { Text("Имя сети (SSID)") },
            singleLine = true, enabled = !locked, isError = state.hotspotSsid.isEmpty(),
            colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = state.hotspotPassword,
            onValueChange = { onIntent(Intent.SetHotspot(state.hotspotSsid, it)) },
            label = { Text("Пароль") },
            singleLine = true, enabled = !locked,
            isError = state.hotspotPassword.length !in 8..63,
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = null, tint = Palette.TextMuted)
                }
            },
            supportingText = { Text("8–63 символа. По умолчанию — случайный на каждый запуск.") },
            colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
        )
        GhostButton("Открыть настройки Windows", icon = Icons.Filled.Settings) { onIntent(Intent.OpenHotspotSettings) }
    }
}

private fun openFolder(dir: File) {
    runCatching { dir.mkdirs(); Desktop.getDesktop().open(dir) }
}

@Composable
private fun AboutDialog(onClose: () -> Unit) {
    BrellDialog(
        title = "BRELLCAR 2.0  ·  v$appVersion",
        onDismiss = onClose,
        confirm = { PrimaryButton("Закрыть", onClick = onClose) },
    ) {
        Text("ADB-консоль для русификации и настройки головных устройств Changan.")
        Text("Папка программы: ${AppPaths.root.absolutePath}", fontSize = 12.sp)
        Text("APK кладутся в Apk, сценарии — в Scripts, голосовые ресурсы — в tinove.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton("Apk", icon = Icons.Filled.FolderOpen) { openFolder(AppPaths.apkDir) }
            GhostButton("Scripts", icon = Icons.Filled.FolderOpen) { openFolder(AppPaths.scriptsDir) }
            GhostButton("Backups", icon = Icons.Filled.FolderOpen) { openFolder(AppPaths.backupsDir) }
            GhostButton("Logs", icon = Icons.Filled.FolderOpen) { openFolder(AppPaths.logsDir) }
        }
    }
}
