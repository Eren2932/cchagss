package com.brellcar.domain

/** Статус ADB-подключения головного устройства. */
enum class AdbState {
    DISCONNECTED, UNAUTHORIZED, CONNECTING, CONNECTED, OFFLINE,

    /** Подключено больше одного устройства: работать нельзя, иначе рецепт уйдёт «не на ту машину». */
    MULTIPLE,
}

/** Подключённое головное устройство (ГУ) автомобиля. */
data class HeadUnit(
    val serial: String,          // adb serial (transport id)
    val state: AdbState,
    val vin: String? = null,     // читаем через getprop / настройки
    val model: String? = null,   // UNI-K, CS55+, Q07 ...
    val androidVersion: String? = null,
    val firmware: String? = null,
    val sdk: Int? = null,                       // ro.build.version.sdk (для проверки minSdk у APK)
    val abis: List<String> = emptyList(),       // ro.product.cpu.abilist (для проверки ABI у APK)
)

/** Результат любой ADB-операции — всегда с полным выводом для диагностики. */
data class AdbResult(
    val success: Boolean,
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val command: String,
) {
    val output: String get() = (stdout + "\n" + stderr).trim()
}

/** Прогресс длительной операции (push/install пакета рецептов). */
data class OpProgress(
    val title: String,
    val percent: Int,       // 0..100
    val line: String = "",
    val done: Boolean = false,
    val error: String? = null,
)

/** Ответ лицензионного сервера (FastAPI). */
data class LicenseVerdict(
    val allowed: Boolean,
    val vin: String,
    val features: Set<String> = emptySet(), // какие операции разрешены для этого VIN
    val expiresAt: String? = null,
    val reason: String? = null,
)

/** Описание одной операции прошивки — читается из /Scripts/<имя>.json (data-driven). */
data class Recipe(
    val id: String,
    val title: String,
    val description: String,
    val requiredFeature: String,       // что должен подтвердить сервер
    val supportedModels: Set<String>,  // пустое = все
    val steps: List<RecipeStep>,
    val group: String = "Прочее",      // секция в UI
    val confirm: String? = null,       // доп. предупреждение в диалоге подтверждения
)

sealed interface RecipeStep {
    /**
     * Установка APK из /Apk (путь относительный).
     * force=false: если на ГУ уже стоит такая же или более новая версия — шаг пропускается.
     */
    data class Install(
        val apkRelPath: String,
        val reinstall: Boolean = true,
        val force: Boolean = false,
    ) : RecipeStep
    /** Заливка ресурсов: /tinove/<local> -> remote. Для папок копируется СОДЕРЖИМОЕ (идемпотентно). */
    data class Push(val localRelPath: String, val remotePath: String) : RecipeStep
    /** Выдача runtime-разрешения приложению. */
    data class Grant(val pkg: String, val permission: String) : RecipeStep
    /** Безопасная системная настройка (проходит через SafetyPolicy, старое значение пишется в журнал). */
    data class Setting(val namespace: String, val key: String, val value: String) : RecipeStep
    /** Открыть штатный системный экран. */
    data class OpenSettings(val action: String) : RecipeStep
    /** Запуск/остановка пакета (напр. отключить китайский лаунчер, НЕ удаляя). */
    data class SetAppEnabled(val pkg: String, val enabled: Boolean) : RecipeStep
    /** Включить (НЕ делать по умолчанию) клавиатуру: id вида `pkg/com.pkg.Service`. */
    data class Ime(val id: String) : RecipeStep
    /** Перезагрузка ГУ. */
    data object Reboot : RecipeStep
}

/** Метаданные APK, прочитанные из его AndroidManifest.xml. */
data class ApkInfo(
    val packageName: String,
    val versionCode: Long?,
    val versionName: String?,
    val sharedUserId: String?,
    val minSdk: Int?,
    val targetSdk: Int?,
    val abis: Set<String>,       // из lib/<abi>/; пусто = нативных библиотек нет (подходит всем)
) {
    /** android.uid.system и т.п.: приложение подписано платформенным ключом ГУ. */
    val isSystemUid: Boolean get() = sharedUserId?.startsWith("android.uid.") == true
}

/** Запись журнала изменений: по ней делается откат. */
data class JournalEntry(
    val kind: Kind,
    val pkg: String? = null,
    val ns: String? = null,
    val key: String? = null,
    val prev: String? = null,     // прежнее значение настройки / прежний versionCode
    val backup: String? = null,   // путь к сохранённому оригинальному APK
) {
    enum class Kind { INSTALLED, SETTING, DISABLED }
}
