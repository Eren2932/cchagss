package com.brellcar.domain

import kotlinx.coroutines.flow.Flow

/** Абстракция над adb.exe. Реализация — в слое data. */
interface AdbPort {
    /** Поток статуса устройства (поллинг adb devices + getprop). */
    fun observeDevice(): Flow<HeadUnit>

    suspend fun readVin(serial: String): String?
    suspend fun readModel(serial: String): String?
    suspend fun readFirmware(serial: String): String?

    suspend fun install(serial: String, apkPath: String, reinstall: Boolean, allowDowngrade: Boolean = false): AdbResult
    suspend fun push(serial: String, localPath: String, remotePath: String): Flow<OpProgress>
    suspend fun grant(serial: String, pkg: String, permission: String): AdbResult
    suspend fun setAppEnabled(serial: String, pkg: String, enabled: Boolean): AdbResult
    suspend fun openSettings(serial: String, action: String): AdbResult
    suspend fun reboot(serial: String): AdbResult

    /** versionCode установленного пакета; null — пакета на ГУ нет. */
    suspend fun installedVersion(serial: String, pkg: String): Long?

    /** Копирует установленный APK пакета в destDir. Возвращает путь к файлу или null. */
    suspend fun backupApk(serial: String, pkg: String, destDirPath: String): String?

    /** Текущее значение настройки; null — не задана. */
    suspend fun getSetting(serial: String, namespace: String, key: String): String?

    /** `adb connect host:port` (ГУ по Wi-Fi). */
    suspend fun connectTcp(hostPort: String): AdbResult

    /** `adb tcpip 5555` на USB-подключённом ГУ, чтобы дальше работать по Wi-Fi. */
    suspend fun enableTcpip(serial: String, port: Int = 5555): AdbResult

    /** Любая shell-команда. Реализация сама проходит через SafetyPolicy. */
    suspend fun shell(serial: String, args: List<String>): AdbResult

    suspend fun killServer()
    suspend fun startServer()
}

/** Windows Mobile Hotspot. */
interface HotspotPort {
    suspend fun start(ssid: String, password: String): AdbResult
    suspend fun stop(): AdbResult
    suspend fun isActive(): Boolean
}

/** Лицензионный сервер. */
interface LicensePort {
    suspend fun verify(vin: String, serial: String): LicenseVerdict
}

/** Результат загрузки рецептов: битые файлы не теряются молча, а попадают в errors. */
data class RecipeLoad(val recipes: List<Recipe>, val errors: List<String>)

/** Загрузка рецептов из /Scripts. */
interface RecipeRepository {
    suspend fun loadAll(): RecipeLoad
}

/** Журнал изменений на конкретном ГУ (для отката). */
interface JournalPort {
    fun append(serial: String, entry: JournalEntry)
    fun entries(serial: String): List<JournalEntry>
    fun clear(serial: String)
}
