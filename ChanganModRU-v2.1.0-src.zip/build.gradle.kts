import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.0.21"
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.21"
    id("org.jetbrains.compose") version "1.7.1"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
}

group = "ru.changanmod"
// Версия по умолчанию. CI переопределяет её через -PappVersion=X.Y.Z (из git-тега),
// чтобы версия в exe/манифесте/имени ZIP всегда совпадала.
version = providers.gradleProperty("appVersion").getOrElse("2.1.0")

repositories {
    google()
    mavenCentral()
    maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.materialIconsExtended)

    // Корутины
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")

    // Ktor client — связь с FastAPI (лицензионный сервер)
    implementation("io.ktor:ktor-client-core:3.0.1")
    implementation("io.ktor:ktor-client-cio:3.0.1")
    implementation("io.ktor:ktor-client-content-negotiation:3.0.1")
    implementation("io.ktor:ktor-serialization-kotlinx-json:3.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    // Логирование
    implementation("io.github.oshai:kotlin-logging-jvm:7.0.0")
    implementation("org.slf4j:slf4j-simple:2.0.16")

    testImplementation(kotlin("test"))
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
}

tasks.test { useJUnitPlatform() }

kotlin { jvmToolchain(17) }

compose.desktop {
    application {
        mainClass = "ru.changanmod.app.MainKt"

        nativeDistributions {
            // Для portable-раздачи нам по сути нужен просто рантайм + exe.
            // msi оставляем опционально, основная поставка — ZIP со структурой (см. CI).
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "ChanganModRU"
            packageVersion = version.toString()
            vendor = "ChanganModRU"
            description = "ChanganModRU — ADB management console"

            windows {
                // Стабильный UpgradeUuid — чтобы апдейты не плодили копии
                upgradeUuid = "8E7F2A10-4B3C-4D1E-9A6F-2C5B7D8E1F23"
                menuGroup = "ChanganModRU"
                console = false
                dirChooser = true
                perUserInstall = true
            }

            // Урезаем JRE, чтобы exe был лёгким
            modules("java.base", "java.desktop", "java.logging", "java.naming", "jdk.crypto.ec")
        }

        buildTypes.release.proguard {
            isEnabled.set(false) // Compose + ProGuard капризны; оставляем выкл для надёжности
        }
    }
}
