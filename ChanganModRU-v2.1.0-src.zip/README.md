# ChanganModRU — ADB management console (Compose Desktop)

Portable-приложение под Windows для управления Android-головой автомобиля через локальный `adb.exe`.
Чистая архитектура (domain / data / app) + MVI. UI по умолчанию заблокирован, разблокировка — по подтверждению сервера.

> ⚠️ Важно про границы: это приложение **не вскрывает инженерное меню и не обходит активацию ADB**.
> Оно работает уже с подключённым (авторизованным) ГУ. Код инженерного меню по VIN — отдельная история,
> в проект не входит.

## Структура

```
changanmod/
├── settings.gradle.kts
├── build.gradle.kts
├── src/main/kotlin/ru/changanmod/
│   ├── domain/   # Models, Ports, SafetyPolicy  (без зависимостей — ядро)
│   ├── data/     # AdbCli, ProcessRunner, WindowsHotspot, LicenseClient, AppPaths, JsonRecipeRepository
│   └── app/      # AppModule(DI), Main(UI), mvi/*, ui/*
├── src/test/...  # SafetyPolicyTest
├── scripts-samples/  # примеры рецептов *.json
└── .github/workflows/build.yml
```

Структура **собранной поставки** (portable, рядом с exe):

```
ChanganModRU/
├── ChanganModRU.exe  (+ app/ и runtime/ от jpackage)
├── adb.exe  AdbWinApi.dll  AdbWinUsbApi.dll   <-- кладёшь сам (бинарники не в git)
├── config.properties                          <-- license.baseUrl твоего сервера
├── Apk/        <-- сюда .apk для установки
├── tinove/     <-- ресурсы голосового ассистента (push)
└── Scripts/    <-- *.json рецепты операций
```

## Как настроить build.gradle.kts под Windows (ключевое)

1. **Плагины**: `org.jetbrains.compose` + `org.jetbrains.kotlin.plugin.compose` (для Kotlin 2.x compose-компилятор вынесен в отдельный плагин — без него не соберётся).
2. **JDK 17** через `jvmToolchain(17)` — jpackage требует JDK, не JRE.
3. **Формат поставки**: в CI мы используем не `.msi`, а **app-image** (`createReleaseDistributable`) — это и есть portable: папка с exe + урезанный рантайм, которую мы зипуем вместе с `/Apk`, `/tinove`, `/Scripts`. `targetFormats(Msi, Exe)` оставлен на случай, если захочешь ещё и инсталлятор.
4. **modules(...)** — вручную перечислены JRE-модули, чтобы exe не тащил всю Java (иначе ~200 МБ).
5. **ProGuard выключен** — Compose + обфускация часто падают; для надёжности оставляем off.

## Локальная сборка

```bash
cd changanmod
./gradlew run                       # запустить дев-версию
./gradlew createReleaseDistributable  # собрать portable app-image
./gradlew test                      # прогнать тесты SafetyPolicy
```

Готовый app-image: `build/compose/binaries/main-release/app/ChanganModRU/`.
Положи туда `adb.exe` + папки `Apk/ tinove/ Scripts/` — и это рабочая portable-сборка.

## CI/CD

`.github/workflows/build.yml`:
- триггерится на тег `vX.Y.Z` или вручную (`workflow_dispatch`);
- собирает app-image на `windows-latest`;
- доклеивает пустые `/Apk`, `/tinove`, `/Scripts` + `config.properties` + пример рецепта;
- зипует в `ChanganModRU-portable.zip`;
- по тегу — публикует как Release-артефакт.

`adb.exe` намеренно не коммитим (бинарь/лицензия платформенных tools). Либо положи в `tools/` и раскомментируй копирование в workflow, либо докидывай в zip после.

## Лицензионный сервер (FastAPI) — контракт

`POST /api/v1/verify`  →  `{ "vin": "...", "serial": "..." }`
Ответ:
```json
{ "allowed": true, "vin": "...", "features": ["russify_cluster","voice"], "expires_at": null, "reason": null }
```
Клиент **fail-closed**: нет связи/HTTP-ошибка — кнопки остаются заблокированы. `features` управляют тем,
какие операции разрешены — так ты продаёшь активации по отдельным функциям и по VIN.

## Защита от окирпичивания (SafetyPolicy)

Любой shell/push/setting проходит `SafetyPolicy` **дважды** (в UseCase и в AdbCli):
- whitelist корневых команд: `getprop settings pm am dumpsys input cmd svc wm`;
- запрет `rm -rf`, `dd`, `mkfs`, `fastboot`, `reboot bootloader/recovery`, remount `/system`;
- `pm uninstall` запрещён — только `disable-user` (китайские прил. отключаем, не удаляем → откатываемо);
- push только в `/sdcard`, `/storage/emulated/0`, `/data/local/tmp` — не в `/system`, `/vendor`;
- запрет критических `setprop` (`ro.boot*`, `ro.product*`, `sys.powerctl`, …);
- рецепт исполняется fail-fast: первый провал/запрет останавливает всю цепочку.
