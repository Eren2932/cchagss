package ru.changanmod.data

import java.io.File

/**
 * Portable-пути. Всё берём ОТНОСИТЕЛЬНО папки с exe, а не из рабочей директории,
 * иначе при запуске ярлыком пути поедут.
 *
 * Структура поставки:
 *   ChanganModRU/
 *     ├── ChanganModRU.exe (+ app/ runtime)
 *     ├── adb.exe, AdbWinApi.dll, AdbWinUsbApi.dll
 *     ├── Apk/
 *     ├── tinove/   (голосовой ассистент)
 *     └── Scripts/  (*.json рецепты)
 */
object AppPaths {

    /** Папка, где лежит exe (или корень проекта при dev-запуске). */
    val root: File by lazy {
        val codeSource = runCatching {
            File(AppPaths::class.java.protectionDomain.codeSource.location.toURI())
        }.getOrNull()
        // В собранном дистрибутиве jar лежит в app/ — поднимаемся к exe.
        val fromJar = codeSource?.let { src ->
            var dir = if (src.isFile) src.parentFile else src
            // app/ -> корень
            if (dir.name.equals("app", ignoreCase = true)) dir = dir.parentFile
            dir
        }
        fromJar ?: File(System.getProperty("user.dir"))
    }

    val adbExe: File get() = root.resolve("adb.exe")
    val apkDir: File get() = root.resolve("Apk")
    val tinoveDir: File get() = root.resolve("tinove")
    val scriptsDir: File get() = root.resolve("Scripts")

    fun ensureDirs() {
        listOf(apkDir, tinoveDir, scriptsDir).forEach { if (!it.exists()) it.mkdirs() }
    }

    /** Безопасно резолвим относительный путь внутри root (anti path-traversal). */
    fun resolveInside(base: File, relative: String): File {
        val f = base.resolve(relative).canonicalFile
        require(f.path.startsWith(base.canonicalFile.path)) {
            "Путь $relative выходит за пределы ${base.name}"
        }
        return f
    }
}
