package ru.changanmod.data

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import ru.changanmod.domain.*

/**
 * Реализация AdbPort поверх локального adb.exe.
 * ВАЖНО: все shell/push проходят проверку SafetyPolicy ЗДЕСЬ же, второй раз —
 * defence in depth. Даже если UI ошибётся, опасная команда не уйдёт на машину.
 */
class AdbCli(
    private val runner: ProcessRunner,
) : AdbPort {

    private fun adb(vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath) + args

    private fun adbSerial(serial: String, vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath, "-s", serial) + args

    override fun observeDevice(): Flow<HeadUnit> = flow {
        while (true) {
            val res = runner.run(adb("devices", "-l"), timeoutSec = 10)
            val line = res.stdout.lineSequence()
                .drop(1)
                .firstOrNull { it.isNotBlank() && !it.startsWith("*") }

            if (line == null) {
                emit(HeadUnit(serial = "", state = AdbState.DISCONNECTED))
            } else {
                val cols = line.trim().split(Regex("\\s+"))
                val serial = cols.firstOrNull().orEmpty()
                val stateStr = cols.getOrNull(1).orEmpty()
                val state = when (stateStr) {
                    "device" -> AdbState.CONNECTED
                    "unauthorized" -> AdbState.UNAUTHORIZED
                    "offline" -> AdbState.OFFLINE
                    else -> AdbState.CONNECTING
                }
                if (state == AdbState.CONNECTED) {
                    emit(HeadUnit(
                        serial = serial,
                        state = state,
                        vin = readVin(serial),
                        model = readModel(serial),
                        androidVersion = getprop(serial, "ro.build.version.release"),
                        firmware = readFirmware(serial),
                    ))
                } else {
                    emit(HeadUnit(serial = serial, state = state))
                }
            }
            delay(2000)
        }
    }

    private suspend fun getprop(serial: String, key: String): String? =
        runner.run(adbSerial(serial, "shell", "getprop", key), timeoutSec = 10)
            .stdout.trim().ifBlank { null }

    override suspend fun readVin(serial: String): String? {
        // VIN на разных ГУ лежит по-разному — пробуем несколько источников.
        val candidates = listOf("persist.sys.vehicle.vin", "ro.vehicle.vin", "persist.vin")
        for (k in candidates) getprop(serial, k)?.let { if (it.length in 11..20) return it }
        return null
    }

    override suspend fun readModel(serial: String): String? =
        getprop(serial, "ro.product.model") ?: getprop(serial, "ro.product.device")

    override suspend fun readFirmware(serial: String): String? =
        getprop(serial, "ro.build.display.id") ?: getprop(serial, "ro.build.version.incremental")

    override suspend fun install(serial: String, apkPath: String, reinstall: Boolean): AdbResult {
        val args = buildList {
            add("install"); if (reinstall) add("-r"); add(apkPath)
        }
        val r = runner.run(adbSerial(serial, *args.toTypedArray()), timeoutSec = 300)
        return r.toResult("install $apkPath")
    }

    override suspend fun push(serial: String, localPath: String, remotePath: String): Flow<OpProgress> {
        when (val d = SafetyPolicy.checkPush(remotePath)) {
            is SafetyPolicy.Decision.Denied -> return flow {
                emit(OpProgress("Push", 0, done = true, error = d.reason))
            }
            else -> {}
        }
        return flow {
            emit(OpProgress("Push $remotePath", 0))
            runner.stream(adbSerial(serial, "push", localPath, remotePath)).collect { ln ->
                val pct = Regex("(\\d+)%").find(ln)?.groupValues?.get(1)?.toIntOrNull()
                emit(OpProgress("Push $remotePath", pct ?: 50, line = ln))
            }
            emit(OpProgress("Push $remotePath", 100, done = true))
        }
    }

    override suspend fun grant(serial: String, pkg: String, permission: String): AdbResult =
        runner.run(adbSerial(serial, "shell", "pm", "grant", pkg, permission)).toResult("grant $pkg $permission")

    override suspend fun setAppEnabled(serial: String, pkg: String, enabled: Boolean): AdbResult {
        val verb = if (enabled) "enable" else "disable-user"
        val args = if (enabled) listOf("shell", "pm", "enable", pkg)
                   else listOf("shell", "pm", "disable-user", "--user", "0", pkg)
        return runner.run(adbSerial(serial, *args.toTypedArray())).toResult("pm $verb $pkg")
    }

    override suspend fun openSettings(serial: String, action: String): AdbResult =
        runner.run(adbSerial(serial, "shell", "am", "start", "-a", action)).toResult("am start $action")

    override suspend fun reboot(serial: String): AdbResult =
        runner.run(adbSerial(serial, "reboot"), timeoutSec = 20).toResult("reboot")

    override suspend fun shell(serial: String, args: List<String>): AdbResult {
        when (val d = SafetyPolicy.checkShell(args)) {
            is SafetyPolicy.Decision.Denied ->
                return AdbResult(false, "", d.reason, -2, "shell ${args.joinToString(" ")}")
            else -> {}
        }
        return runner.run(adbSerial(serial, "shell", *args.toTypedArray())).toResult("shell ${args.joinToString(" ")}")
    }

    override suspend fun killServer() { runner.run(adb("kill-server"), timeoutSec = 15) }
    override suspend fun startServer() { runner.run(adb("start-server"), timeoutSec = 30) }

    private fun ProcOutput.toResult(cmd: String) =
        AdbResult(exitCode == 0, stdout, stderr, exitCode, cmd)
}
