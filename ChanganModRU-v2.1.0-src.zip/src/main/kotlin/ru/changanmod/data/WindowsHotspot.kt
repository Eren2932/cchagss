package ru.changanmod.data

import ru.changanmod.domain.AdbResult
import ru.changanmod.domain.HotspotPort

/**
 * Windows Mobile Hotspot через WinRT (PowerShell).
 *
 * ВАЖНО про SSID/пароль: современный Windows Mobile Hotspot НЕ даёт менять SSID/пароль
 * из командной строки — он берёт их из системных настроек (Параметры → Мобильный хот-спот).
 * Старый "netsh wlan set hostednetwork" на многих адаптерах уже не работает.
 *
 * Поэтому стратегия:
 *  1) start()/stop() — рулим питанием хотспота через WinRT NetworkOperatorTetheringManager.
 *  2) ssid/password по возможности читаем и показываем в UI; смену предлагаем сделать
 *     один раз руками в настройках Windows (кнопка «Открыть настройки хот-спота»).
 *
 * Для стабильного автозапуска по SSID="ChanganModRU"/pass="12345678" лучший путь —
 * один раз выставить их в системе, дальше приложение только включает/выключает.
 */
class WindowsHotspot(
    private val runner: ProcessRunner,
) : HotspotPort {

    private val startScript = """
        ${'$'}p = [Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]
        ${'$'}conn = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
        if (${'$'}conn -eq ${'$'}null) { Write-Output "NO_INTERNET_PROFILE"; exit 1 }
        ${'$'}mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile(${'$'}conn)
        if (${'$'}mgr.TetheringOperationalState -eq 1) { Write-Output "ALREADY_ON"; exit 0 }
        ${'$'}op = ${'$'}mgr.StartTetheringAsync()
        Start-Sleep -Milliseconds 1500
        Write-Output ("STATE:" + ${'$'}mgr.TetheringOperationalState)
    """.trimIndent()

    private val stopScript = """
        ${'$'}conn = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
        ${'$'}mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile(${'$'}conn)
        ${'$'}op = ${'$'}mgr.StopTetheringAsync()
        Start-Sleep -Milliseconds 1000
        Write-Output ("STATE:" + ${'$'}mgr.TetheringOperationalState)
    """.trimIndent()

    private val stateScript = """
        ${'$'}conn = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
        if (${'$'}conn -eq ${'$'}null) { Write-Output "0"; exit 0 }
        ${'$'}mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile(${'$'}conn)
        Write-Output ${'$'}mgr.TetheringOperationalState
    """.trimIndent()

    override suspend fun start(ssid: String, password: String): AdbResult {
        val r = ps(startScript)
        return AdbResult(r.exitCode == 0 && !r.stdout.contains("NO_INTERNET"), r.stdout, r.stderr, r.exitCode, "hotspot start")
    }

    override suspend fun stop(): AdbResult {
        val r = ps(stopScript)
        return AdbResult(r.exitCode == 0, r.stdout, r.stderr, r.exitCode, "hotspot stop")
    }

    override suspend fun isActive(): Boolean =
        ps(stateScript).stdout.trim().contains("1")

    fun openHotspotSettings() {
        // ms-settings:network-mobilehotspot — открыть системные настройки для смены SSID/пароля.
        runBlockingSafe { runner.run(listOf("cmd", "/c", "start", "ms-settings:network-mobilehotspot"), timeoutSec = 10) }
    }

    private suspend fun ps(script: String): ProcOutput =
        runner.run(listOf("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script), timeoutSec = 30)

    private fun <T> runBlockingSafe(block: suspend () -> T) =
        kotlinx.coroutines.runBlocking { runCatching { block() } }
}
