package ru.changanmod.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier,
        color = Palette.Surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Palette.Border),
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun StatusDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(color))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Palette.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** Плитка операции — как на макете: иконка-квадрат, заголовок, подпись-статус. */
@Composable
fun ActionTile(
    title: String,
    subtitle: String,
    accent: Color,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (enabled) Palette.SurfaceAlt else Palette.Surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Palette.Border),
        onClick = onClick,
        enabled = enabled,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = if (enabled) 0.22f else 0.08f))
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = if (enabled) Palette.TextPrimary else Palette.TextMuted,
                    fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = Palette.TextMuted, fontSize = 12.sp)
            }
            Text("›", color = Palette.TextMuted, fontSize = 20.sp)
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = Palette.Primary),
        shape = RoundedCornerShape(10.dp),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}
