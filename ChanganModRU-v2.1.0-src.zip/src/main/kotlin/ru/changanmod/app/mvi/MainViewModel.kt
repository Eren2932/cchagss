package ru.changanmod.app.mvi

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ru.changanmod.domain.*

class MainViewModel(
    private val scope: CoroutineScope,
    private val adb: AdbPort,
    private val hotspot: HotspotPort,
    private val license: LicensePort,
    private val recipes: RecipeRepository,
    private val runRecipe: RunRecipeUseCase,
    private val onOpenHotspotSettings: () -> Unit,
) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        // 1) мониторинг устройства
        scope.launch {
            adb.observeDevice().collect { hu ->
                val prevSerial = _state.value.device.serial
                _state.update { it.copy(device = hu) }
                // Авто-сброс лицензии при смене/отключении устройства (безопасность).
                if (hu.serial != prevSerial) _state.update { it.copy(license = null) }
            }
        }
        // 2) загрузка рецептов
        scope.launch { _state.update { it.copy(recipes = recipes.loadAll()) } }
        // 3) статус хотспота
        scope.launch { _state.update { it.copy(hotspotActive = hotspot.isActive()) } }
    }

    fun dispatch(intent: Intent) = when (intent) {
        Intent.VerifyLicense -> verify()
        Intent.ToggleHotspot -> toggleHotspot()
        Intent.OpenHotspotSettings -> onOpenHotspotSettings()
        is Intent.RunRecipe -> execute(intent.recipe)
        Intent.RebootDevice -> withSerial { s -> safeOp { adb.reboot(s).logTo() } }
        Intent.OpenAndroidSettings -> withSerial { s ->
            safeOp { adb.openSettings(s, "android.settings.SETTINGS").logTo() }
        }
        Intent.RestartAdb -> scope.launch { adb.killServer(); adb.startServer(); log("ADB-сервер перезапущен") }.let {}
        Intent.ClearLog -> _state.update { it.copy(log = emptyList()) }
    }

    private fun verify() {
        val d = _state.value.device
        val vin = d.vin
        if (!_state.value.connected || vin.isNullOrBlank()) {
            log("Нельзя проверить лицензию: нет VIN/устройства"); return
        }
        scope.launch {
            _state.update { it.copy(licenseChecking = true) }
            val v = license.verify(vin, d.serial)
            _state.update { it.copy(license = v, licenseChecking = false) }
            log(if (v.allowed) "Активация подтверждена для VIN $vin (${v.features})"
                else "Активация отклонена: ${v.reason}")
        }
    }

    private fun toggleHotspot() = scope.launch {
        val s = _state.value
        val r = if (s.hotspotActive) hotspot.stop()
                else hotspot.start(s.hotspotSsid, s.hotspotPassword)
        _state.update { it.copy(hotspotActive = hotspot.isActive()) }
        log("Hotspot: ${r.output.ifBlank { if (s.hotspotActive) "остановлен" else "запущен" }}")
    }.let {}

    private fun execute(recipe: Recipe) {
        val st = _state.value
        if (!st.isRecipeEnabled(recipe)) { log("Операция недоступна: ${recipe.title}"); return }
        scope.launch {
            _state.update { it.copy(busy = true) }
            runRecipe.run(st.device.serial, recipe).collect { p ->
                _state.update { it.copy(progress = p) }
                if (p.line.isNotBlank()) log(p.line)
                if (p.error != null) log("ОШИБКА: ${p.error}")
                if (p.done) log("Готово: ${recipe.title}")
            }
            _state.update { it.copy(busy = false) }
        }
    }

    private inline fun withSerial(crossinline block: (String) -> Unit) {
        val s = _state.value.device.serial
        if (_state.value.connected && s.isNotBlank()) block(s) else log("Нет подключённого устройства")
    }

    private inline fun safeOp(crossinline block: suspend () -> Unit) {
        scope.launch { _state.update { it.copy(busy = true) }; runCatching { block() }
            .onFailure { log("Ошибка: ${it.message}") }; _state.update { it.copy(busy = false) } }
    }

    private suspend fun AdbResult.logTo() = log("$command -> ${if (success) "OK" else "FAIL: ${output.take(200)}"}")

    private fun log(line: String) = _state.update {
        it.copy(log = (it.log + "• $line").takeLast(500))
    }
}
