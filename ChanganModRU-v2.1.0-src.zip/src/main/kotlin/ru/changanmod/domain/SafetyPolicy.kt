package ru.changanmod.domain

/**
 * SafetyPolicy — единственный барьер между UI и shell-командой на машине.
 *
 * Принцип: ЗАПРЕЩЕНО ВСЁ, что явно не разрешено (whitelist), плюс отдельный
 * blacklist-детектор на заведомо опасные паттерны. Цель — не дать окирпичить ГУ.
 *
 * Любая команда перед выполнением должна пройти check(). Если вернулся Denied —
 * выполнять нельзя ни при каких условиях.
 */
object SafetyPolicy {

    sealed interface Decision {
        data object Allowed : Decision
        data class Denied(val reason: String) : Decision
    }

    /** setprop-свойства, трогать которые = высокий риск бутлупа/кирпича. */
    private val FORBIDDEN_PROP_PREFIXES = listOf(
        "ro.boot", "ro.bootloader", "ro.build.fingerprint", "ro.build.version",
        "persist.sys.safemode", "ctl.", "sys.powerctl", "persist.vendor.radio",
        "ro.product", "dalvik.vm", "persist.sys.usb.config",
    )

    /** settings, менять которые опасно (дисплей, bootanim,密ключевые системные). */
    private val FORBIDDEN_SETTINGS_KEYS = listOf(
        "device_provisioned", "user_setup_complete", "adb_enabled_bootcheck",
    )

    /** Прямые опасные команды — полный запрет из UI. */
    private val HARD_BLOCKED = listOf(
        "rm -rf", "mkfs", "dd ", "format", "wipe", "recovery", "fastboot",
        "reboot bootloader", "reboot recovery", "flash", "mount -o remount",
        "> /system", "> /vendor", "pm uninstall", // удаление системных пакетов запрещаем, только disable
    )

    /** Разрешённые корневые команды shell. */
    private val ALLOWED_SHELL_HEADS = setOf(
        "getprop", "settings", "pm", "am", "dumpsys", "input", "cmd", "svc", "wm",
    )

    /**
     * Белый список remote-путей для push. Нельзя писать в /system, /vendor напрямую —
     * только в пользовательские/ресурсные директории.
     */
    private val ALLOWED_PUSH_ROOTS = listOf(
        "/sdcard/", "/storage/emulated/0/", "/data/local/tmp/",
    )

    fun checkShell(args: List<String>): Decision {
        val joined = args.joinToString(" ")
        HARD_BLOCKED.firstOrNull { joined.contains(it, ignoreCase = true) }?.let {
            return Decision.Denied("Опасная команда заблокирована: \"$it\"")
        }
        val head = args.firstOrNull()?.trim()
            ?: return Decision.Denied("Пустая команда")
        if (head !in ALLOWED_SHELL_HEADS) {
            return Decision.Denied("Команда \"$head\" не в белом списке")
        }
        if (head == "pm" && args.getOrNull(1) == "uninstall") {
            return Decision.Denied("Удаление пакетов запрещено. Используй disable (SetAppEnabled=false)")
        }
        return Decision.Allowed
    }

    fun checkSetprop(prop: String): Decision {
        FORBIDDEN_PROP_PREFIXES.firstOrNull { prop.startsWith(it) }?.let {
            return Decision.Denied("setprop $prop запрещён (критическое свойство)")
        }
        return Decision.Allowed
    }

    fun checkSetting(key: String): Decision {
        if (key in FORBIDDEN_SETTINGS_KEYS)
            return Decision.Denied("settings $key запрещён (риск окирпичивания)")
        return Decision.Allowed
    }

    fun checkPush(remotePath: String): Decision {
        if (ALLOWED_PUSH_ROOTS.none { remotePath.startsWith(it) })
            return Decision.Denied("push в $remotePath запрещён. Разрешены: $ALLOWED_PUSH_ROOTS")
        return Decision.Allowed
    }

    /** Проверка шага рецепта целиком. */
    fun checkRecipeStep(step: RecipeStep): Decision = when (step) {
        is RecipeStep.Push -> checkPush(step.remotePath)
        is RecipeStep.Setting -> checkSetting(step.key)
        is RecipeStep.SetAppEnabled -> Decision.Allowed
        is RecipeStep.Install -> Decision.Allowed
        is RecipeStep.Grant -> Decision.Allowed
        is RecipeStep.OpenSettings -> Decision.Allowed
        RecipeStep.Reboot -> Decision.Allowed
    }
}
