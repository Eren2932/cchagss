package ru.changanmod

import ru.changanmod.domain.SafetyPolicy
import ru.changanmod.domain.SafetyPolicy.Decision
import kotlin.test.Test
import kotlin.test.assertTrue

class SafetyPolicyTest {

    @Test fun `allows whitelisted settings`() {
        assertTrue(SafetyPolicy.checkShell(listOf("settings", "put", "system", "x", "1")) is Decision.Allowed)
    }

    @Test fun `blocks rm -rf`() {
        assertTrue(SafetyPolicy.checkShell(listOf("rm", "-rf", "/system")) is Decision.Denied)
    }

    @Test fun `blocks pm uninstall`() {
        assertTrue(SafetyPolicy.checkShell(listOf("pm", "uninstall", "com.chinese.app")) is Decision.Denied)
    }

    @Test fun `blocks reboot bootloader`() {
        assertTrue(SafetyPolicy.checkShell(listOf("svc", "reboot", "bootloader")) is Decision.Denied)
    }

    @Test fun `blocks critical setprop`() {
        assertTrue(SafetyPolicy.checkSetprop("ro.boot.something") is Decision.Denied)
        assertTrue(SafetyPolicy.checkSetprop("persist.sys.my_flag") is Decision.Allowed)
    }

    @Test fun `blocks push into system`() {
        assertTrue(SafetyPolicy.checkPush("/system/app/x.apk") is Decision.Denied)
        assertTrue(SafetyPolicy.checkPush("/sdcard/x.apk") is Decision.Allowed)
    }

    @Test fun `blocks unknown shell head`() {
        assertTrue(SafetyPolicy.checkShell(listOf("busybox", "whatever")) is Decision.Denied)
    }
}
