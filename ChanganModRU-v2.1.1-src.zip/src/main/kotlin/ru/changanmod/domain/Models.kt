package ru.changanmod.domain

/** Статус ADB-подключения головного устройства. */
enum class AdbState { DISCONNECTED, UNAUTHORIZED, CONNECTING, CONNECTED, OFFLINE }

/** Подключённое головное устройство (ГУ) автомобиля. */
data class HeadUnit(
    val serial: String,          // adb serial (transport id)
    val state: AdbState,
    val vin: String? = null,     // читаем через getprop / настройки
    val model: String? = null,   // UNI-K, CS55+, Q07 ...
    val androidVersion: String? = null,
    val firmware: String? = null,
)

/** Результат любой ADB-операции — всегда с полным выводом для диагностики. */
data class AdbResult(
    val success: Boolean,
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val command: String,
) {
    val output: String get() = (stdout + "\n" + stderr).trim()
}

/** Прогресс длительной операции (push/install пакета рецептов). */
data class OpProgress(
    val title: String,
    val percent: Int,       // 0..100
    val line: String = "",
    val done: Boolean = false,
    val error: String? = null,
)

/** Ответ лицензионного сервера (FastAPI). */
data class LicenseVerdict(
    val allowed: Boolean,
    val vin: String,
    val features: Set<String> = emptySet(), // какие операции разрешены для этого VIN
    val expiresAt: String? = null,
    val reason: String? = null,
)

/** Описание одной операции прошивки — читается из /Scripts/*.json (data-driven). */
data class Recipe(
    val id: String,
    val title: String,
    val description: String,
    val requiredFeature: String,       // что должен подтвердить сервер
    val supportedModels: Set<String>,  // пустое = все
    val steps: List<RecipeStep>,
)

sealed interface RecipeStep {
    /** Установка APK из /Apk (путь относительный). */
    data class Install(val apkRelPath: String, val reinstall: Boolean = true) : RecipeStep
    /** Заливка ресурсов: /tinove -> remote. */
    data class Push(val localRelPath: String, val remotePath: String) : RecipeStep
    /** Выдача runtime-разрешения приложению. */
    data class Grant(val pkg: String, val permission: String) : RecipeStep
    /** Безопасная системная настройка (проходит через SafetyPolicy). */
    data class Setting(val namespace: String, val key: String, val value: String) : RecipeStep
    /** Открыть штатный системный экран. */
    data class OpenSettings(val action: String) : RecipeStep
    /** Запуск/остановка пакета (напр. отключить китайский лаунчер, НЕ удаляя). */
    data class SetAppEnabled(val pkg: String, val enabled: Boolean) : RecipeStep
    /** Перезагрузка ГУ. */
    data object Reboot : RecipeStep
}
