package ru.changanmod.domain

import kotlinx.coroutines.flow.Flow

/** Абстракция над adb.exe. Реализация — в слое data. */
interface AdbPort {
    /** Поток статуса устройства (поллинг adb devices + getprop). */
    fun observeDevice(): Flow<HeadUnit>

    suspend fun readVin(serial: String): String?
    suspend fun readModel(serial: String): String?
    suspend fun readFirmware(serial: String): String?

    suspend fun install(serial: String, apkPath: String, reinstall: Boolean): AdbResult
    suspend fun push(serial: String, localPath: String, remotePath: String): Flow<OpProgress>
    suspend fun grant(serial: String, pkg: String, permission: String): AdbResult
    suspend fun setAppEnabled(serial: String, pkg: String, enabled: Boolean): AdbResult
    suspend fun openSettings(serial: String, action: String): AdbResult
    suspend fun reboot(serial: String): AdbResult

    /** Любая shell-команда — ОБЯЗАТЕЛЬНО проходит через SafetyPolicy у вызывающего. */
    suspend fun shell(serial: String, args: List<String>): AdbResult

    suspend fun killServer()
    suspend fun startServer()
}

/** Windows Mobile Hotspot. */
interface HotspotPort {
    suspend fun start(ssid: String, password: String): AdbResult
    suspend fun stop(): AdbResult
    suspend fun isActive(): Boolean
}

/** Лицензионный сервер. */
interface LicensePort {
    suspend fun verify(vin: String, serial: String): LicenseVerdict
}

/** Загрузка рецептов из /Scripts. */
interface RecipeRepository {
    suspend fun loadAll(): List<Recipe>
}
