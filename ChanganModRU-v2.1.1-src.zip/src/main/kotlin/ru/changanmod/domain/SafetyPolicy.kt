package ru.changanmod.domain

/**
 * SafetyPolicy — единственный барьер между UI/рецептом и shell-командой на машине.
 *
 * Принцип: ЗАПРЕЩЕНО ВСЁ, что явно не разрешено (whitelist), плюс отдельный
 * blacklist-детектор на заведомо опасные паттерны. Цель — не дать окирпичить ГУ.
 *
 * Любой шаг перед выполнением должен пройти проверку. Если вернулся Denied —
 * выполнять нельзя ни при каких условиях.
 */
object SafetyPolicy {

    sealed interface Decision {
        data object Allowed : Decision
        data class Denied(val reason: String) : Decision
    }

    /** setprop-свойства, трогать которые = высокий риск бутлупа/кирпича. */
    private val FORBIDDEN_PROP_PREFIXES = listOf(
        "ro.boot", "ro.bootloader", "ro.build.fingerprint", "ro.build.version",
        "persist.sys.safemode", "ctl.", "sys.powerctl", "persist.vendor.radio",
        "ro.product", "dalvik.vm", "persist.sys.usb.config",
    )

    /** settings-ключи, менять которые опасно (потеря ADB, провижининг, режим полёта). */
    private val FORBIDDEN_SETTINGS_KEYS = setOf(
        "device_provisioned", "user_setup_complete", "adb_enabled_bootcheck",
        "adb_enabled", "airplane_mode_on",
    )

    private val SETTING_NAMESPACES = setOf("system", "secure", "global")

    /** Опасные фразы целиком. */
    private val HARD_BLOCKED_PHRASES = listOf(
        "rm -rf", "reboot bootloader", "reboot recovery", "mount -o remount",
        "> /system", "> /vendor", "pm uninstall",
    )

    /**
     * Опасные слова — только как отдельные слова, чтобы не ловить
     * `date_format` или `com.x.flashlight`.
     */
    private val HARD_BLOCKED_WORDS = Regex(
        "(?<![A-Za-z0-9_])(mkfs|dd|format|wipe|recovery|fastboot|flash)(?![A-Za-z0-9_])",
        RegexOption.IGNORE_CASE,
    )

    /** adb shell склеивает аргументы в одну строку для удалённого sh → метасимволы = инъекция. */
    private val SHELL_META = Regex("[;&|<>`\\n\\r]|\\x24\\(")

    private val IDENT = Regex("^[A-Za-z0-9._:/\\-]{1,200}\$")
    private val SETTING_KEY = Regex("^[A-Za-z0-9._]{1,100}\$")
    private val SETTING_VALUE = Regex("^[A-Za-z0-9._:,+=@/\\-]{0,200}\$")
    private val REMOTE_PATH = Regex("^[A-Za-z0-9._/\\-]{1,300}\$")

    /** Разрешённые корневые команды shell. */
    private val ALLOWED_SHELL_HEADS = setOf(
        "getprop", "settings", "pm", "am", "dumpsys", "input", "cmd", "svc", "wm",
    )

    /** Белый список remote-путей для push. В /system, /vendor писать нельзя. */
    private val ALLOWED_PUSH_ROOTS = listOf(
        "/sdcard/", "/storage/emulated/0/", "/data/local/tmp/",
    )

    fun checkShell(args: List<String>): Decision {
        val joined = args.joinToString(" ")
        if (SHELL_META.containsMatchIn(joined)) {
            return Decision.Denied("В команде недопустимые символы (; & | < > `)")
        }
        HARD_BLOCKED_PHRASES.firstOrNull { joined.contains(it, ignoreCase = true) }?.let {
            return Decision.Denied("Опасная команда заблокирована: \"$it\"")
        }
        HARD_BLOCKED_WORDS.find(joined)?.let {
            return Decision.Denied("Опасная команда заблокирована: \"${it.value}\"")
        }
        val head = args.firstOrNull()?.trim()
            ?: return Decision.Denied("Пустая команда")
        if (head !in ALLOWED_SHELL_HEADS) {
            return Decision.Denied("Команда \"$head\" не в белом списке")
        }
        if (head == "pm" && args.getOrNull(1) == "uninstall") {
            return Decision.Denied("Удаление пакетов запрещено. Используй disable (SetAppEnabled=false)")
        }
        return Decision.Allowed
    }

    fun checkSetprop(prop: String): Decision {
        FORBIDDEN_PROP_PREFIXES.firstOrNull { prop.startsWith(it) }?.let {
            return Decision.Denied("setprop $prop запрещён (критическое свойство)")
        }
        return Decision.Allowed
    }

    fun checkSetting(key: String): Decision {
        if (key in FORBIDDEN_SETTINGS_KEYS)
            return Decision.Denied("settings $key запрещён (риск окирпичивания)")
        return Decision.Allowed
    }

    fun checkPush(remotePath: String): Decision {
        if (remotePath.split('/').any { it == ".." })
            return Decision.Denied("push: '..' в пути запрещён ($remotePath)")
        if (!REMOTE_PATH.matches(remotePath))
            return Decision.Denied("push: недопустимые символы в пути ($remotePath)")
        if (ALLOWED_PUSH_ROOTS.none { remotePath.startsWith(it) })
            return Decision.Denied("push в $remotePath запрещён. Разрешены: $ALLOWED_PUSH_ROOTS")
        return Decision.Allowed
    }

    /** Проверка шага рецепта целиком (вызывается ДО выполнения любого шага). */
    fun checkRecipeStep(step: RecipeStep): Decision = when (step) {
        is RecipeStep.Push -> checkPush(step.remotePath)
        is RecipeStep.Setting -> checkSettingStep(step)
        is RecipeStep.SetAppEnabled -> checkIdent("пакет", step.pkg)
        is RecipeStep.Install ->
            if (step.apkRelPath.endsWith(".apk", ignoreCase = true)) Decision.Allowed
            else Decision.Denied("Install: файл должен быть .apk (${step.apkRelPath})")
        is RecipeStep.Grant -> firstDenied(
            checkIdent("пакет", step.pkg),
            checkIdent("разрешение", step.permission),
        )
        is RecipeStep.OpenSettings -> checkIdent("action", step.action)
        RecipeStep.Reboot -> Decision.Allowed
    }

    private fun checkSettingStep(s: RecipeStep.Setting): Decision {
        if (s.namespace !in SETTING_NAMESPACES)
            return Decision.Denied("settings: неизвестный namespace \"${s.namespace}\"")
        val keyDecision = checkSetting(s.key)
        if (keyDecision is Decision.Denied) return keyDecision
        if (!SETTING_KEY.matches(s.key))
            return Decision.Denied("settings: недопустимый ключ \"${s.key}\"")
        if (!SETTING_VALUE.matches(s.value))
            return Decision.Denied("settings: недопустимое значение \"${s.value}\"")
        return Decision.Allowed
    }

    private fun checkIdent(label: String, value: String): Decision =
        if (IDENT.matches(value)) Decision.Allowed
        else Decision.Denied("Недопустимое значение ($label): \"$value\"")

    private fun firstDenied(vararg ds: Decision): Decision =
        ds.firstOrNull { it is Decision.Denied } ?: Decision.Allowed
}
