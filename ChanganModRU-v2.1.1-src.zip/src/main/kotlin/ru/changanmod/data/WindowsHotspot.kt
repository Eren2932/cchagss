package ru.changanmod.data

import ru.changanmod.domain.AdbResult
import ru.changanmod.domain.HotspotPort
import java.util.Base64

/**
 * Мобильный хот-спот Windows через WinRT (NetworkOperatorTetheringManager), без сторонних утилит.
 *
 * Что делаем:
 *  1. Задаём SSID/пароль (ConfigureAccessPointAsync). Если не вышло, продолжаем с настройками Windows
 *     и честно сообщаем об этом в лог (CONFIG_FAIL).
 *  2. Включаем хот-спот и ждём реального состояния On (до ~10 с).
 *
 * Требования Windows: есть Wi-Fi адаптер и активное интернет-подключение (источник для раздачи).
 *
 * Скрипты передаются через -EncodedCommand (Base64/UTF-16LE): так не ломаются кавычки и кодировка.
 * В исходниках скриптов «~» заменяется на «$» (чтобы не экранировать доллар в Kotlin).
 */
class WindowsHotspot(private val runner: ProcessRunner) : HotspotPort {

    private val head = """
        ~ErrorActionPreference = 'Stop'
        ~ProgressPreference = 'SilentlyContinue'
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        [void][Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]
        [void][Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
        [void][Windows.Networking.NetworkOperators.NetworkOperatorTetheringAccessPointConfiguration,Windows.Networking.NetworkOperators,ContentType=WindowsRuntime]
        ~conn = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
        if (~conn -eq ~null) { Write-Output 'NO_INTERNET_PROFILE'; exit 2 }
        ~mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile(~conn)
    """.trimIndent()

    override suspend fun start(ssid: String, password: String): AdbResult {
        if (ssid.isEmpty() || ssid.length > 32 || ssid.any { it.isISOControl() }) {
            return fail("SSID должен быть 1–32 символа без управляющих знаков")
        }
        if (password.length !in 8..63 || password.any { it.code !in 32..126 }) {
            return fail("Пароль хот-спота: 8–63 печатных ASCII-символа")
        }
        val s = ssid.replace("'", "''")
        val p = password.replace("'", "''")
        val script = head + "\n" + """
            if ([int]~mgr.TetheringOperationalState -eq 1) { Write-Output 'ALREADY_ON'; exit 0 }
            try {
                ~asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { ~_.Name -eq 'AsTask' -and ~_.GetParameters().Count -eq 1 -and ~_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
                ~cfg = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringAccessPointConfiguration]::new()
                ~cfg.Ssid = '@@SSID@@'
                ~cfg.Passphrase = '@@PASS@@'
                ~t = ~asTask.Invoke(~null, @(~mgr.ConfigureAccessPointAsync(~cfg)))
                [void]~t.Wait(15000)
                Write-Output 'CONFIG_OK'
            } catch { Write-Output ('CONFIG_FAIL:' + ~_.Exception.GetType().Name) }
            ~op = ~mgr.StartTetheringAsync()
            for (~i = 0; ~i -lt 20 -and [int]~mgr.TetheringOperationalState -ne 1; ~i++) { Start-Sleep -Milliseconds 500 }
            Write-Output ('STATE:' + [int]~mgr.TetheringOperationalState)
        """.trimIndent()
        return run(script, "hotspot start", "@@SSID@@" to s, "@@PASS@@" to p)
    }

    override suspend fun stop(): AdbResult {
        val script = head + "\n" + """
            if ([int]~mgr.TetheringOperationalState -eq 2) { Write-Output 'ALREADY_OFF'; exit 0 }
            ~op = ~mgr.StopTetheringAsync()
            for (~i = 0; ~i -lt 20 -and [int]~mgr.TetheringOperationalState -ne 2; ~i++) { Start-Sleep -Milliseconds 500 }
            Write-Output ('STATE:' + [int]~mgr.TetheringOperationalState)
        """.trimIndent()
        return run(script, "hotspot stop")
    }

    override suspend fun isActive(): Boolean = try {
        raw(head + "\n" + "Write-Output ('STATE:' + [int]~mgr.TetheringOperationalState)")
            .stdout.contains("STATE:1")
    } catch (e: Exception) {
        false
    }

    /** Открыть штатный экран «Мобильный хот-спот» (не блокирует UI). */
    fun openHotspotSettings() {
        runCatching { ProcessBuilder("cmd", "/c", "start", "", "ms-settings:network-mobilehotspot").start() }
    }

    /**
     * Шаблон: «~» → «$». Значения пользователя (SSID/пароль) подставляются ПОСЛЕ этой замены
     * через маркеры @@..@@, иначе символ «~» в пароле превратился бы в «$».
     */
    private suspend fun raw(script: String, vararg subs: Pair<String, String>): ProcOutput {
        var text = script.replace('~', '$')
        for ((marker, value) in subs) text = text.replace(marker, value)
        val encoded = Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_16LE))
        return runner.run(
            listOf(
                "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-EncodedCommand", encoded,
            ),
            timeoutSec = 40,
        )
    }

    private suspend fun run(script: String, label: String, vararg subs: Pair<String, String>): AdbResult {
        val r = raw(script, *subs)
        val text = describe(r.stdout)
        return AdbResult(
            success = r.exitCode == 0,
            stdout = text,
            stderr = if (r.exitCode == 0) "" else r.stderr.take(300),
            exitCode = r.exitCode,
            command = label,
        )
    }

    private fun describe(out: String): String =
        out.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("; ") { line ->
            when {
                line == "NO_INTERNET_PROFILE" -> "у ноутбука нет активного интернета (хот-споту нужен источник)"
                line == "ALREADY_ON" -> "уже включён"
                line == "ALREADY_OFF" -> "уже выключен"
                line == "CONFIG_OK" -> "SSID и пароль применены"
                line.startsWith("CONFIG_FAIL") -> "SSID/пароль задать не удалось, действуют настройки Windows ($line)"
                line == "STATE:1" -> "включён"
                line == "STATE:2" -> "выключен"
                line.startsWith("STATE:") -> "переходное состояние ($line)"
                else -> line
            }
        }

    private fun fail(msg: String) = AdbResult(false, "", msg, -1, "hotspot")
}
