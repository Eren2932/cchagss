package ru.changanmod.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import ru.changanmod.domain.*

/**
 * Реализация AdbPort поверх локального adb.exe.
 * ВАЖНО: все shell/push проходят проверку SafetyPolicy ЗДЕСЬ же, второй раз —
 * defence in depth. Даже если UI ошибётся, опасная команда не уйдёт на машину.
 */
class AdbCli(
    private val runner: ProcessRunner,
) : AdbPort {

    private val propLine = Regex("^\\[(.+?)\\]: \\[(.*)\\]\$")
    private val vinKey = Regex("(^|[._])vin([._]|\$)", RegexOption.IGNORE_CASE)
    private val pushFailure = Regex(
        "^(adb: (error|failed)|error:)|Permission denied|No such file or directory|Read-only file system",
        RegexOption.IGNORE_CASE,
    )

    private fun adb(vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath) + args

    private fun adbSerial(serial: String, vararg args: String): List<String> =
        listOf(AppPaths.adbExe.absolutePath, "-s", serial) + args

    override fun observeDevice(): Flow<HeadUnit> = flow {
        var last: HeadUnit? = null
        while (true) {
            val hu = try {
                poll(last)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Нет adb.exe / adb завис — не роняем приложение, показываем «Не подключено».
                HeadUnit(serial = "", state = AdbState.DISCONNECTED)
            }
            last = hu
            emit(hu)
            delay(2000)
        }
    }

    /**
     * Один опрос. Детали ГУ (VIN, модель, прошивка) читаем ОДИН раз на подключение,
     * а не каждые 2 секунды: иначе десяток adb-процессов в цикле нагружают ГУ и USB.
     */
    private suspend fun poll(last: HeadUnit?): HeadUnit {
        val res = runner.run(adb("devices", "-l"), timeoutSec = 10)
        val line = res.stdout.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() && !it.startsWith("*") && !it.startsWith("List of devices") }
            ?: return HeadUnit(serial = "", state = AdbState.DISCONNECTED)

        val cols = line.split(Regex("\\s+"))
        val serial = cols.first()
        val state = when (cols.getOrNull(1)) {
            "device" -> AdbState.CONNECTED
            "unauthorized" -> AdbState.UNAUTHORIZED
            "offline" -> AdbState.OFFLINE
            else -> AdbState.CONNECTING
        }
        if (state != AdbState.CONNECTED) return HeadUnit(serial = serial, state = state)
        if (last != null && last.serial == serial && last.state == AdbState.CONNECTED) return last

        return HeadUnit(
            serial = serial,
            state = state,
            vin = readVin(serial),
            model = readModel(serial),
            androidVersion = getprop(serial, "ro.build.version.release"),
            firmware = readFirmware(serial),
        )
    }

    private suspend fun getprop(serial: String, key: String): String? =
        runner.run(adbSerial(serial, "shell", "getprop", key), timeoutSec = 10)
            .stdout.trim().ifBlank { null }

    override suspend fun readVin(serial: String): String? {
        // 1) Сканируем ВСЕ свойства: ищем ключ вида *.vin / vin_* со значением длиной 11..20.
        //    Точное имя свойства у разных ГУ отличается, поэтому не гадаем одно имя.
        val dump = runner.run(adbSerial(serial, "shell", "getprop"), timeoutSec = 15).stdout
        val fromDump = dump.lineSequence()
            .mapNotNull { line ->
                propLine.find(line.trim())?.let { it.groupValues[1] to it.groupValues[2].trim() }
            }
            .firstOrNull { (k, v) -> vinKey.containsMatchIn(k) && v.length in 11..20 }
            ?.second
        if (fromDump != null) return fromDump

        // 2) Запасной вариант — несколько известных имён.
        val candidates = listOf("persist.sys.vehicle.vin", "ro.vehicle.vin", "persist.vin")
        for (k in candidates) getprop(serial, k)?.let { if (it.length in 11..20) return it }
        return null
    }

    override suspend fun readModel(serial: String): String? =
        getprop(serial, "ro.product.model") ?: getprop(serial, "ro.product.device")

    override suspend fun readFirmware(serial: String): String? =
        getprop(serial, "ro.build.display.id") ?: getprop(serial, "ro.build.version.incremental")

    override suspend fun install(serial: String, apkPath: String, reinstall: Boolean): AdbResult {
        val args = buildList {
            add("install"); if (reinstall) add("-r"); add(apkPath)
        }
        val r = runner.run(adbSerial(serial, *args.toTypedArray()), timeoutSec = 300)
        return r.toResult("install $apkPath")
    }

    override suspend fun push(serial: String, localPath: String, remotePath: String): Flow<OpProgress> {
        val decision = SafetyPolicy.checkPush(remotePath)
        if (decision is SafetyPolicy.Decision.Denied) {
            return flow { emit(OpProgress("Push", 0, done = true, error = decision.reason)) }
        }
        return flow {
            val title = "Push $remotePath"
            emit(OpProgress(title, 0))
            var failure: String? = null
            runner.stream(adbSerial(serial, "push", localPath, remotePath)).collect { ln ->
                if (pushFailure.containsMatchIn(ln)) failure = ln
                val pct = Regex("(\\d+)%").find(ln)?.groupValues?.get(1)?.toIntOrNull()
                emit(OpProgress(title, pct ?: 50, line = ln))
            }
            // adb push не отдаёт exit code через стрим — ловим ошибку по тексту вывода.
            val f = failure
            if (f != null) emit(OpProgress(title, 0, done = true, error = f))
            else emit(OpProgress(title, 100, done = true))
        }
    }

    override suspend fun grant(serial: String, pkg: String, permission: String): AdbResult =
        runner.run(adbSerial(serial, "shell", "pm", "grant", pkg, permission)).toResult("grant $pkg $permission")

    override suspend fun setAppEnabled(serial: String, pkg: String, enabled: Boolean): AdbResult {
        val verb = if (enabled) "enable" else "disable-user"
        val args = if (enabled) listOf("shell", "pm", "enable", pkg)
                   else listOf("shell", "pm", "disable-user", "--user", "0", pkg)
        return runner.run(adbSerial(serial, *args.toTypedArray())).toResult("pm $verb $pkg")
    }

    override suspend fun openSettings(serial: String, action: String): AdbResult =
        runner.run(adbSerial(serial, "shell", "am", "start", "-a", action)).toResult("am start $action")

    override suspend fun reboot(serial: String): AdbResult =
        runner.run(adbSerial(serial, "reboot"), timeoutSec = 20).toResult("reboot")

    override suspend fun shell(serial: String, args: List<String>): AdbResult {
        val decision = SafetyPolicy.checkShell(args)
        if (decision is SafetyPolicy.Decision.Denied) {
            return AdbResult(false, "", decision.reason, -2, "shell ${args.joinToString(" ")}")
        }
        return runner.run(adbSerial(serial, "shell", *args.toTypedArray())).toResult("shell ${args.joinToString(" ")}")
    }

    override suspend fun killServer() { runner.run(adb("kill-server"), timeoutSec = 15) }
    override suspend fun startServer() { runner.run(adb("start-server"), timeoutSec = 30) }

    private fun ProcOutput.toResult(cmd: String) =
        AdbResult(exitCode == 0, stdout, stderr, exitCode, cmd)
}
