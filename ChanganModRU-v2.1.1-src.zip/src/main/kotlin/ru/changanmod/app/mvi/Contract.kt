package ru.changanmod.app.mvi

import ru.changanmod.domain.*

private val VIN_REGEX = Regex("^[A-HJ-NPR-Z0-9]{17}\$")

/** Единое состояние экрана (MVI). UI — чистая функция от этого state. */
data class UiState(
    val device: HeadUnit = HeadUnit("", AdbState.DISCONNECTED),
    val manualVin: String = "",
    val license: LicenseVerdict? = null,
    val licenseChecking: Boolean = false,
    val hotspotActive: Boolean = false,
    val hotspotSsid: String = "ChanganModRU",
    val hotspotPassword: String = "12345678",
    val recipes: List<Recipe> = emptyList(),
    val progress: OpProgress? = null,
    val log: List<String> = emptyList(),
    val busy: Boolean = false,
) {
    val connected: Boolean get() = device.state == AdbState.CONNECTED

    /** VIN: автоопределённый с ГУ, иначе введённый вручную (ровно 17 символов). */
    val vin: String? get() = device.vin ?: manualVin.trim().uppercase().takeIf { VIN_REGEX.matches(it) }

    val unlocked: Boolean get() = connected && license?.allowed == true

    /** Доступна ли конкретная операция: подключено + сервер подтвердил фичу + модель совместима. */
    fun isRecipeEnabled(recipe: Recipe): Boolean {
        if (!unlocked) return false
        val feats = license?.features ?: return false
        if (recipe.requiredFeature !in feats) return false
        val model = device.model
        if (recipe.supportedModels.isNotEmpty() &&
            model != null &&
            recipe.supportedModels.none { model.contains(it, ignoreCase = true) }
        ) return false
        return true
    }
}

/** Намерения пользователя. */
sealed interface Intent {
    data object VerifyLicense : Intent
    data object ToggleHotspot : Intent
    data object OpenHotspotSettings : Intent
    data class RunRecipe(val recipe: Recipe) : Intent
    data object RebootDevice : Intent
    data object OpenAndroidSettings : Intent
    data object RestartAdb : Intent
    data object ClearLog : Intent
    data class SetManualVin(val vin: String) : Intent
}
