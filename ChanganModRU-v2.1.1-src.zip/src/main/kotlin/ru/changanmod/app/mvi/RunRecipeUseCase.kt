package ru.changanmod.app.mvi

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import ru.changanmod.data.AppPaths
import ru.changanmod.domain.*

/**
 * Исполнение рецепта по шагам с прогрессом и жёсткой проверкой SafetyPolicy.
 * Если хоть один шаг Denied — весь рецепт останавливается (fail-fast), чтобы не
 * оставить машину в полусломанном состоянии.
 */
class RunRecipeUseCase(private val adb: AdbPort) {

    fun run(serial: String, recipe: Recipe): Flow<OpProgress> = flow {
        val total = recipe.steps.size

        // Preflight: проверяем ВСЕ шаги и наличие файлов ДО первого действия на машине.
        // Лучше не начать вообще, чем остановиться на 4-м шаге из 7.
        recipe.steps.forEachIndexed { i, step ->
            val d = SafetyPolicy.checkRecipeStep(step)
            if (d is SafetyPolicy.Decision.Denied) {
                emit(OpProgress(recipe.title, 0, done = true, error = "Рецепт отклонён (шаг ${i + 1}): ${d.reason}"))
                return@flow
            }
            val missing: String? = when (step) {
                is RecipeStep.Install ->
                    AppPaths.resolveInside(AppPaths.apkDir, step.apkRelPath).takeIf { !it.exists() }?.name
                is RecipeStep.Push ->
                    AppPaths.resolveInside(AppPaths.tinoveDir, step.localRelPath).takeIf { !it.exists() }?.name
                else -> null
            }
            if (missing != null) {
                emit(OpProgress(recipe.title, 0, done = true, error = "Рецепт не запущен: нет файла «$missing» (шаг ${i + 1})"))
                return@flow
            }
        }
        recipe.steps.forEachIndexed { i, step ->
            val base = (i * 100) / total

            when (val d = SafetyPolicy.checkRecipeStep(step)) {
                is SafetyPolicy.Decision.Denied -> {
                    emit(OpProgress(recipe.title, base, done = true, error = "Шаг ${i + 1}: ${d.reason}"))
                    return@flow
                }
                else -> {}
            }

            val res: AdbResult? = when (step) {
                is RecipeStep.Install -> {
                    val apk = AppPaths.resolveInside(AppPaths.apkDir, step.apkRelPath)
                    if (!apk.exists()) {
                        emit(OpProgress(recipe.title, base, done = true, error = "Нет файла: ${apk.name}")); return@flow
                    }
                    emit(OpProgress("Установка ${apk.name}", base))
                    adb.install(serial, apk.absolutePath, step.reinstall)
                }
                is RecipeStep.Push -> {
                    val local = AppPaths.resolveInside(AppPaths.tinoveDir, step.localRelPath)
                    if (!local.exists()) {
                        emit(OpProgress(recipe.title, base, done = true, error = "Нет ресурса: ${local.name}")); return@flow
                    }
                    var pushError: String? = null
                    adb.push(serial, local.absolutePath, step.remotePath).collect { p ->
                        if (p.error != null) pushError = p.error
                        // done/error сбрасываем: завершение ОДНОГО шага не конец всего рецепта.
                        emit(p.copy(percent = base + p.percent / total, done = false, error = null))
                    }
                    val pe = pushError
                    if (pe != null) {
                        emit(OpProgress(recipe.title, base, done = true, error = "Шаг ${i + 1}: $pe"))
                        return@flow
                    }
                    null
                }
                is RecipeStep.Grant -> {
                    emit(OpProgress("Разрешение ${step.permission}", base))
                    adb.grant(serial, step.pkg, step.permission)
                }
                is RecipeStep.Setting -> {
                    emit(OpProgress("Настройка ${step.key}", base))
                    adb.shell(serial, listOf("settings", "put", step.namespace, step.key, step.value))
                }
                is RecipeStep.OpenSettings -> {
                    emit(OpProgress("Открываю ${step.action}", base))
                    adb.openSettings(serial, step.action)
                }
                is RecipeStep.SetAppEnabled -> {
                    emit(OpProgress("${if (step.enabled) "Включаю" else "Отключаю"} ${step.pkg}", base))
                    adb.setAppEnabled(serial, step.pkg, step.enabled)
                }
                RecipeStep.Reboot -> {
                    emit(OpProgress("Перезагрузка ГУ", base))
                    adb.reboot(serial)
                }
            }

            if (res != null && !res.success) {
                emit(OpProgress(recipe.title, base, line = res.output, done = true,
                    error = "Шаг ${i + 1} провален: ${res.output.take(300)}"))
                return@flow
            }
        }
        emit(OpProgress(recipe.title, 100, done = true))
    }
}
