package ru.changanmod.app.mvi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ru.changanmod.data.AppPaths
import ru.changanmod.domain.*

/**
 * MVI-вьюмодель: Intent -> (side effects) -> новый UiState.
 * Любое исключение в корутине ловим и пишем в лог. Иначе необработанная ошибка
 * (нет adb.exe, сломанный JSON, отвалился USB) роняет всё приложение.
 */
class MainViewModel(
    private val scope: CoroutineScope,
    private val adb: AdbPort,
    private val hotspot: HotspotPort,
    private val license: LicensePort,
    private val recipes: RecipeRepository,
    private val runRecipe: RunRecipeUseCase,
    private val onOpenHotspotSettings: () -> Unit,
) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        if (!AppPaths.adbExe.exists()) {
            log("adb.exe не найден: ${AppPaths.adbExe.absolutePath}. Положите его рядом с программой.")
        }
        launchSafe {
            adb.observeDevice().collect { hu ->
                _state.update { cur ->
                    // Другое устройство → старая лицензия недействительна.
                    val changed = hu.serial != cur.device.serial
                    cur.copy(device = hu, license = if (changed) null else cur.license)
                }
            }
        }
        launchSafe { _state.update { it.copy(recipes = recipes.loadAll()) } }
        launchSafe { _state.update { it.copy(hotspotActive = hotspot.isActive()) } }
    }

    fun dispatch(intent: Intent) {
        when (intent) {
            Intent.VerifyLicense -> verify()
            Intent.ToggleHotspot -> toggleHotspot()
            Intent.OpenHotspotSettings -> onOpenHotspotSettings()
            is Intent.RunRecipe -> execute(intent.recipe)
            Intent.RebootDevice -> withSerial { s -> launchBusy { adb.reboot(s).logTo() } }
            Intent.OpenAndroidSettings -> withSerial { s ->
                launchBusy { adb.openSettings(s, "android.settings.SETTINGS").logTo() }
            }
            Intent.RestartAdb -> launchSafe {
                adb.killServer()
                adb.startServer()
                log("ADB-сервер перезапущен")
            }
            Intent.ClearLog -> _state.update { it.copy(log = emptyList()) }
            is Intent.SetManualVin ->
                _state.update { it.copy(manualVin = intent.vin.take(17), license = null) }
        }
    }

    // ───────────────────────── операции ─────────────────────────

    private fun verify() {
        val st = _state.value
        val vin = st.vin
        if (!st.connected || vin.isNullOrBlank()) {
            log("Нельзя проверить лицензию: нет подключения или VIN")
            return
        }
        launchSafe {
            _state.update { it.copy(licenseChecking = true) }
            try {
                val verdict = license.verify(vin, st.device.serial)
                _state.update { it.copy(license = verdict) }
                log(if (verdict.allowed) "Лицензия подтверждена сервером" else "Лицензия не подтверждена: ${verdict.reason ?: "отказ сервера"}")
            } finally {
                _state.update { it.copy(licenseChecking = false) }
            }
        }
    }

    private fun toggleHotspot() {
        val s = _state.value
        if (s.busy) { log("Подождите, идёт другая операция"); return }
        launchBusy {
            val r = if (s.hotspotActive) hotspot.stop() else hotspot.start(s.hotspotSsid, s.hotspotPassword)
            val active = hotspot.isActive()
            _state.update { it.copy(hotspotActive = active) }
            log("Хот-спот: " + r.output.ifBlank { if (active) "включён" else "выключен" })
        }
    }

    private fun execute(recipe: Recipe) {
        val st = _state.value
        if (st.busy) { log("Подождите, идёт другая операция"); return }
        if (!st.isRecipeEnabled(recipe)) { log("Операция недоступна: ${recipe.title}"); return }
        launchBusy {
            log("Запуск: ${recipe.title}")
            runRecipe.run(st.device.serial, recipe).collect { p ->
                _state.update { it.copy(progress = p) }
                if (p.line.isNotBlank()) log(p.line)
                p.error?.let { log("ОШИБКА: $it") }
                if (p.done && p.error == null) log("Готово: ${recipe.title}")
            }
        }
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun withSerial(block: (String) -> Unit) {
        val st = _state.value
        when {
            !st.connected -> log("Устройство не подключено")
            st.busy -> log("Подождите, идёт другая операция")
            else -> block(st.device.serial)
        }
    }

    /** Запуск корутины, которая не может уронить приложение. */
    private fun launchSafe(block: suspend () -> Unit): Job = scope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            log("Ошибка: ${e.message ?: e::class.simpleName}")
        }
    }

    /** То же + флаг busy на время операции (блокирует кнопки). */
    private fun launchBusy(block: suspend () -> Unit): Job = launchSafe {
        _state.update { it.copy(busy = true) }
        try {
            block()
        } finally {
            _state.update { it.copy(busy = false) }
        }
    }

    private fun AdbResult.logTo() =
        log(if (success) "OK: $command" else "Ошибка ($exitCode): ${output.take(300)}")

    private fun log(line: String) {
        _state.update { it.copy(log = (it.log + "• $line").takeLast(500)) }
    }
}
