package ru.changanmod.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import ru.changanmod.app.mvi.Intent
import ru.changanmod.app.mvi.MainViewModel
import ru.changanmod.app.mvi.UiState
import ru.changanmod.app.ui.*
import ru.changanmod.data.AppPaths
import ru.changanmod.domain.AdbState

/** Версия приложения: build.gradle.kts передаёт её через -Dapp.version (совпадает с версией ZIP). */
private val appVersion: String = System.getProperty("app.version") ?: "dev"

fun main() {
    // Создаём структуру portable-папок при первом старте (один раз, не при рекомпозиции).
    AppPaths.ensureDirs()
    application {
        val windowState = rememberWindowState(width = 1100.dp, height = 760.dp)
        Window(onCloseRequest = ::exitApplication, state = windowState, title = "ChanganModRU v$appVersion") {
            ChanganTheme {
                // Настоящий rememberCoroutineScope, не самодельный remember.
                val scope = rememberCoroutineScope()
                val vm = remember { AppModule.provideViewModel(scope) }
                val state by vm.state.collectAsState()
                MainScreen(state, vm::dispatch)
            }
        }
    }
}

@Composable
private fun MainScreen(state: UiState, onIntent: (Intent) -> Unit) {
    Scaffold(containerColor = Palette.Bg) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            HeaderRow(state, onIntent)
            StatusRow(state, onIntent)
            HotspotBar(state, onIntent)
            ActionsGrid(state, onIntent)
            if (state.progress != null) ProgressBlock(state)
            LogBlock(state, onIntent)
        }
    }
}

@Composable
private fun HeaderRow(state: UiState, onIntent: (Intent) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("CHANGANMODRU", color = Palette.TextPrimary, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.width(8.dp))
        AssistChip(onClick = {}, label = { Text("v$appVersion") })
        Spacer(Modifier.weight(1f))
        PrimaryButton("Проверить активацию", enabled = state.connected && state.vin != null && !state.licenseChecking) {
            onIntent(Intent.VerifyLicense)
        }
    }
}

@Composable
private fun StatusRow(state: UiState, onIntent: (Intent) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Panel(Modifier.weight(1f)) {
            Text("ADB СТАТУС", color = Palette.TextMuted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            val (color, label) = when (state.device.state) {
                AdbState.CONNECTED -> Palette.Success to "Подключено"
                AdbState.UNAUTHORIZED -> Palette.Warning to "Нет авторизации (подтвердите на ГУ)"
                AdbState.CONNECTING -> Palette.Warning to "Подключение…"
                AdbState.OFFLINE -> Palette.Danger to "Offline"
                AdbState.DISCONNECTED -> Palette.Danger to "Не подключено"
            }
            StatusDot(color, label)
            Spacer(Modifier.height(4.dp))
            Text(state.device.serial.ifBlank { "Подключите ГУ по USB / Wi-Fi" },
                color = Palette.TextMuted, style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { onIntent(Intent.RestartAdb) }) { Text("Перезапустить ADB") }
        }
        Panel(Modifier.weight(1f)) {
            Text("АВТОМОБИЛЬ", color = Palette.TextMuted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            Text(state.device.model ?: "— Нет устройства",
                color = Palette.TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text("VIN: ${state.vin ?: "будет определён автоматически"}",
                color = Palette.TextMuted, style = MaterialTheme.typography.bodySmall)
            if (state.connected && state.device.vin == null) {
                // ГУ не отдал VIN через getprop: даём ввести вручную (17 символов).
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.manualVin,
                    onValueChange = { onIntent(Intent.SetManualVin(it)) },
                    label = { Text("VIN вручную (17 символов)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            val lic = state.license
            if (lic != null) StatusDot(
                if (lic.allowed) Palette.Success else Palette.Danger,
                if (lic.allowed) "Активировано" else "Не активировано: ${lic.reason ?: ""}"
            )
        }
    }
}

@Composable
private fun HotspotBar(state: UiState, onIntent: (Intent) -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(
                if (state.hotspotActive) Palette.Success else Palette.TextMuted,
                if (state.hotspotActive) "Wi-Fi запущена (Mobile Hotspot): ${state.hotspotSsid}"
                else "Wi-Fi точка доступа выключена"
            )
            Spacer(Modifier.weight(1f))
            Text("Пароль: ${state.hotspotPassword}", color = Palette.TextMuted,
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = { onIntent(Intent.OpenHotspotSettings) }) { Text("Настройки") }
            PrimaryButton(if (state.hotspotActive) "Выключить" else "Включить", enabled = !state.busy) {
                onIntent(Intent.ToggleHotspot)
            }
        }
    }
}

@Composable
private fun ActionsGrid(state: UiState, onIntent: (Intent) -> Unit) {
    // Данные-driven: плитки рисуем из рецептов, но держим фиксированный красивый порядок.
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        state.recipes.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { recipe ->
                    val enabled = state.isRecipeEnabled(recipe)
                    ActionTile(
                        title = recipe.title,
                        subtitle = if (enabled) recipe.description.ifBlank { "Готово к запуску" }
                                   else "Подключите и активируйте VIN",
                        accent = Palette.Primary,
                        enabled = enabled && !state.busy,
                        onClick = { onIntent(Intent.RunRecipe(recipe)) },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("Настройки Android", "Открыть штатные настройки ГУ",
                Palette.Warning, state.connected && !state.busy,
                { onIntent(Intent.OpenAndroidSettings) }, Modifier.weight(1f))
            ActionTile("Перезагрузить устройство", "Reboot ГУ",
                Palette.Danger, state.connected && !state.busy,
                { onIntent(Intent.RebootDevice) }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ProgressBlock(state: UiState) {
    val p = state.progress ?: return
    Panel {
        Text(p.title, color = Palette.TextPrimary, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { p.percent / 100f }, modifier = Modifier.fillMaxWidth())
        if (p.error != null) {
            Spacer(Modifier.height(6.dp))
            Text(p.error, color = Palette.Danger, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun LogBlock(state: UiState, onIntent: (Intent) -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ЛОГ", color = Palette.TextMuted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { onIntent(Intent.ClearLog) }) { Text("Очистить") }
        }
        state.log.takeLast(12).forEach {
            Text(it, color = Palette.TextMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
