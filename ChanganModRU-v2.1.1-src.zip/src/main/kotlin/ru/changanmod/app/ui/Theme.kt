package ru.changanmod.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Тёмная минималистичная тема в стиле макета ChanganModRU. */
object Palette {
    val Bg = Color(0xFF0E1116)
    val Surface = Color(0xFF161B22)
    val SurfaceAlt = Color(0xFF1C232D)
    val Primary = Color(0xFF3B82F6)
    val Success = Color(0xFF22C55E)
    val Danger = Color(0xFFEF4444)
    val Warning = Color(0xFFF59E0B)
    val TextPrimary = Color(0xFFE6EDF3)
    val TextMuted = Color(0xFF8B949E)
    val Border = Color(0xFF2A313B)
}

@Composable
fun ChanganTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Palette.Primary,
        background = Palette.Bg,
        surface = Palette.Surface,
        onPrimary = Color.White,
        onBackground = Palette.TextPrimary,
        onSurface = Palette.TextPrimary,
        error = Palette.Danger,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
