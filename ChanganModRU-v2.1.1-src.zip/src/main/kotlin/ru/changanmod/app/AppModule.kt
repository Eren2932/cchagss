package ru.changanmod.app

import kotlinx.coroutines.CoroutineScope
import ru.changanmod.app.mvi.MainViewModel
import ru.changanmod.app.mvi.RunRecipeUseCase
import ru.changanmod.data.*

/**
 * Ручной DI — для десктопа этого достаточно, без тяжёлых фреймворков.
 * baseUrl лицензионного сервера читаем из config.properties рядом с exe (portable),
 * с дефолтом на всякий случай.
 */
object AppModule {

    private val config by lazy {
        val f = AppPaths.root.resolve("config.properties")
        java.util.Properties().apply { if (f.exists()) f.inputStream().use { load(it) } }
    }

    private val licenseBaseUrl: String
        get() = config.getProperty("license.baseUrl", "https://your-fastapi-server.example")
    private val licenseApiKey: String?
        get() = config.getProperty("license.apiKey")

    fun provideViewModel(scope: CoroutineScope): MainViewModel {
        val runner = ProcessRunner()
        val adb = AdbCli(runner)
        val hotspot = WindowsHotspot(runner)
        val license = LicenseClient(licenseBaseUrl, licenseApiKey)
        val recipes = JsonRecipeRepository()
        return MainViewModel(
            scope = scope,
            adb = adb,
            hotspot = hotspot,
            license = license,
            recipes = recipes,
            runRecipe = RunRecipeUseCase(adb),
            onOpenHotspotSettings = { hotspot.openHotspotSettings() },
        )
    }
}
