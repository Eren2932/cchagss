package ru.changanmod

import ru.changanmod.data.AppPaths
import java.io.File
import kotlin.io.path.createTempDirectory
import kotlin.test.Test
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class AppPathsTest {

    @Test fun `rejects sibling folder with the same prefix`() {
        val tmp = createTempDirectory("cmr").toFile()
        try {
            val apk = File(tmp, "Apk").apply { mkdirs() }
            File(tmp, "Apk2").mkdirs()
            // "Apk2" начинается с "Apk", но это ДРУГАЯ папка: выход за пределы должен ловиться.
            assertFailsWith<IllegalArgumentException> { AppPaths.resolveInside(apk, "../Apk2/x.apk") }
        } finally {
            tmp.deleteRecursively()
        }
    }

    @Test fun `rejects traversal and absolute paths`() {
        val tmp = createTempDirectory("cmr").toFile()
        try {
            val apk = File(tmp, "Apk").apply { mkdirs() }
            assertFailsWith<IllegalArgumentException> { AppPaths.resolveInside(apk, "../../etc/passwd") }
            assertFailsWith<IllegalArgumentException> { AppPaths.resolveInside(apk, tmp.absolutePath) }
        } finally {
            tmp.deleteRecursively()
        }
    }

    @Test fun `allows nested file inside base`() {
        val tmp = createTempDirectory("cmr").toFile()
        try {
            val apk = File(tmp, "Apk").apply { mkdirs() }
            val f = AppPaths.resolveInside(apk, "sub/x.apk")
            assertTrue(f.path.startsWith(apk.canonicalPath))
        } finally {
            tmp.deleteRecursively()
        }
    }
}
