package ru.changanmod.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import ru.changanmod.domain.Recipe
import ru.changanmod.domain.RecipeRepository
import ru.changanmod.domain.RecipeStep

/**
 * Рецепты лежат в /Scripts/<имя>.json — так новые машины/патчи добавляются БЕЗ пересборки.
 * Каждый json — декларативное описание шагов. SafetyPolicy проверит каждый шаг.
 */
class JsonRecipeRepository : RecipeRepository {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Serializable
    private data class RecipeDto(
        val id: String,
        val title: String,
        val description: String = "",
        val requiredFeature: String,
        val supportedModels: List<String> = emptyList(),
        val steps: List<StepDto>,
    )

    @Serializable
    private data class StepDto(
        val type: String,
        val apk: String? = null,
        val reinstall: Boolean = true,
        val local: String? = null,
        val remote: String? = null,
        val pkg: String? = null,
        val permission: String? = null,
        val namespace: String? = null,
        val key: String? = null,
        val value: String? = null,
        val action: String? = null,
        val enabled: Boolean = true,
    )

    override suspend fun loadAll(): List<Recipe> = withContext(Dispatchers.IO) {
        AppPaths.ensureDirs()
        val files = AppPaths.scriptsDir.listFiles { f -> f.extension.equals("json", true) } ?: emptyArray()
        files.mapNotNull { f ->
            runCatching {
                val dto = json.decodeFromString<RecipeDto>(f.readText())
                dto.toDomain()
            }.getOrNull()
        }
    }

    private fun RecipeDto.toDomain() = Recipe(
        id = id, title = title, description = description,
        requiredFeature = requiredFeature,
        supportedModels = supportedModels.toSet(),
        steps = steps.map { it.toDomain() },
    )

    private fun StepDto.toDomain(): RecipeStep = when (type.lowercase()) {
        "install" -> RecipeStep.Install(apk!!, reinstall)
        "push" -> RecipeStep.Push(local!!, remote!!)
        "grant" -> RecipeStep.Grant(pkg!!, permission!!)
        "setting" -> RecipeStep.Setting(namespace ?: "system", key!!, value!!)
        "opensettings" -> RecipeStep.OpenSettings(action!!)
        "setappenabled" -> RecipeStep.SetAppEnabled(pkg!!, enabled)
        "reboot" -> RecipeStep.Reboot
        else -> error("Неизвестный тип шага: $type")
    }
}
