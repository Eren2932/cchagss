package com.brellcar.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import com.brellcar.app.mvi.Intent
import com.brellcar.app.mvi.PendingRun
import com.brellcar.app.mvi.UiState
import com.brellcar.app.ui.*
import com.brellcar.data.AppPaths
import com.brellcar.domain.AdbState
import com.brellcar.domain.OpProgress

/** Версия приложения: build.gradle.kts передаёт её через -Dapp.version (совпадает с версией ZIP). */
private val appVersion: String = System.getProperty("app.version") ?: "dev"

fun main() {
    // Создаём структуру portable-папок при первом старте (один раз, не при рекомпозиции).
    AppPaths.ensureDirs()
    application {
        val scope = rememberCoroutineScope()
        val vm = remember { AppModule.provideViewModel(scope) }
        val windowState = rememberWindowState(width = 1280.dp, height = 860.dp)
        Window(
            // При закрытии гасим раздачу Wi-Fi, если включали мы: интернет не должен остаться открытым.
            onCloseRequest = { vm.shutdown(); exitApplication() },
            state = windowState,
            title = "BRELLCAR 2.0",
        ) {
            BrellcarTheme {
                val state by vm.state.collectAsState()
                MainScreen(state, vm::dispatch)
            }
        }
    }
}

@Composable
private fun MainScreen(state: UiState, onIntent: (Intent) -> Unit) {
    Column(Modifier.fillMaxSize().background(Palette.Bg)) {
        TopBar(state)
        Row(
            Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // Левая колонка: подключение и сеть.
            Column(
                Modifier.width(380.dp).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                DeviceCard(state, onIntent)
                LicenseCard(state, onIntent)
                WifiAdbCard(state, onIntent)
                HotspotCard(state, onIntent)
            }
            // Правая колонка: операции, прогресс, журнал.
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                RecipesSection(state, onIntent)
                ServiceSection(state, onIntent)
                state.progress?.let { ProgressCard(it) }
                LogCard(state, onIntent)
            }
        }
    }
    // Запуск на машине — только после явного подтверждения.
    state.pending?.let { ConfirmDialog(it, onIntent) }
}

// ───────────────────────── верхняя панель ─────────────────────────

@Composable
private fun TopBar(state: UiState) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LogoMark()
        Spacer(Modifier.width(14.dp))
        Column {
            Text("BRELLCAR 2.0", color = Palette.TextPrimary, fontSize = 24.sp,
                fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("Русификация и настройка ГУ Changan", color = Palette.TextMuted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(14.dp))
        Pill("v$appVersion")
        Spacer(Modifier.weight(1f))
        val lic = state.license
        when {
            lic == null -> Pill("Лицензия не проверена", Palette.Warning)
            lic.allowed -> Pill("Активировано", Palette.Success)
            else -> Pill("Не активировано", Palette.Danger)
        }
    }
}

// ───────────────────────── левая колонка ─────────────────────────

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.Primary,
    unfocusedBorderColor = Palette.Border,
    disabledBorderColor = Palette.Border,
    focusedLabelColor = Palette.Primary,
    unfocusedLabelColor = Palette.TextMuted,
    disabledLabelColor = Palette.TextMuted,
    cursorColor = Palette.Primary,
    focusedTextColor = Palette.TextPrimary,
    unfocusedTextColor = Palette.TextPrimary,
    disabledTextColor = Palette.TextMuted,
)

@Composable
private fun InfoRow(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(key, color = Palette.TextMuted, fontSize = 12.sp, modifier = Modifier.width(92.dp))
        Text(value, color = Palette.TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DeviceCard(state: UiState, onIntent: (Intent) -> Unit) {
    Panel(title = "Устройство") {
        val (color, label) = when (state.device.state) {
            AdbState.CONNECTED -> Palette.Success to "Подключено"
            AdbState.UNAUTHORIZED -> Palette.Warning to "Подтвердите отладку на экране ГУ"
            AdbState.CONNECTING -> Palette.Warning to "Подключение…"
            AdbState.OFFLINE -> Palette.Danger to "Offline: переподключите кабель"
            AdbState.MULTIPLE -> Palette.Danger to "Подключено несколько устройств"
            AdbState.DISCONNECTED -> Palette.Danger to "Не подключено"
        }
        StatusDot(color, label)
        Spacer(Modifier.height(10.dp))
        if (state.device.state == AdbState.MULTIPLE) {
            Text(
                "Устройства: ${state.device.serial}.\nОтключите лишние или перезапустите ADB. Пока устройств больше одного, " +
                    "запуск заблокирован, чтобы операция не ушла не на то устройство.",
                color = Palette.Warning, fontSize = 12.sp,
            )
        } else {
            val android = state.device.androidVersion
            val sdk = state.device.sdk
            InfoRow("Модель", state.device.model ?: "—")
            InfoRow("Android", if (android == null) "—" else if (sdk != null) "$android (API $sdk)" else android)
            InfoRow("Серийный №", state.device.serial.ifBlank { "—" })
            InfoRow("VIN", state.vin ?: "не определён")
            if (!state.device.abis.isEmpty()) InfoRow("Процессор", state.device.abis.joinToString())
        }
        if (state.connected && state.device.vin == null) {
            // ГУ не отдал VIN через getprop: даём ввести вручную (17 символов).
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = state.manualVin,
                onValueChange = { onIntent(Intent.SetManualVin(it)) },
                label = { Text("VIN вручную (17 символов)") },
                singleLine = true,
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(12.dp))
        GhostButton("Перезапустить ADB", modifier = Modifier.fillMaxWidth(), icon = Icons.Filled.Refresh) {
            onIntent(Intent.RestartAdb)
        }
    }
}

@Composable
private fun LicenseCard(state: UiState, onIntent: (Intent) -> Unit) {
    Panel(title = "Активация") {
        val lic = state.license
        when {
            lic == null -> Text(
                "Лицензия привязана к VIN. Нажмите «Проверить активацию», когда ГУ подключено.",
                color = Palette.TextMuted, fontSize = 12.sp,
            )
            lic.allowed -> {
                StatusDot(Palette.Success, "Активировано")
                Spacer(Modifier.height(6.dp))
                Text("Разрешено: ${lic.features.joinToString().ifBlank { "—" }}", color = Palette.TextMuted, fontSize = 12.sp)
                lic.expiresAt?.let { Text("До: $it", color = Palette.TextMuted, fontSize = 12.sp) }
            }
            else -> {
                StatusDot(Palette.Danger, "Не активировано")
                Spacer(Modifier.height(6.dp))
                Text(lic.reason ?: "Отказ сервера", color = Palette.Danger, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton(
            if (state.licenseChecking) "Проверяю…" else "Проверить активацию",
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Filled.Lock,
            enabled = state.connected && state.vin != null && !state.licenseChecking,
        ) { onIntent(Intent.VerifyLicense) }
    }
}

@Composable
private fun WifiAdbCard(state: UiState, onIntent: (Intent) -> Unit) {
    Panel(title = "ADB по Wi‑Fi") {
        Text(
            "1) Подключите ГУ по USB и нажмите «Включить».\n" +
                "2) Введите IP ГУ (в сети раздачи с ПК обычно 192.168.137.x) и нажмите «Подключить».",
            color = Palette.TextMuted, fontSize = 12.sp,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = state.wifiTarget,
            onValueChange = { onIntent(Intent.SetWifiTarget(it)) },
            label = { Text("IP ГУ, например 192.168.137.2") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton(
                "Включить", modifier = Modifier.weight(1f), icon = Icons.Filled.Usb,
                enabled = state.connected && !state.busy && !state.device.serial.contains(':'),
            ) { onIntent(Intent.EnableTcpip) }
            PrimaryButton(
                "Подключить", modifier = Modifier.weight(1f), icon = Icons.Filled.Wifi,
                enabled = !state.busy && state.wifiTarget.isNotBlank(),
            ) { onIntent(Intent.ConnectWifi) }
        }
    }
}

private fun hotspotInputValid(state: UiState): Boolean =
    state.hotspotSsid.length in 1..32 &&
        state.hotspotPassword.length in 8..63 &&
        state.hotspotPassword.all { it.code in 32..126 }

@Composable
private fun HotspotCard(state: UiState, onIntent: (Intent) -> Unit) {
    var showPassword by remember { mutableStateOf(false) }
    Panel(title = "Раздача Wi‑Fi с ПК") {
        StatusDot(
            if (state.hotspotActive) Palette.Success else Palette.TextMuted,
            if (state.hotspotActive) "Включена" else "Выключена",
        )
        Spacer(Modifier.height(10.dp))
        val locked = state.hotspotActive || state.busy
        OutlinedTextField(
            value = state.hotspotSsid,
            onValueChange = { onIntent(Intent.SetHotspot(it, state.hotspotPassword)) },
            label = { Text("Имя сети (SSID)") },
            singleLine = true,
            enabled = !locked,
            isError = state.hotspotSsid.isEmpty(),
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = state.hotspotPassword,
            onValueChange = { onIntent(Intent.SetHotspot(state.hotspotSsid, it)) },
            label = { Text("Пароль") },
            singleLine = true,
            enabled = !locked,
            isError = state.hotspotPassword.length !in 8..63,
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(
                        if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = null, tint = Palette.TextMuted,
                    )
                }
            },
            supportingText = { Text("8–63 символа. Пароль случайный на каждый запуск.", color = Palette.TextMuted) },
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        PrimaryButton(
            if (state.hotspotActive) "Выключить раздачу" else "Включить раздачу",
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Filled.Wifi,
            enabled = !state.busy && (state.hotspotActive || hotspotInputValid(state)),
        ) { onIntent(Intent.ToggleHotspot) }
        Spacer(Modifier.height(8.dp))
        GhostButton("Настройки Windows", modifier = Modifier.fillMaxWidth(), icon = Icons.Filled.Settings) {
            onIntent(Intent.OpenHotspotSettings)
        }
    }
}

// ───────────────────────── правая колонка ─────────────────────────

@Composable
private fun RecipesSection(state: UiState, onIntent: (Intent) -> Unit) {
    if (state.recipes.isEmpty()) {
        Panel(title = "Операции") {
            Text(
                "Рецепты не найдены. Положите *.json в папку Scripts рядом с программой и нажмите «Обновить рецепты».",
                color = Palette.TextMuted, fontSize = 13.sp,
            )
        }
        return
    }
    state.recipes.groupBy { it.group }.forEach { (group, items) ->
        SectionLabel(group)
        items.chunked(2).forEach { pair ->
            Row(
                Modifier.fillMaxWidth().height(IntrinsicSize.Max),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                pair.forEach { recipe ->
                    RecipeCard(
                        recipe = recipe,
                        disabledReason = state.disabledReason(recipe),
                        busy = state.busy,
                        onRun = { onIntent(Intent.RequestRun(recipe)) },
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ServiceSection(state: UiState, onIntent: (Intent) -> Unit) {
    SectionLabel("Сервис")
    Panel {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton(
                "Откатить изменения", modifier = Modifier.weight(1f), icon = Icons.Filled.Restore,
                enabled = state.canRollback && !state.busy,
            ) { onIntent(Intent.Rollback) }
            GhostButton(
                "Настройки Android", modifier = Modifier.weight(1f), icon = Icons.Filled.Settings,
                enabled = state.connected && !state.busy,
            ) { onIntent(Intent.OpenAndroidSettings) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton(
                "Обновить рецепты", modifier = Modifier.weight(1f), icon = Icons.Filled.Refresh,
                enabled = !state.busy,
            ) { onIntent(Intent.ReloadRecipes) }
            GhostButton(
                "Перезагрузить ГУ", modifier = Modifier.weight(1f), icon = Icons.Filled.PowerSettingsNew,
                danger = true, enabled = state.connected && !state.busy,
            ) { onIntent(Intent.RebootDevice) }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Откат возвращает настройки и включает отключённые приложения. Новые установки остаются, оригиналы заменённых APK лежат в Backups.",
            color = Palette.TextMuted, fontSize = 11.sp,
        )
    }
}

@Composable
private fun ProgressCard(p: OpProgress) {
    Panel(title = "Выполнение") {
        Text(p.title, color = Palette.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { p.percent.coerceIn(0, 100) / 100f },
            color = if (p.error != null) Palette.Danger else Palette.Primary,
            trackColor = Palette.SurfaceAlt,
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
        )
        if (p.error != null) {
            Spacer(Modifier.height(8.dp))
            Text(p.error, color = Palette.Danger, fontSize = 12.sp)
        } else if (p.done) {
            Spacer(Modifier.height(8.dp))
            Text("Готово", color = Palette.Success, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun logColor(line: String): Color = when {
    line.contains("ОШИБКА") || line.contains("Ошибка") || line.contains("Не удалось") ||
        line.contains("не удалось") || line.contains("не загружен") -> Palette.Danger
    line.contains("Готово") || line.contains("Восстановлено") || line.contains("подтверждена") ||
        line.startsWith("• OK") -> Palette.Success
    line.startsWith("• Запуск") -> Palette.Mint
    else -> Palette.TextMuted
}

@Composable
private fun LogCard(state: UiState, onIntent: (Intent) -> Unit) {
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    LaunchedEffect(state.log.size) {
        if (state.log.isNotEmpty()) listState.scrollToItem(state.log.lastIndex)
    }
    Panel(title = "Журнал") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Копия пишется в папку Logs", color = Palette.TextMuted, fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { clipboard.setText(AnnotatedString(state.log.joinToString("\n"))) }) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = Palette.Mint, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Копировать", color = Palette.Mint)
            }
            TextButton(onClick = { onIntent(Intent.ClearLog) }) { Text("Очистить", color = Palette.Mint) }
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier.fillMaxWidth().height(260.dp)
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF050D09)).padding(10.dp),
        ) {
            if (state.log.isEmpty()) {
                Text("Здесь будет ход выполнения операций.", color = Palette.TextMuted, fontSize = 12.sp)
            } else {
                LazyColumn(state = listState) {
                    items(state.log) { line ->
                        Text(line, color = logColor(line), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfirmDialog(p: PendingRun, onIntent: (Intent) -> Unit) {
    AlertDialog(
        onDismissRequest = { onIntent(Intent.CancelRun) },
        containerColor = Palette.Surface,
        titleContentColor = Palette.TextPrimary,
        textContentColor = Palette.TextMuted,
        title = { Text(p.recipe.title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Шагов: ${p.recipe.steps.size}. Перед заменой приложений оригиналы сохраняются в Backups, " +
                    "изменения пишутся в журнал и откатываются кнопкой «Откатить изменения».")
                p.risks.forEach { risk ->
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = Palette.Warning,
                            modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(risk, color = Palette.Warning, fontSize = 13.sp)
                    }
                }
                Text("Не выключайте зажигание и не отключайте кабель до завершения.")
            }
        },
        confirmButton = {
            PrimaryButton("Запустить", icon = Icons.Filled.PlayArrow) { onIntent(Intent.ConfirmRun) }
        },
        dismissButton = {
            GhostButton("Отмена") { onIntent(Intent.CancelRun) }
        },
    )
}
