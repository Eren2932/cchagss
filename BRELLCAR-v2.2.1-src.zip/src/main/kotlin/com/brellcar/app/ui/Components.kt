package com.brellcar.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.brellcar.domain.Recipe

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        color = Palette.Surface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Palette.Border),
    ) {
        Column(Modifier.padding(16.dp)) {
            if (title != null) {
                Text(title.uppercase(), color = Palette.Mint, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(10.dp))
            }
            content()
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text.uppercase(), color = Palette.TextMuted, fontSize = 12.sp,
        fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp,
        modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun StatusDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(color))
        Spacer(Modifier.width(10.dp))
        Text(label, color = Palette.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Pill(text: String, color: Color = Palette.Mint) {
    Surface(color = color.copy(alpha = 0.14f), shape = RoundedCornerShape(50)) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
    }
}

@Composable
fun LogoMark() {
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Palette.Primary),
        contentAlignment = Alignment.Center,
    ) {
        Text("B", color = Palette.OnPrimary, fontSize = 24.sp, fontWeight = FontWeight.Black)
    }
}

/** Главная кнопка: заливка, крупная, тёмный текст на зелёном. */
@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 44.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Palette.Primary, contentColor = Palette.OnPrimary,
            disabledContainerColor = Palette.SurfaceAlt, disabledContentColor = Palette.TextMuted,
        ),
        shape = RoundedCornerShape(12.dp),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

/** Вторичная кнопка: контур. */
@Composable
fun GhostButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val tint = if (danger) Palette.Danger else Palette.PrimaryBright
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 40.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tint, disabledContentColor = Palette.TextMuted),
        border = BorderStroke(1.dp, if (enabled) tint.copy(alpha = 0.6f) else Palette.Border),
        shape = RoundedCornerShape(12.dp),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

fun iconForGroup(group: String): ImageVector = when {
    group.contains("русиф", ignoreCase = true) -> Icons.Filled.Translate
    group.contains("приложен", ignoreCase = true) -> Icons.Filled.Apps
    group.contains("голос", ignoreCase = true) -> Icons.Filled.Folder
    group.contains("систем", ignoreCase = true) -> Icons.Filled.Settings
    else -> Icons.Filled.Build
}

/** Карточка операции: иконка, название, описание, число шагов, причина блокировки и крупная кнопка запуска. */
@Composable
fun RecipeCard(
    recipe: Recipe,
    disabledReason: String?,
    busy: Boolean,
    onRun: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val enabled = disabledReason == null && !busy
    Surface(
        modifier = modifier,
        color = if (disabledReason == null) Palette.SurfaceAlt else Palette.Surface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (disabledReason == null) Palette.PrimaryDeep else Palette.Border),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(11.dp))
                        .background(Palette.Primary.copy(alpha = if (disabledReason == null) 0.20f else 0.08f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(iconForGroup(recipe.group), contentDescription = null,
                        tint = if (disabledReason == null) Palette.PrimaryBright else Palette.TextMuted,
                        modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(recipe.title, color = if (disabledReason == null) Palette.TextPrimary else Palette.TextMuted,
                        fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${recipe.steps.size} шагов", color = Palette.TextMuted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(recipe.description.ifBlank { "Готово к запуску" }, color = Palette.TextMuted, fontSize = 12.sp,
                minLines = 2, maxLines = 3)
            Spacer(Modifier.height(10.dp))
            if (disabledReason != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = Palette.Warning, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(disabledReason, color = Palette.Warning, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
            }
            PrimaryButton("Запустить", modifier = Modifier.fillMaxWidth(), icon = Icons.Filled.PlayArrow,
                enabled = enabled, onClick = onRun)
        }
    }
}
