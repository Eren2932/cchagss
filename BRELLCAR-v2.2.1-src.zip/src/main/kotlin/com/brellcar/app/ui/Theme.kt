package com.brellcar.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * BRELLCAR 2.0: тёмно-зелёная тема.
 * Фон → поверхности → акцент: три слоя зелёного, акцентный зелёный только на действиях,
 * поэтому глаз сразу находит «куда нажать».
 */
object Palette {
    val Bg = Color(0xFF07110C)          // фон окна
    val Surface = Color(0xFF0E1B14)     // карточки
    val SurfaceAlt = Color(0xFF14271D)  // поля ввода, плашки внутри карточек
    val SurfaceHi = Color(0xFF1B3427)   // hover/выделение
    val Primary = Color(0xFF22C55E)     // главный зелёный (кнопки действий)
    val PrimaryBright = Color(0xFF4ADE80)
    val PrimaryDeep = Color(0xFF15803D)
    val OnPrimary = Color(0xFF04140A)   // тёмный текст на зелёной кнопке (контраст ≥ 8:1)
    val Mint = Color(0xFF86EFAC)
    val Success = Color(0xFF4ADE80)
    val Danger = Color(0xFFF87171)
    val Warning = Color(0xFFFBBF24)
    val TextPrimary = Color(0xFFE8F5EC)
    val TextMuted = Color(0xFF8DB09B)
    val Border = Color(0xFF21402F)
}

@Composable
fun BrellcarTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Palette.Primary,
        onPrimary = Palette.OnPrimary,
        primaryContainer = Palette.PrimaryDeep,
        secondary = Palette.Mint,
        background = Palette.Bg,
        surface = Palette.Surface,
        surfaceVariant = Palette.SurfaceAlt,
        onBackground = Palette.TextPrimary,
        onSurface = Palette.TextPrimary,
        onSurfaceVariant = Palette.TextMuted,
        outline = Palette.Border,
        error = Palette.Danger,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
